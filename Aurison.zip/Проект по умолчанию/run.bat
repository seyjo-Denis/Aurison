@echo off
cd /d "%~dp0"
where pythonw.exe >nul 2>nul
if errorlevel 1 (
    echo pythonw.exe not found. Install Python and make sure it is in PATH.
    pause
    exit /b 1
)
start "" pythonw.exe "%~dp0main.py"
