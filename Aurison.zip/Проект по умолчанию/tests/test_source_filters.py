"""Tests for the online source registry, filters and persistence."""

from __future__ import annotations

import os
import tempfile
import unittest
from unittest import mock

os.environ.setdefault(
    "AURISON_CONFIG_DIR", tempfile.mkdtemp(prefix="aurison-filter-test-")
)
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from PySide6.QtWidgets import QApplication

from aurison import music_service
from aurison.config import Config
from aurison.music_service import (
    PROVIDER_KEYS,
    PROVIDERS,
    SEARCH_LIMIT,
    MusicAggregatorService,
    ProviderReport,
    SearchReport,
    SearchResult,
    provider_available,
)
from aurison.online import SearchWorker
from aurison.online_view import OnlineView


def track(source: str, title: str, duration_ms: int = 200_000) -> SearchResult:
    return SearchResult(
        source=source,
        title=title,
        uploader="Artist",
        duration_ms=duration_ms,
        url=f"https://example.test/{source}/{title}",
    )


class ProviderRegistryTest(unittest.TestCase):
    def test_required_providers_are_registered_and_extensible(self) -> None:
        required = {
            "youtube",
            "vk",
            "rutube",
            "deezer",
            "itunes",
            "lightaudio",
            "hitmo",
        }
        self.assertTrue(required.issubset(set(PROVIDER_KEYS)))
        removed = {"soundcloud", "bandcamp", "dailymotion"}
        self.assertFalse(removed & set(PROVIDER_KEYS))
        self.assertEqual(
            [spec.key for spec in PROVIDERS],
            list(music_service.SOURCE_ORDER),
        )

    def test_preview_and_token_capabilities_come_from_the_registry(self) -> None:
        by_key = {spec.key: spec for spec in PROVIDERS}
        self.assertTrue(by_key["deezer"].preview_only)
        self.assertTrue(by_key["itunes"].preview_only)
        self.assertFalse(by_key["youtube"].preview_only)
        self.assertFalse(by_key["lightaudio"].preview_only)
        self.assertEqual(by_key["lightaudio"].label, "LightAudio")
        with mock.patch.dict(os.environ, {}, clear=False):
            os.environ.pop("AURISON_VK_TOKEN", None)
            self.assertFalse(provider_available("vk"))
            self.assertTrue(provider_available("youtube"))


class AdapterSelectionTest(unittest.TestCase):
    def test_search_runs_only_selected_adapters(self) -> None:
        calls: list[str] = []

        def fake_search(source: str, query: str, limit: int):
            calls.append(source)
            return [track(source, f"{source} song")]

        with mock.patch.object(
            music_service, "search_tracks", fake_search
        ):
            results, errors = MusicAggregatorService().search(
                "query", "tracks", 10, ["rutube", "itunes"]
            )

        self.assertEqual(sorted(calls), ["itunes", "rutube"])
        self.assertEqual(
            {result.source for result in results}, {"rutube", "itunes"}
        )
        self.assertEqual(errors, [])

    def test_empty_selection_sends_no_requests(self) -> None:
        with mock.patch.object(
            music_service, "search_tracks"
        ) as search:
            report = MusicAggregatorService().search_report(
                "query", "tracks", 10, []
            )
        search.assert_not_called()
        self.assertEqual(report.results, [])
        self.assertEqual(report.errors, [])
        self.assertFalse(report.any_success)

    def test_report_keeps_counts_and_source_failure_separate(self) -> None:
        def fake_search(source: str, query: str, limit: int):
            if source == "youtube":
                return []
            if source == "rutube":
                return [track("rutube", "Song")]
            if source == "lightaudio":
                raise RuntimeError("HTTP Error 503")
            return []

        with mock.patch.object(
            music_service, "search_tracks", fake_search
        ):
            report = MusicAggregatorService().search_report(
                "query",
                "tracks",
                10,
                ["youtube", "rutube", "lightaudio", "deezer"],
            )

        self.assertEqual(report.providers["youtube"].count, 0)
        self.assertEqual(report.providers["youtube"].status, "ok")
        self.assertEqual(report.providers["rutube"].count, 1)
        self.assertEqual(report.providers["lightaudio"].status, "unavailable")
        self.assertEqual(report.providers["deezer"].status, "preview")
        self.assertTrue(report.any_success)
        self.assertEqual(len(report.errors), 1)
        self.assertIn("LightAudio", report.errors[0])

    def test_album_search_ignores_track_only_adapters(self) -> None:
        album = SearchResult(
            "youtube",
            "Discovery",
            "Daft Punk",
            0,
            "https://www.youtube.com/playlist?list=PL1",
            kind="album",
            track_count=14,
        )
        with mock.patch.object(
            music_service, "search_youtube_albums", return_value=[album]
        ) as albums, mock.patch.object(
            music_service, "search_tracks"
        ) as tracks:
            report = MusicAggregatorService().search_report(
                "daft punk", "albums", 5, ["youtube", "rutube"]
            )
        albums.assert_called_once()
        tracks.assert_not_called()
        self.assertEqual(report.results, [album])

    def test_album_search_without_youtube_runs_nothing(self) -> None:
        with mock.patch.object(
            music_service, "search_youtube_albums"
        ) as albums, mock.patch.object(
            music_service, "search_tracks"
        ) as tracks:
            report = MusicAggregatorService().search_report(
                "daft punk", "albums", 5, ["rutube"]
            )
        albums.assert_not_called()
        tracks.assert_not_called()
        self.assertEqual(report.results, [])
        self.assertFalse(report.any_success)


class SourceConfigPersistenceTest(unittest.TestCase):
    def test_online_sources_roundtrip_without_touching_offline_config(self) -> None:
        with tempfile.TemporaryDirectory() as folder, mock.patch.dict(
            os.environ, {"AURISON_CONFIG_DIR": folder}
        ):
            cfg = Config()
            cfg.folders = [r"C:\Music"]
            cfg.selected_folder = r"C:\Music"
            cfg.volume = 42
            cfg.online_sources = ["youtube", "rutube"]
            cfg.save()

            loaded = Config.load()
            self.assertEqual(loaded.online_sources, ["youtube", "rutube"])
            self.assertEqual(loaded.folders, [r"C:\Music"])
            self.assertEqual(loaded.selected_folder, r"C:\Music")
            self.assertEqual(loaded.volume, 42)

            none_selected = Config()
            none_selected.online_sources = []
            none_selected.save()
            self.assertEqual(Config.load().online_sources, [])

            default_all = Config()
            default_all.save()
            self.assertIsNone(Config.load().online_sources)


class OnlineViewFilterTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.app = QApplication.instance() or QApplication([])

    def setUp(self) -> None:
        self.view = OnlineView()

    def tearDown(self) -> None:
        self.view.deleteLater()
        self.app.processEvents()

    def test_every_registered_provider_has_a_checkbox(self) -> None:
        self.assertEqual(
            set(self.view.source_panel._checks), set(PROVIDER_KEYS)
        )
        self.assertEqual(self.view.selected_sources(), list(PROVIDER_KEYS))
        self.assertEqual(
            self.view.source_panel._checks["lightaudio"].text(), "LightAudio"
        )

    def test_source_hint_lists_enabled_and_filtered_sources(self) -> None:
        self.view.set_sources(["youtube", "rutube"])
        hint = self.view.source_hint.text()
        self.assertIn("Ищем в: YouTube, RUTUBE", hint)
        self.assertIn("отфильтровано источников: 5", hint)

    def test_checkbox_excludes_a_source_and_emits_selection(self) -> None:
        emitted: list[list[str]] = []
        self.view.sourcesChanged.connect(
            lambda sources: emitted.append(list(sources))
        )
        self.view.source_panel._checks["youtube"].setChecked(False)
        self.assertNotIn("youtube", self.view.selected_sources())
        self.assertTrue(emitted)
        self.assertNotIn("youtube", emitted[-1])

    def test_no_sources_blocks_the_request_and_shows_a_hint(self) -> None:
        requested: list[tuple] = []
        self.view.searchRequested.connect(
            lambda *args: requested.append(args)
        )
        self.view.set_sources([])
        self.view.set_query("daft punk")
        self.view._submit_search()
        self.assertEqual(requested, [])
        self.assertIn(
            "Выберите хотя бы один источник",
            self.view.status_label.full_text(),
        )

    def test_reports_update_counters_and_availability_badges(self) -> None:
        self.view.set_provider_reports(
            {
                "youtube": ProviderReport(
                    "youtube", "YouTube", count=4
                ),
                "rutube": ProviderReport(
                    "rutube",
                    "RUTUBE",
                    error="HTTP Error 503",
                    available=False,
                ),
            }
        )
        self.assertEqual(
            self.view.source_panel._counts["youtube"].text(), "4"
        )
        self.assertEqual(
            self.view.source_panel._badges["rutube"].property("status"),
            "unavailable",
        )

    def test_selected_sources_have_a_dedicated_empty_state(self) -> None:
        self.view.show_selected_empty()
        self.assertEqual(self.view._state, "empty_selected")
        self.assertIn(
            "По выбранным источникам ничего не найдено",
            self.view.placeholder.title_label.text(),
        )

    def test_source_warnings_use_provider_labels(self) -> None:
        self.view.show_source_warnings(
            [
                "LightAudio недоступен (HTTP 503).",
                "RUTUBE: HTTP Error 503",
            ]
        )
        details = self.view.status_label.full_text()
        self.assertIn("LightAudio, RUTUBE", details)
        self.assertNotIn("HTTP 503", details)


class SearchWorkerFilterTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.app = QApplication.instance() or QApplication([])

    def test_worker_forwards_selected_sources_and_emits_report(self) -> None:
        result = track("rutube", "Song")
        report = SearchReport(
            results=[result],
            providers={
                "rutube": ProviderReport(
                    "rutube", "RUTUBE", count=1
                )
            },
            requested_sources=("rutube",),
        )
        worker = SearchWorker(7, "query", "tracks", sources=["rutube"])
        detailed: list[tuple] = []
        legacy: list[tuple] = []
        worker.finishedSearchDetailed.connect(
            lambda generation, payload: detailed.append(
                (generation, payload)
            )
        )
        worker.finishedSearch.connect(
            lambda *args: legacy.append(args)
        )
        with mock.patch.object(
            MusicAggregatorService,
            "search_report",
            return_value=report,
        ) as search:
            worker.run()

        search.assert_called_once_with(
            "query", "tracks", SEARCH_LIMIT, ["rutube"]
        )
        self.assertEqual(detailed[0][0], 7)
        self.assertIs(detailed[0][1], report)
        self.assertEqual(legacy[0][1], [result])
        self.assertEqual(legacy[0][2], [])


if __name__ == "__main__":
    unittest.main()
