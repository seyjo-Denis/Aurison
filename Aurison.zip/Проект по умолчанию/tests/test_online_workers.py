"""Tests for the Qt online workers without touching the network."""

from __future__ import annotations

import os
import tempfile
import unittest
from unittest import mock

os.environ.setdefault(
    "AURISON_CONFIG_DIR", tempfile.mkdtemp(prefix="aurison-worker-test-")
)
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from PySide6.QtWidgets import QApplication

from aurison.online import PreviewWorker
from aurison.music_service import MusicAggregatorService, SearchResult


class PreviewWorkerTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.app = QApplication.instance() or QApplication([])

    def test_primary_worker_resolves_preview(self) -> None:
        result = SearchResult(
            "youtube",
            "Song",
            "Artist",
            200_000,
            "https://example.test/watch",
        )
        worker = PreviewWorker(3, result)
        ready: list[tuple] = []
        failed: list[tuple] = []
        worker.previewReady.connect(lambda *args: ready.append(args))
        worker.previewFailed.connect(lambda *args: failed.append(args))

        with mock.patch.object(
            MusicAggregatorService,
            "resolve_preview",
            return_value=("https://example.test/stream.m4a", "Song", 200_000),
        ) as resolver:
            worker.run()

        resolver.assert_called_once_with(result)
        self.assertEqual(
            ready,
            [(3, "https://example.test/stream.m4a", "Song", 200_000)],
        )
        self.assertEqual(failed, [])

    def test_fallback_worker_refreshes_the_stream(self) -> None:
        result = SearchResult(
            "deezer",
            "Song",
            "Artist",
            200_000,
            "https://example.test/stale",
            preview_only=True,
        )
        worker = PreviewWorker(4, result, fallback=True)
        ready: list[tuple] = []
        failed: list[tuple] = []
        worker.previewReady.connect(lambda *args: ready.append(args))
        worker.previewFailed.connect(lambda *args: failed.append(args))

        with mock.patch.object(
            MusicAggregatorService,
            "resolve_preview_fallback",
            return_value=("https://example.test/fresh", "Song", 30_000),
        ) as resolver:
            worker.run()

        resolver.assert_called_once_with(result)
        self.assertEqual(
            ready, [(4, "https://example.test/fresh", "Song", 30_000)]
        )
        self.assertEqual(failed, [])

    def test_fallback_failure_is_reported(self) -> None:
        result = SearchResult(
            "youtube",
            "Song",
            "Artist",
            200_000,
            "https://example.test/watch",
        )
        worker = PreviewWorker(5, result, fallback=True)
        failed: list[tuple] = []
        worker.previewReady.connect(lambda *args: None)
        worker.previewFailed.connect(lambda *args: failed.append(args))

        with mock.patch.object(
            MusicAggregatorService,
            "resolve_preview_fallback",
            side_effect=RuntimeError("no preview"),
        ):
            worker.run()

        self.assertEqual(failed, [(5, "no preview")])


if __name__ == "__main__":
    unittest.main()
