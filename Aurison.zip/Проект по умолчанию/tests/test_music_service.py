"""Unit tests for the online aggregation, preview and download backend.

These tests never touch the network: every provider call and every yt-dlp
interaction is replaced with a deterministic fake.
"""

from __future__ import annotations

import os
import tempfile
import unittest
from pathlib import Path
from unittest import mock

os.environ.setdefault(
    "AURISON_CONFIG_DIR", tempfile.mkdtemp(prefix="aurison-service-test-")
)

from aurison import music_service
from aurison.music_service import (
    MAX_TRACK_MS,
    MIN_TRACK_MS,
    MusicAggregatorService,
    SearchResult,
    cookie_options,
    dedupe_key,
    track_duration_ok,
)


def track(
    source: str,
    title: str,
    uploader: str,
    duration_ms: int,
    url: str | None = None,
    *,
    preview_only: bool = False,
) -> SearchResult:
    return SearchResult(
        source=source,
        title=title,
        uploader=uploader,
        duration_ms=duration_ms,
        url=url or f"https://example.test/{source}/{abs(hash(title))}",
        preview_only=preview_only,
    )


class DurationFilterTest(unittest.TestCase):
    def test_short_and_long_tracks_are_rejected(self) -> None:
        self.assertFalse(
            track_duration_ok(track("youtube", "Ad", "Brand", MIN_TRACK_MS - 1))
        )
        self.assertFalse(
            track_duration_ok(track("youtube", "Album", "Band", MAX_TRACK_MS + 1))
        )

    def test_music_length_and_unknown_duration_are_kept(self) -> None:
        self.assertTrue(
            track_duration_ok(track("youtube", "Song", "Band", MIN_TRACK_MS))
        )
        self.assertTrue(
            track_duration_ok(track("youtube", "Song", "Band", 10 * 60_000))
        )
        self.assertTrue(track_duration_ok(track("youtube", "Song", "Band", 0)))
        self.assertTrue(
            track_duration_ok(
                SearchResult(
                    "youtube", "Album", "Band", 0, "https://example.test/list", "album"
                )
            )
        )


class AggregationTest(unittest.TestCase):
    def test_every_provider_is_queried_and_deduplicated(self) -> None:
        full = track(
            "youtube",
            "Daft Punk - Instant Crush (Official Video) ft. Julian Casablancas",
            "Daft Punk",
            340_000,
            "https://example.test/yt/full",
        )
        duplicate_lyrics = track(
            "youtube",
            "Daft Punk - Instant Crush (Lyrics) ft. Julian Casablancas",
            "Lyrics Channel",
            338_000,
            "https://example.test/yt/lyrics",
        )
        preview_duplicate = track(
            "deezer",
            "Instant Crush",
            "Daft Punk",
            211_000,
            "https://example.test/deezer/preview",
            preview_only=True,
        )
        other_preview = track(
            "itunes",
            "Another Song",
            "Another Artist",
            240_000,
            "https://example.test/itunes/preview",
            preview_only=True,
        )
        short_ad = track("youtube", "Ad", "Brand", 20_000)
        long_mix = track("rutube", "Mega Mix", "DJ", 80 * 60_000)

        supplied = {
            "youtube": [full, duplicate_lyrics, short_ad],
            "rutube": [long_mix],
            "deezer": [preview_duplicate],
            "vk": [],
            "lightaudio": [],
            "hitmo": [],
            "itunes": [other_preview],
        }
        requested: list[str] = []

        def fake_search_tracks(source: str, query: str, limit: int):
            requested.append(source)
            if source == "lightaudio":
                raise RuntimeError("provider is down")
            return list(supplied[source])

        with mock.patch.object(
            music_service, "search_tracks", fake_search_tracks
        ):
            results, errors = MusicAggregatorService().search(
                "daft punk", "tracks", 10
            )

        self.assertEqual(sorted(requested), sorted(music_service.SOURCE_ORDER))
        self.assertEqual([result.url for result in results], [
            "https://example.test/yt/full",
            "https://example.test/itunes/preview",
        ])
        self.assertTrue(results[1].preview_only)
        self.assertEqual(len(errors), 1)
        self.assertIn("LightAudio", errors[0])

    def test_album_scope_only_queries_youtube_playlists(self) -> None:
        album = SearchResult(
            "youtube",
            "Discovery",
            "Daft Punk",
            0,
            "https://www.youtube.com/playlist?list=PL1",
            kind="album",
            track_count=14,
        )
        with mock.patch.object(
            music_service, "search_youtube_albums", return_value=[album]
        ) as albums, mock.patch.object(
            music_service, "search_tracks"
        ) as tracks:
            results, errors = MusicAggregatorService().search(
                "daft punk", "albums", 5
            )
        albums.assert_called_once()
        tracks.assert_not_called()
        self.assertEqual(results, [album])
        self.assertEqual(errors, [])

    def test_dedupe_prefers_a_full_result_over_a_preview(self) -> None:
        preview = track(
            "deezer", "Instant Crush", "Daft Punk", 210_000, preview_only=True
        )
        full = track(
            "youtube", "Daft Punk - Instant Crush", "Daft Punk", 340_000
        )
        self.assertEqual(dedupe_key(preview), dedupe_key(full))
        results = MusicAggregatorService()._dedupe([preview, full])
        self.assertEqual(results, [full])

    def test_dedupe_ignores_case_punctuation_and_feature_credits(self) -> None:
        first = track(
            "youtube",
            "DAFT PUNK - Instant Crush (feat. Julian Casablancas) [HD]",
            "Some Channel",
            340_000,
        )
        second = track(
            "itunes",
            "Instant Crush",
            "Daft Punk",
            340_000,
            preview_only=True,
        )
        self.assertEqual(dedupe_key(first), dedupe_key(second))


class PreviewTest(unittest.TestCase):
    def test_preview_only_result_is_played_directly(self) -> None:
        result = track(
            "itunes",
            "Instant Crush",
            "Daft Punk",
            340_000,
            "https://example.test/preview.m4a",
            preview_only=True,
        )
        url, title, duration_ms = MusicAggregatorService().resolve_preview(result)
        self.assertEqual(url, "https://example.test/preview.m4a")
        self.assertEqual(title, "Instant Crush")
        self.assertEqual(duration_ms, 30_000)

    def test_missing_stream_falls_back_to_itunes_preview(self) -> None:
        result = track(
            "youtube",
            "Instant Crush",
            "Daft Punk",
            340_000,
            "https://example.test/watch",
        )
        payload = {
            "results": [
                {
                    "trackName": "Instant Crush",
                    "previewUrl": "https://example.test/fallback.m4a",
                    "trackTimeMillis": 340_000,
                }
            ]
        }
        service = MusicAggregatorService()
        with mock.patch.object(
            service, "_extract_info", side_effect=RuntimeError("HTTP Error 403")
        ), mock.patch.object(
            music_service, "http_json", return_value=payload
        ):
            url, title, duration_ms = service.resolve_preview(result)
        self.assertEqual(url, "https://example.test/fallback.m4a")
        self.assertIn("фрагмент 30 сек", title)
        self.assertEqual(duration_ms, 30_000)

    def test_playback_failure_refreshes_an_expired_deezer_url(self) -> None:
        stale = track(
            "deezer",
            "Instant Crush",
            "Daft Punk",
            340_000,
            "https://example.test/deezer/stale",
            preview_only=True,
        )
        fresh = track(
            "deezer",
            "Instant Crush",
            "Daft Punk",
            340_000,
            "https://example.test/deezer/fresh",
            preview_only=True,
        )
        service = MusicAggregatorService()
        with mock.patch.object(
            music_service, "search_tracks", return_value=[fresh]
        ):
            url, title, duration_ms = service.resolve_preview_fallback(stale)
        self.assertEqual(url, "https://example.test/deezer/fresh")
        self.assertIn("фрагмент 30 сек", title)
        self.assertEqual(duration_ms, 30_000)

    def test_playback_failure_falls_back_to_itunes_preview(self) -> None:
        result = track(
            "youtube",
            "Instant Crush",
            "Daft Punk",
            340_000,
            "https://example.test/watch",
        )
        payload = {
            "results": [
                {
                    "trackName": "Instant Crush",
                    "previewUrl": "https://example.test/itunes.m4a",
                    "trackTimeMillis": 340_000,
                }
            ]
        }
        service = MusicAggregatorService()
        with mock.patch.object(
            music_service, "http_json", return_value=payload
        ):
            url, title, duration_ms = service.resolve_preview_fallback(
                result
            )
        self.assertEqual(url, "https://example.test/itunes.m4a")
        self.assertIn("фрагмент 30 сек", title)
        self.assertEqual(duration_ms, 30_000)

    def test_playback_failure_reports_when_no_fallback_exists(self) -> None:
        result = track(
            "youtube",
            "Instant Crush",
            "Daft Punk",
            340_000,
            "https://example.test/watch",
        )
        service = MusicAggregatorService()
        with mock.patch.object(
            music_service, "http_json", return_value={"results": []}
        ):
            with self.assertRaises(RuntimeError):
                service.resolve_preview_fallback(result)

    def test_preview_marker_is_localized(self) -> None:
        from aurison import i18n

        result = track(
            "itunes",
            "Instant Crush",
            "Daft Punk",
            340_000,
            preview_only=True,
        )
        self.assertIn("фрагмент 30 сек", result.subtitle())
        i18n.set_language("en")
        try:
            self.assertIn("preview (30s)", result.subtitle())
        finally:
            i18n.set_language("ru")

    def test_stream_extraction_returns_direct_url(self) -> None:
        result = track(
            "youtube", "Song", "Artist", 200_000, "https://example.test/watch"
        )
        service = MusicAggregatorService()
        with mock.patch.object(
            service,
            "_extract_info",
            return_value={
                "title": "Song",
                "duration": 201,
                "url": "https://example.test/audio.m4a",
            },
        ), mock.patch.object(
            music_service, "_stream_available", return_value=True
        ):
            url, title, duration_ms = service.resolve_preview(result)
        self.assertEqual(url, "https://example.test/audio.m4a")
        self.assertEqual(title, "Song")
        self.assertEqual(duration_ms, 201_000)


class DownloadTest(unittest.TestCase):
    def setUp(self) -> None:
        self.folder = Path(tempfile.mkdtemp(prefix="aurison-service-dl-"))

    def test_preview_only_download_resolves_a_full_alternative(self) -> None:
        preview = track(
            "deezer",
            "Instant Crush",
            "Daft Punk",
            340_000,
            "https://example.test/deezer/preview",
            preview_only=True,
        )
        alternative = track(
            "youtube",
            "Daft Punk - Instant Crush",
            "Daft Punk",
            341_000,
            "https://example.test/yt/full",
        )
        service = MusicAggregatorService()
        calls: list[str] = []

        def fake_download(url: str, options: dict) -> None:
            calls.append(url)

        with mock.patch.object(
            service, "search", return_value=([alternative], [])
        ), mock.patch.object(service, "_download_url", fake_download):
            downloaded = service.download(preview, self.folder)

        self.assertEqual(downloaded, alternative)
        self.assertEqual(calls, ["https://example.test/yt/full"])

    def test_failed_download_falls_back_to_another_source(self) -> None:
        original = track(
            "youtube",
            "Daft Punk - Instant Crush",
            "Daft Punk",
            340_000,
            "https://example.test/yt/first",
        )
        alternative = track(
            "rutube",
            "Daft Punk - Instant Crush",
            "Daft Punk",
            339_000,
            "https://example.test/rutube/second",
        )
        service = MusicAggregatorService()
        calls: list[str] = []

        def fake_download(url: str, options: dict) -> None:
            calls.append(url)
            if url == original.url:
                raise RuntimeError("HTTP Error 403")

        with mock.patch.object(
            service, "search", return_value=([original, alternative], [])
        ), mock.patch.object(service, "_download_url", fake_download):
            downloaded = service.download(original, self.folder)

        self.assertEqual(downloaded, alternative)
        self.assertEqual(calls, [original.url, alternative.url])

    def test_download_retries_with_browser_cookies_after_403(self) -> None:
        service = MusicAggregatorService()
        attempts: list[dict] = []

        class FakeYoutubeDL:
            def __init__(self, options: dict) -> None:
                attempts.append(options)

            def __enter__(self):
                return self

            def __exit__(self, *args):
                return False

            def download(self, urls: list[str]) -> None:
                if "cookiesfrombrowser" not in attempts[-1]:
                    raise RuntimeError("HTTP Error 403: Forbidden")

        with mock.patch.object(
            music_service, "yt_dlp", mock.Mock(YoutubeDL=FakeYoutubeDL)
        ), mock.patch.object(music_service.time, "sleep") as sleep:
            service._download_url("https://example.test/video", {"quiet": True})

        self.assertEqual(len(attempts), 2)
        self.assertNotIn("cookiesfrombrowser", attempts[0])
        self.assertIn("cookiesfrombrowser", attempts[1])
        sleep.assert_called_once()

    def test_non_retryable_download_error_is_not_repeated(self) -> None:
        service = MusicAggregatorService()
        attempts: list[dict] = []

        class FakeYoutubeDL:
            def __init__(self, options: dict) -> None:
                attempts.append(options)

            def __enter__(self):
                return self

            def __exit__(self, *args):
                return False

            def download(self, urls: list[str]) -> None:
                raise RuntimeError("This video is unavailable")

        with mock.patch.object(
            music_service, "yt_dlp", mock.Mock(YoutubeDL=FakeYoutubeDL)
        ):
            with self.assertRaises(RuntimeError):
                service._download_url(
                    "https://example.test/video", {"quiet": True}
                )
        self.assertEqual(len(attempts), 1)

    def test_cookie_browser_defaults_and_override(self) -> None:
        with mock.patch.dict(os.environ, {}, clear=False):
            os.environ.pop("AURISON_COOKIE_BROWSER", None)
            self.assertEqual(cookie_options(), {"cookiesfrombrowser": ("edge",)})
            os.environ["AURISON_COOKIE_BROWSER"] = "chrome"
            self.assertEqual(
                cookie_options(), {"cookiesfrombrowser": ("chrome",)}
            )


class YouTubeInstancesTest(unittest.TestCase):
    def setUp(self) -> None:
        music_service._reset_instance_cache()

    def tearDown(self) -> None:
        music_service._reset_instance_cache()

    def test_invidious_search_returns_direct_audio_proxy(self) -> None:
        payload = [
            {
                "videoId": "a5uQMwRMHcs",
                "title": "Daft Punk - Instant Crush",
                "lengthSeconds": 340,
                "author": "Daft Punk",
            }
        ]
        with mock.patch.object(
            music_service, "INVIDIOUS_INSTANCES", ("https://inv.test",)
        ), mock.patch.object(
            music_service, "PIPED_INSTANCES", ()
        ), mock.patch.object(
            music_service, "http_json", return_value=payload
        ):
            results = music_service._search_youtube_tracks("instant crush", 5, 10)

        self.assertEqual(len(results), 1)
        result = results[0]
        self.assertEqual(result.source, "youtube")
        self.assertEqual(result.duration_ms, 340_000)
        self.assertEqual(
            result.stream_url,
            "https://inv.test/latest_version?id=a5uQMwRMHcs"
            "&itag=140&local=true",
        )
        self.assertEqual(result.download_url, result.stream_url)

    def test_piped_is_used_when_invidious_has_no_results(self) -> None:
        def fake_json(url: str, timeout: int = 20):
            if "invidious.test" in url:
                return []
            return {
                "items": [
                    {
                        "url": "/watch?v=jNQXAC9IVRw",
                        "title": "Me at the zoo",
                        "uploaderName": "jawed",
                        "duration": 200,
                    }
                ]
            }

        with mock.patch.object(
            music_service, "INVIDIOUS_INSTANCES", ("https://invidious.test",)
        ), mock.patch.object(
            music_service, "PIPED_INSTANCES", ("https://piped.test",)
        ), mock.patch.object(
            music_service, "http_json", side_effect=fake_json
        ):
            results = music_service._search_youtube_tracks("zoo", 5, 10)

        self.assertEqual(len(results), 1)
        self.assertEqual(results[0].provider, "piped")
        self.assertEqual(results[0].url, "https://www.youtube.com/watch?v=jNQXAC9IVRw")

    def test_empty_instance_answer_does_not_fall_back_to_ytdlp(self) -> None:
        with mock.patch.object(
            music_service, "INVIDIOUS_INSTANCES", ("https://inv.test",)
        ), mock.patch.object(
            music_service, "PIPED_INSTANCES", ()
        ), mock.patch.object(
            music_service, "http_json", return_value=[]
        ), mock.patch.object(
            music_service, "flat_extract"
        ) as ytdlp:
            results = music_service._search_youtube_tracks("nothing", 5, 10)
        self.assertEqual(results, [])
        ytdlp.assert_not_called()

    def test_piped_stream_audio_is_ranked_by_bitrate(self) -> None:
        payload = {
            "audioStreams": [
                {"url": "https://cdn.test/low", "bitrate": 64000},
                {"url": "https://cdn.test/high", "bitrate": 128000},
            ]
        }
        with mock.patch.object(
            music_service, "http_json", return_value=payload
        ):
            url = music_service._piped_audio_url("https://piped.test", "id")
        self.assertEqual(url, "https://cdn.test/high")

    def test_youtube_video_id_accepts_urls_and_ids(self) -> None:
        cases = {
            "https://www.youtube.com/watch?v=a5uQMwRMHcs": "a5uQMwRMHcs",
            "https://youtu.be/a5uQMwRMHcs?t=1": "a5uQMwRMHcs",
            "https://www.youtube.com/shorts/a5uQMwRMHcs": "a5uQMwRMHcs",
            "/watch?v=a5uQMwRMHcs": "a5uQMwRMHcs",
            "a5uQMwRMHcs": "a5uQMwRMHcs",
            "not a video!": "",
        }
        for value, expected in cases.items():
            self.assertEqual(
                music_service.youtube_video_id(value), expected, value
            )

    def test_preview_uses_invidious_url_without_ytdlp(self) -> None:
        result = SearchResult(
            "youtube",
            "Song",
            "Artist",
            200_000,
            "https://www.youtube.com/watch?v=a5uQMwRMHcs",
            stream_url="https://inv.test/audio.m4a",
        )
        service = MusicAggregatorService()
        with mock.patch.object(
            service, "_extract_info"
        ) as extract:
            url, title, duration_ms = service.resolve_preview(result)
        extract.assert_not_called()
        self.assertEqual(url, "https://inv.test/audio.m4a")
        self.assertEqual(title, "Song")
        self.assertEqual(duration_ms, 200_000)

    def test_playback_failure_refreshes_youtube_stream_first(self) -> None:
        result = SearchResult(
            "youtube",
            "Song",
            "Artist",
            200_000,
            "https://www.youtube.com/watch?v=a5uQMwRMHcs",
            stream_url="https://inv.test/stale.m4a",
        )
        service = MusicAggregatorService()
        with mock.patch.object(
            service,
            "_resolve_youtube_stream",
            return_value="https://inv.test/fresh.m4a",
        ) as resolver, mock.patch.object(
            service, "_extract_info"
        ) as extract:
            url, title, duration_ms = service.resolve_preview_fallback(result)
        resolver.assert_called_once_with(result, force_refresh=True)
        extract.assert_not_called()
        self.assertEqual(url, "https://inv.test/fresh.m4a")


class ExtraProvidersTest(unittest.TestCase):
    def test_vk_is_skipped_without_a_token(self) -> None:
        with mock.patch.dict(os.environ, {}, clear=False):
            os.environ.pop("AURISON_VK_TOKEN", None)
            self.assertEqual(
                music_service._search_vk("song", 5, 10), []
            )

    def test_vk_search_with_token(self) -> None:
        payload = {
            "response": {
                "items": [
                    {
                        "title": "Song",
                        "artist": "Artist",
                        "duration": 200,
                        "url": "https://vk.test/song.mp3",
                    }
                ]
            }
        }
        with mock.patch.dict(
            os.environ, {"AURISON_VK_TOKEN": "token"}
        ), mock.patch.object(
            music_service, "http_json", return_value=payload
        ):
            results = music_service._search_vk("song", 5, 10)
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0].stream_url, "https://vk.test/song.mp3")
        self.assertEqual(results[0].download_url, "https://vk.test/song.mp3")

    def test_audio_extension_prefers_content_type(self) -> None:
        self.assertEqual(
            music_service._audio_extension(
                "https://inv.test/latest_version?id=x", "audio/mp4"
            ),
            ".m4a",
        )
        self.assertEqual(
            music_service._audio_extension(
                "https://cdn.test/song.mp3", "application/octet-stream"
            ),
            ".mp3",
        )


class DirectDownloadTest(unittest.TestCase):
    def setUp(self) -> None:
        self.folder = Path(tempfile.mkdtemp(prefix="aurison-direct-dl-"))

    def test_youtube_download_uses_direct_stream_before_ytdlp(self) -> None:
        result = SearchResult(
            "youtube",
            "Daft Punk - Instant Crush",
            "Daft Punk",
            340_000,
            "https://www.youtube.com/watch?v=a5uQMwRMHcs",
            provider="invidious",
        )
        service = MusicAggregatorService()
        calls: list[str] = []

        def fake_direct(url, target, candidate, hook=None):
            calls.append(url)
            path = target / "song.m4a"
            path.write_bytes(b"audio")
            return path

        with mock.patch.object(
            service,
            "_resolve_youtube_stream",
            return_value="https://inv.test/audio.m4a",
        ), mock.patch.object(
            service, "_http_download", side_effect=fake_direct
        ), mock.patch.object(
            service, "_download_url"
        ) as ytdlp:
            downloaded = service.download(result, self.folder)

        self.assertEqual(downloaded, result)
        self.assertEqual(calls, ["https://inv.test/audio.m4a"])
        ytdlp.assert_not_called()

    def test_direct_download_failure_falls_back_to_ytdlp(self) -> None:
        result = SearchResult(
            "vk",
            "Song",
            "Artist",
            200_000,
            "https://vk.test/song",
            download_url="https://cdn.test/song.mp3",
        )
        service = MusicAggregatorService()
        with mock.patch.object(
            service,
            "_http_download",
            side_effect=RuntimeError("HTTP Error 403"),
        ), mock.patch.object(service, "_download_url") as ytdlp:
            service.download(result, self.folder)
        ytdlp.assert_called_once()


class CleanTrackTitleTest(unittest.TestCase):
    def test_drops_links_and_official_tags(self) -> None:
        self.assertEqual(
            music_service.clean_track_title(
                "Song (www.lightaudio.ru)"
            ),
            "Song",
        )
        self.assertEqual(
            music_service.clean_track_title(
                "Song (official video) [XBS0B_MyS]"
            ),
            "Song",
        )

    def test_keeps_version_tags(self) -> None:
        for raw in (
            "Song (Slowed + Reverb)",
            "Song [Super Slowed]",
            "Song (hardtekk)",
            "Song (Sped Up)",
            "Song (Nightcore)",
            "Song (Bass Boost)",
        ):
            self.assertEqual(music_service.clean_track_title(raw), raw)


class DownloadFileNameTest(unittest.TestCase):
    def test_lightaudio_domain_is_stripped_from_saved_file(self) -> None:
        body = b"ID3" + b"\x00" * 32

        class FakeResponse:
            def __init__(self) -> None:
                self._body = body
                self.headers = {
                    "Content-Type": "audio/mpeg",
                    "Content-Length": str(len(body)),
                    # The server's suggestion must never win.
                    "Content-Disposition": (
                        'attachment; filename="Track (www.lightaudio.ru).mp3"'
                    ),
                }

            def read(self, size: int = -1) -> bytes:
                chunk, self._body = self._body, b""
                return chunk

            def __enter__(self):
                return self

            def __exit__(self, *args) -> bool:
                return False

            def close(self) -> None:
                pass

        result = SearchResult(
            "lightaudio",
            "Track (www.lightaudio.ru)",
            "Artist",
            180_000,
            "https://web.ligaudio.ru/mp3/track.html",
        )
        with tempfile.TemporaryDirectory() as folder:
            with mock.patch(
                "aurison.music_service.urllib.request.urlopen",
                return_value=FakeResponse(),
            ):
                path = MusicAggregatorService()._http_download(
                    "https://storage.test/track.mp3",
                    Path(folder),
                    result,
                )
            self.assertEqual(path.name, "Track.mp3")
            self.assertTrue(path.is_file())


if __name__ == "__main__":
    unittest.main()
