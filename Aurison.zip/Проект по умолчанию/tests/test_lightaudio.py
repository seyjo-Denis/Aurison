"""Tests for the LightAudio provider.

The adapter talks to a real HTML page in production; these tests use saved
markup and mocked fetches so they never touch the network.
"""

from __future__ import annotations

import os
import tempfile
import unittest
from pathlib import Path
from unittest import mock

os.environ.setdefault(
    "AURISON_CONFIG_DIR", tempfile.mkdtemp(prefix="aurison-lightaudio-test-")
)

from aurison import music_service
from aurison.music_service import (
    LIGHTAUDIO_MAX_CONCURRENCY,
    LIGHTAUDIO_TIMEOUT,
    LightAudioError,
    MusicAggregatorService,
    SearchResult,
)

PAGE_URL = "https://web.ligaudio.ru/mp3/test%20query"

LIGHTAUDIO_HTML = """
<html><body><div id="result" itemscope
     itemtype="https://schema.org/MusicPlaylist">
  <meta itemprop="name" content="Test query" />
  <meta itemprop="numTracks" content="2" />
  <div class="item" id="id-aaa" itemprop="track" itemscope
       itemtype="http://schema.org/MusicRecording"><div>
    <a class="play" data-audio="//storage4.lightaudio.ru/a/b/Song.m3u8"
       title="Play"></a>
    <div class="title">
      <span class="title" itemprop="name">Song &amp; Dance</span>
      <i class="m"> &mdash; </i>
      <span class="autor" itemprop="byArtist">
        <a href="/mp3/artist">Artist</a>, <a href="/mp3/feat">Feat</a>
      </span>
    </div>
    <meta content="PT3M30S" itemprop="duration" />
    <span class="d">3:30</span>
    <a class="down" href="//storage4.lightaudio.ru/dm/a/b/Song.mp3?d=210&amp;v=abc"
       target="_blank" itemprop="url"></a>
  </div></div>
  <div class="item" id="id-bbb" itemprop="track" itemscope
       itemtype="http://schema.org/MusicRecording"><div>
    <div class="title">
      <span class="title" itemprop="name">Second Track</span>
      <span class="autor" itemprop="byArtist"><a>Other</a></span>
    </div>
    <span class="d">4:05</span>
    <a class="down" href="https://storage9.lightaudio.ru/dm/c/d/Second.mp3"
       itemprop="url"></a>
  </div></div>
  <div class="pagination"><a href="/mp3/test%20query">1</a></div>
</div></body></html>
"""

UPDATED_HTML = LIGHTAUDIO_HTML.replace(
    "https://storage9.lightaudio.ru/dm/c/d/Second.mp3",
    "https://storage9.lightaudio.ru/dm/c/d/Second.mp3?d=999&v=fresh",
)


def track(source: str, title: str = "Song") -> SearchResult:
    return SearchResult(
        source=source,
        title=title,
        uploader="Artist",
        duration_ms=200_000,
        url=f"https://example.test/{source}/{title}",
    )


class LightAudioParserTest(unittest.TestCase):
    def test_parses_titles_artists_durations_and_urls(self) -> None:
        results = music_service._parse_lightaudio_items(
            LIGHTAUDIO_HTML, PAGE_URL
        )

        self.assertEqual(len(results), 2)
        first = results[0]
        self.assertEqual(first.source, "lightaudio")
        self.assertEqual(first.source_name, "LightAudio")
        self.assertEqual(first.title, "Song & Dance")
        self.assertEqual(first.artist, "Artist, Feat")
        self.assertEqual(first.duration, 210_000)
        self.assertEqual(
            first.stream_url,
            "https://storage4.lightaudio.ru/dm/a/b/Song.mp3?d=210&v=abc",
        )
        self.assertEqual(first.stream_url, first.download_url)
        self.assertEqual(first.url, f"{PAGE_URL}#id-aaa")

        second = results[1]
        self.assertEqual(second.title, "Second Track")
        self.assertEqual(second.uploader, "Other")
        # No ISO duration in this block: the visible clock is used.
        self.assertEqual(second.duration_ms, 245_000)
        self.assertEqual(
            second.download_url,
            "https://storage9.lightaudio.ru/dm/c/d/Second.mp3",
        )
        self.assertEqual(second.url, f"{PAGE_URL}#id-bbb")

    def test_iso_and_clock_durations(self) -> None:
        self.assertEqual(music_service._parse_iso_duration("PT3M30S"), 210_000)
        self.assertEqual(
            music_service._parse_iso_duration("PT1H2M3S"), 3_723_000
        )
        self.assertEqual(music_service._parse_iso_duration("3:30"), 0)
        self.assertEqual(music_service._parse_clock("4:05"), 245_000)

    def test_lightaudio_limits_are_modest(self) -> None:
        self.assertGreaterEqual(LIGHTAUDIO_TIMEOUT, 10)
        self.assertLessEqual(LIGHTAUDIO_TIMEOUT, 15)
        self.assertGreaterEqual(LIGHTAUDIO_MAX_CONCURRENCY, 1)
        self.assertLessEqual(LIGHTAUDIO_MAX_CONCURRENCY, 2)


class LightAudioSearchTest(unittest.TestCase):
    def test_dispatch_uses_the_lightaudio_search_adapter(self) -> None:
        expected = [track("lightaudio")]
        with mock.patch.object(
            music_service, "_search_lightaudio", return_value=expected
        ) as adapter:
            results = music_service.search_tracks("lightaudio", "query", 5)
        adapter.assert_called_once_with("query", 5)
        self.assertEqual(results, expected)

    def test_search_returns_direct_lightaudio_results(self) -> None:
        with mock.patch.object(
            music_service,
            "_lightaudio_fetch",
            return_value=LIGHTAUDIO_HTML,
        ) as fetch:
            results = music_service._search_lightaudio("test query", 10)

        fetch.assert_called_once_with(
            "https://web.ligaudio.ru/mp3/test%20query"
        )
        self.assertEqual([item.title for item in results], [
            "Song & Dance",
            "Second Track",
        ])
        self.assertTrue(all(item.download_url for item in results))
        self.assertTrue(all(not item.preview_only for item in results))

    def test_valid_empty_result_page_is_not_an_error(self) -> None:
        empty = '<div id="result"><meta itemprop="numTracks" content="0" /></div>'
        with mock.patch.object(
            music_service, "_lightaudio_fetch", return_value=empty
        ):
            self.assertEqual(music_service._search_lightaudio("x", 10), [])

    def test_captcha_page_raises_a_clear_error(self) -> None:
        blocked = "<html><body>Подтвердите, что вы не робот: captcha</body></html>"
        with mock.patch.object(
            music_service, "_lightaudio_fetch", return_value=blocked
        ):
            with self.assertRaises(LightAudioError) as caught:
                music_service._search_lightaudio("x", 10)
        self.assertIn("LightAudio", str(caught.exception))
        self.assertIn("капча", str(caught.exception))

    def test_unexpected_html_raises_instead_of_silently_returning_empty(
        self,
    ) -> None:
        with mock.patch.object(
            music_service,
            "_lightaudio_fetch",
            return_value="<html><body>maintenance</body></html>",
        ):
            with self.assertRaises(LightAudioError) as caught:
                music_service._search_lightaudio("x", 10)
        self.assertIn("неожиданный ответ", str(caught.exception))

    def test_http_block_is_reported_with_a_status_code(self) -> None:
        import urllib.error

        error = urllib.error.HTTPError(
            PAGE_URL, 429, "Too Many Requests", {}, None
        )
        try:
            with mock.patch.object(
                music_service, "http_text", side_effect=error
            ):
                with self.assertRaises(LightAudioError) as caught:
                    music_service._lightaudio_fetch(PAGE_URL)
        finally:
            error.close()
        self.assertIn("HTTP 429", str(caught.exception))

    def test_failure_does_not_break_other_providers(self) -> None:
        healthy = track("youtube", "Healthy")

        def fake_search(source: str, query: str, limit: int):
            if source == "lightaudio":
                raise LightAudioError("LightAudio недоступен (HTTP 503).")
            if source == "youtube":
                return [healthy]
            return []

        with mock.patch.object(
            music_service, "search_tracks", fake_search
        ):
            report = MusicAggregatorService().search_report(
                "query", "tracks", 10, ["lightaudio", "youtube"]
            )

        self.assertEqual(report.results, [healthy])
        self.assertTrue(report.any_success)
        self.assertEqual(report.providers["youtube"].status, "ok")
        self.assertEqual(
            report.providers["lightaudio"].status, "unavailable"
        )
        self.assertEqual(len(report.errors), 1)
        self.assertIn("LightAudio", report.errors[0])
        self.assertNotIn("LightAudio: LightAudio", report.errors[0])

    def test_only_lightaudio_failure_is_not_an_empty_success(self) -> None:
        def fake_search(source: str, query: str, limit: int):
            raise LightAudioError("LightAudio недоступен (HTTP 503).")

        with mock.patch.object(
            music_service, "search_tracks", fake_search
        ):
            report = MusicAggregatorService().search_report(
                "query", "tracks", 10, ["lightaudio"]
            )

        self.assertEqual(report.results, [])
        self.assertFalse(report.any_success)
        self.assertEqual(report.errors, ["LightAudio недоступен (HTTP 503)."])


class LightAudioPlaybackTest(unittest.TestCase):
    def test_expired_url_is_refreshed_from_the_saved_results_page(self) -> None:
        original = SearchResult(
            source="lightaudio",
            title="Second Track",
            uploader="Other",
            duration_ms=245_000,
            url=f"{PAGE_URL}#id-bbb",
            stream_url="https://storage9.lightaudio.ru/dm/c/d/Second.mp3",
            download_url="https://storage9.lightaudio.ru/dm/c/d/Second.mp3",
            provider="lightaudio",
        )

        with mock.patch.object(
            music_service, "_lightaudio_fetch", return_value=UPDATED_HTML
        ) as fetch, mock.patch.object(
            music_service, "search_tracks"
        ) as search:
            url, title, duration = (
                MusicAggregatorService().resolve_preview_fallback(original)
            )

        self.assertEqual(
            url,
            "https://storage9.lightaudio.ru/dm/c/d/Second.mp3?d=999&v=fresh",
        )
        self.assertEqual(title, "Second Track")
        self.assertEqual(duration, 245_000)
        self.assertEqual(original.download_url, url)
        fetch.assert_called_once_with(PAGE_URL)
        search.assert_not_called()


class LightAudioDownloadTest(unittest.TestCase):
    def test_download_uses_plain_http_and_never_ytdlp(self) -> None:
        result = SearchResult(
            source="lightaudio",
            title="Song",
            uploader="Artist",
            duration_ms=210_000,
            url=f"{PAGE_URL}#id-aaa",
            stream_url="https://storage4.lightaudio.ru/dm/a/b/Song.mp3",
            download_url="https://storage4.lightaudio.ru/dm/a/b/Song.mp3",
            provider="lightaudio",
        )
        folder = Path(tempfile.mkdtemp(prefix="aurison-lightaudio-dl-"))

        with mock.patch.object(
            MusicAggregatorService,
            "_http_download",
            return_value=folder / "Song.mp3",
        ) as http_download, mock.patch.object(
            MusicAggregatorService, "_download_url"
        ) as ytdlp_download:
            downloaded = MusicAggregatorService().download(result, folder)

        self.assertIs(downloaded, result)
        http_download.assert_called_once()
        ytdlp_download.assert_not_called()

    def test_expired_download_link_is_refreshed_and_retried(self) -> None:
        result = SearchResult(
            source="lightaudio",
            title="Second Track",
            uploader="Other",
            duration_ms=245_000,
            url=f"{PAGE_URL}#id-bbb",
            stream_url="https://storage9.lightaudio.ru/dm/c/d/Second.mp3",
            download_url="https://storage9.lightaudio.ru/dm/c/d/Second.mp3",
            provider="lightaudio",
        )
        folder = Path(tempfile.mkdtemp(prefix="aurison-lightaudio-retry-"))
        seen: list[str] = []
        fresh = "https://storage9.lightaudio.ru/dm/c/d/Second.mp3?d=999&v=fresh"

        def fake_http(url, target, candidate, progress_hook=None):
            seen.append(url)
            if len(seen) == 1:
                raise RuntimeError("HTTP 403")
            return folder / "Second.mp3"

        with mock.patch.object(
            MusicAggregatorService, "_http_download", side_effect=fake_http
        ), mock.patch.object(
            music_service, "_lightaudio_fetch", return_value=UPDATED_HTML
        ), mock.patch.object(
            MusicAggregatorService, "_download_url"
        ) as ytdlp_download:
            downloaded = MusicAggregatorService().download(result, folder)

        self.assertIs(downloaded, result)
        self.assertEqual(
            seen,
            [
                "https://storage9.lightaudio.ru/dm/c/d/Second.mp3",
                fresh,
            ],
        )
        self.assertEqual(result.download_url, fresh)
        ytdlp_download.assert_not_called()


if __name__ == "__main__":
    unittest.main()
