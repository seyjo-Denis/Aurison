"""Online orchestration tests that need a real (offscreen) main window."""

from __future__ import annotations

import os
import tempfile
import types
import unittest
from unittest import mock

os.environ.setdefault(
    "AURISON_CONFIG_DIR", tempfile.mkdtemp(prefix="aurison-online-flow-test-")
)
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from PySide6.QtWidgets import QApplication

from aurison.config import Config
from aurison.main_window import MainWindow
from aurison.music_service import SearchResult


class PreviewPlaybackFallbackTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.app = QApplication.instance() or QApplication([])

    def test_player_error_starts_one_fallback_worker(self) -> None:
        config = Config()
        window = MainWindow(config, enable_hotkeys=False)
        window.show()
        window._set_online_mode(True, persist=False)
        started: list[tuple] = []

        class FakeWorker:
            def __init__(
                self,
                generation,
                result,
                parent=None,
                fallback=False,
            ) -> None:
                started.append((generation, result, fallback))
                self.previewReady = types.SimpleNamespace(connect=lambda fn: None)
                self.previewFailed = types.SimpleNamespace(connect=lambda fn: None)
                self.finished = types.SimpleNamespace(connect=lambda fn: None)
                self._running = True

            def start(self) -> None:
                pass

            def isRunning(self) -> bool:
                return self._running

            def cancel(self) -> None:
                self._running = False

        result = SearchResult(
            "youtube",
            "Song",
            "Artist",
            200_000,
            "https://example.test/watch",
        )
        try:
            window._preview_result = result
            window._preview_fallback_used = False
            window.playback.prepare_preview(
                "https://example.test/stream", "Song", 200_000
            )
            with mock.patch(
                "aurison.main_window.PreviewWorker", FakeWorker
            ):
                window._on_playback_error("Could not open file")

            self.assertEqual(len(started), 1)
            self.assertIs(started[0][1], result)
            self.assertTrue(started[0][2])
            self.assertTrue(window._preview_fallback_used)
            self.assertFalse(window.playback.is_previewing())
        finally:
            window.close()
            self.app.processEvents()


class FilteredSearchFlowTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.app = QApplication.instance() or QApplication([])

    def test_main_window_uses_only_enabled_sources(self) -> None:
        config = Config()
        config.online_sources = ["rutube", "lightaudio"]
        window = MainWindow(config, enable_hotkeys=False)
        window.show()
        window._set_online_mode(True, persist=False)
        started: list[tuple] = []

        class FakeSearchWorker:
            def __init__(
                self,
                generation,
                query,
                scope,
                parent=None,
                sources=None,
            ) -> None:
                started.append((query, scope, list(sources or [])))
                self.finishedSearchDetailed = types.SimpleNamespace(
                    connect=lambda fn: None
                )
                self.finished = types.SimpleNamespace(
                    connect=lambda fn: None
                )
                self._running = True

            def start(self) -> None:
                pass

            def isRunning(self) -> bool:
                return self._running

            def cancel(self) -> None:
                self._running = False

        try:
            self.assertEqual(
                window.online_view.selected_sources(),
                ["rutube", "lightaudio"],
            )
            with mock.patch(
                "aurison.main_window.SearchWorker", FakeSearchWorker
            ):
                window._start_online_search("query", "tracks")
            self.assertEqual(started[0][0], "query")
            self.assertEqual(started[0][1], "tracks")
            self.assertEqual(started[0][2], ["rutube", "lightaudio"])

            window._on_online_sources_changed(["youtube"])
            self.assertEqual(config.online_sources, ["youtube"])
        finally:
            window.close()
            self.app.processEvents()


class StartupModeTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.app = QApplication.instance() or QApplication([])

    def test_starts_offline_even_when_online_was_saved(self) -> None:
        config = Config()
        config.online_mode = True
        window = MainWindow(config, enable_hotkeys=False)
        window.show()
        try:
            self.assertFalse(window._online_mode)
            self.assertFalse(window.config.online_mode)
            self.assertIsNot(
                window.stack.currentWidget(), window.online_view
            )
        finally:
            window.close()
            self.app.processEvents()


if __name__ == "__main__":
    unittest.main()
