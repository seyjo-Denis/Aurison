"""One basic test for the Hitmo HTML parser."""

from __future__ import annotations

import os
import tempfile
import unittest

os.environ.setdefault(
    "AURISON_CONFIG_DIR", tempfile.mkdtemp(prefix="aurison-hitmo-test-")
)

from aurison import music_service


HITMO_HTML = """
<ul class="tracks__list">
  <li class="tracks__item track mustoggler"
      data-musmeta='{"artist":"Paul Martinez","title":"The Way","url":"/get/music/1/The_Way.mp3","id":"track-id-1"}'>
    <div class="track__info">
      <div class="track__title">The Way</div>
      <div class="track__desc">Paul Martinez</div>
      <div class="track__info-r">
        <div class="track__time">
          <div class="track__fulltime">3:45</div>
        </div>
        <a href="/get/music/1/The_Way.mp3" class="track__download-btn"></a>
      </div>
    </div>
  </li>
</ul>
"""


class HitmoParserTest(unittest.TestCase):
    def test_parses_title_artist_duration_and_mp3_url(self) -> None:
        results = music_service._parse_hitmo_items(
            HITMO_HTML, "https://ru.hitmox.net"
        )

        self.assertEqual(len(results), 1)
        track = results[0]
        self.assertEqual(track.source, "hitmo")
        self.assertEqual(track.source_name, "Hitmo")
        self.assertEqual(track.title, "The Way")
        self.assertEqual(track.uploader, "Paul Martinez")
        self.assertEqual(track.duration_ms, 225_000)
        self.assertEqual(
            track.download_url,
            "https://ru.hitmox.net/get/music/1/The_Way.mp3",
        )
        self.assertEqual(track.stream_url, track.download_url)


if __name__ == "__main__":
    unittest.main()
