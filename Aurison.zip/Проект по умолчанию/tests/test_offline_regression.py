"""Regression checks for the offline player.

The online refactor must not change local scanning, caching, configuration or
queue playback.  These checks exercise exactly those paths and verify that the
offline modules never import the online backend.
"""

from __future__ import annotations

import os
import struct
import subprocess
import sys
import tempfile
import time
import unittest
import wave
from pathlib import Path

os.environ.setdefault(
    "AURISON_CONFIG_DIR", tempfile.mkdtemp(prefix="aurison-offline-test-")
)
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication

from aurison.config import Config, config_dir
from aurison.library import Track, TrackCache, scan_folder
from aurison.main_window import MainWindow
from aurison.player import PlaybackController

ROOT = Path(__file__).resolve().parent.parent


def make_wav(path: Path, seconds: float = 1.0) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    frames = int(8000 * seconds)
    with wave.open(str(path), "wb") as handle:
        handle.setnchannels(1)
        handle.setsampwidth(2)
        handle.setframerate(8000)
        handle.writeframes(
            b"".join(struct.pack("<h", 0) for _ in range(frames))
        )


def wait_until(predicate, timeout_ms: int = 8000) -> bool:
    deadline = time.monotonic() + timeout_ms / 1000
    while time.monotonic() < deadline:
        QApplication.processEvents()
        if predicate():
            return True
        QTest.qWait(25)
    return predicate()


class OfflineLibraryTest(unittest.TestCase):
    def test_scan_folder_finds_audio_and_ignores_noise(self) -> None:
        folder = Path(tempfile.mkdtemp(prefix="aurison-offline-scan-"))
        make_wav(folder / "02 - Beta.wav")
        make_wav(folder / "01 - Alpha.wav")
        make_wav(folder / "nested" / "03 - Gamma.wav")
        (folder / ".hidden.wav").write_bytes(b"not audio")
        (folder / "notes.txt").write_text("text", encoding="utf-8")

        tracks, updates = scan_folder(str(folder), {})

        self.assertEqual(
            [Path(track.path).stem for track in tracks],
            ["01 - Alpha", "02 - Beta", "03 - Gamma"],
        )
        self.assertEqual(len(updates), 3)
        self.assertTrue(all(entry["duration_verified"] is False for entry in updates.values()))

    def test_cache_snapshot_reuses_verified_duration(self) -> None:
        folder = Path(tempfile.mkdtemp(prefix="aurison-offline-cache-"))
        make_wav(folder / "Song.wav")
        first, updates = scan_folder(str(folder), {})

        entry = next(iter(updates.values()))
        entry["duration"] = 61_000
        entry["duration_verified"] = True
        cached = {first[0].path: entry}

        second, new_updates = scan_folder(str(folder), cached)
        self.assertEqual(second[0].duration_ms, 61_000)
        self.assertEqual(new_updates, {})

    def test_track_cache_roundtrip(self) -> None:
        cache = TrackCache()
        cache.entries.clear()
        cache.entries["C:/music/song.mp3"] = {
            "mtime": 1.0,
            "size": 42,
            "title": "Song",
            "duration": 120_000,
            "duration_verified": True,
        }
        cache.save()

        restored = TrackCache()
        self.assertEqual(
            restored.entries["C:/music/song.mp3"]["title"], "Song"
        )
        self.assertTrue(
            restored.entries["C:/music/song.mp3"]["duration_verified"]
        )

    def test_config_roundtrip_keeps_offline_settings(self) -> None:
        path = config_dir() / "config.json"
        path.unlink(missing_ok=True)
        cfg = Config()
        cfg.folders = [r"C:\Music"]
        cfg.selected_folder = r"C:\Music"
        cfg.volume = 55
        cfg.shuffle = True
        cfg.repeat_one = True
        cfg.track_order = {r"C:\Music": [r"C:\Music\b.mp3", r"C:\Music\a.mp3"]}
        cfg.language = "en"
        cfg.save()

        loaded = Config.load()
        self.assertEqual(loaded.folders, [r"C:\Music"])
        self.assertEqual(loaded.selected_folder, r"C:\Music")
        self.assertEqual(loaded.volume, 55)
        self.assertTrue(loaded.shuffle)
        self.assertTrue(loaded.repeat_one)
        self.assertEqual(
            loaded.track_order[r"C:\Music"],
            [r"C:\Music\b.mp3", r"C:\Music\a.mp3"],
        )
        self.assertEqual(loaded.language, "en")


    def test_lightaudio_selection_does_not_change_offline_settings(self) -> None:
        path = config_dir() / "config.json"
        path.unlink(missing_ok=True)
        cfg = Config()
        cfg.folders = [r"C:\Music"]
        cfg.selected_folder = r"C:\Music"
        cfg.volume = 37
        cfg.online_mode = False
        cfg.online_sources = ["lightaudio"]
        cfg.save()

        loaded = Config.load()
        self.assertEqual(loaded.online_sources, ["lightaudio"])
        self.assertEqual(loaded.folders, [r"C:\Music"])
        self.assertEqual(loaded.selected_folder, r"C:\Music")
        self.assertEqual(loaded.volume, 37)
        self.assertFalse(loaded.online_mode)


class OfflinePlayerTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.app = QApplication.instance() or QApplication([])

    def test_queue_navigation_volume_and_preview_state(self) -> None:
        folder = Path(tempfile.mkdtemp(prefix="aurison-offline-queue-"))
        paths = []
        for index in range(3):
            path = folder / f"{index}.wav"
            make_wav(path)
            paths.append(path)
        tracks = [
            Track(str(path), f"Track {index}", 1000)
            for index, path in enumerate(paths)
        ]

        player = PlaybackController()
        player.play_queue(tracks, 0)
        self.assertEqual(player.current_track, tracks[0])
        self.assertEqual(player.current_index, 0)
        self.assertFalse(player.is_previewing())

        player.next_track()
        self.assertEqual(player.current_track, tracks[1])
        player.previous_track()
        self.assertEqual(player.current_track, tracks[0])

        player.set_volume(55)
        self.assertEqual(player.volume(), 55)
        player.set_muted(True)
        self.assertTrue(player.is_muted())
        player.set_volume(0)
        self.assertEqual(player.volume(), 0)

        player.apply_order(
            [tracks[2].path, tracks[0].path, tracks[1].path]
        )
        self.assertEqual(player.queue, [tracks[2], tracks[0], tracks[1]])
        self.assertEqual(player.current_track, tracks[0])

        player.prepare_preview("https://example.test/stream", "Remote", 30_000)
        self.assertTrue(player.is_previewing())
        self.assertEqual(player.current_track.title, "Remote")
        self.assertEqual(player.queue, [])
        player.stop_preview()
        self.assertFalse(player.is_previewing())
        self.assertIsNone(player.current_track)

        # Local playback still works after an online preview was stopped.
        player.play_queue(tracks, 2)
        self.assertEqual(player.current_track, tracks[2])
        player.stop()


class OfflineWindowTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.app = QApplication.instance() or QApplication([])

    def test_offline_window_scans_and_plays_without_online_backend(self) -> None:
        folder = Path(tempfile.mkdtemp(prefix="aurison-offline-window-"))
        make_wav(folder / "01 - Alpha.wav")
        make_wav(folder / "02 - Beta.wav")

        config = Config()
        config.folders = [str(folder)]
        config.selected_folder = str(folder)
        config.online_mode = False
        config.online_sources = ["rutube"]
        config.language = "ru"

        window = MainWindow(config, enable_hotkeys=False)
        window.show()
        try:
            self.assertTrue(
                wait_until(lambda: not window._scan_threads, 10_000),
                "offline scan did not finish",
            )
            self.assertIn(str(folder), window._scanned)
            self.assertIs(window.stack.currentWidget(), window.table)
            self.assertEqual(window.table.rowCount(), 2)
            self.assertIsNone(window._search_thread)
            self.assertEqual(
                window.online_view.selected_sources(), ["rutube"]
            )

            window._play_row(0)
            self.assertIsNotNone(window.playback.current_track)
            self.assertFalse(window.playback.is_previewing())
            self.assertFalse(window.config.online_mode)
        finally:
            window.playback.stop()
            window.close()
            wait_until(lambda: not window._scan_threads, 3000)

    def test_offline_search_handles_typos(self) -> None:
        folder = Path(tempfile.mkdtemp(prefix="aurison-offline-search-"))
        make_wav(folder / "01 - Alpha.wav")
        make_wav(folder / "02 - Beta.wav")
        make_wav(folder / "03 - Bravo.wav")

        config = Config()
        config.folders = [str(folder)]
        config.selected_folder = str(folder)
        config.online_mode = False
        config.language = "ru"

        window = MainWindow(config, enable_hotkeys=False)
        window.show()
        try:
            self.assertTrue(
                wait_until(lambda: not window._scan_threads, 10_000),
                "offline scan did not finish",
            )
            self.assertEqual(window.table.rowCount(), 3)

            # Exact substring match wins.
            window.search_input.setText("et")
            window.search_button.click()
            row = window.table.highlight_row_index()
            self.assertEqual(window.table.item(row, 1).text(), "02 - Beta")

            # A typo is still found through difflib.
            window.search_input.setText("brvvo")
            window.search_button.click()
            row = window.table.highlight_row_index()
            self.assertEqual(window.table.item(row, 1).text(), "03 - Bravo")

            # A miss changes nothing and keeps the previous hit highlighted.
            window.search_input.setText("zzzzzzzz")
            window.search_button.click()
            self.assertEqual(row, window.table.highlight_row_index())
        finally:
            window.playback.stop()
            window.close()
            wait_until(lambda: not window._scan_threads, 3000)

    def test_offline_modules_do_not_import_online_backend(self) -> None:
        code = (
            "import sys\n"
            "import aurison.library, aurison.player, aurison.config\n"
            "assert 'aurison.online' not in sys.modules, 'online imported'\n"
            "assert 'aurison.music_service' not in sys.modules, "
            "'music_service imported'\n"
        )
        env = dict(os.environ)
        env["PYTHONPATH"] = str(ROOT)
        env["QT_QPA_PLATFORM"] = "offscreen"
        result = subprocess.run(
            [sys.executable, "-c", code],
            cwd=str(ROOT),
            env=env,
            capture_output=True,
            text=True,
        )
        self.assertEqual(
            result.returncode,
            0,
            f"offline imports pulled in the online backend:\n"
            f"{result.stdout}\n{result.stderr}",
        )


if __name__ == "__main__":
    unittest.main()
