from __future__ import annotations

import ctypes
import sys

from PySide6.QtGui import QColor, QFont, QPalette
from PySide6.QtWidgets import QApplication

from aurison.config import Config, config_dir
from aurison.i18n import set_language, tr
from aurison.icons import app_icon
from aurison.main_window import MainWindow
from aurison.theme import STYLESHEET


def _set_windows_app_id() -> None:
    if sys.platform != "win32":
        return
    try:
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(
            "Aurison.MusicPlayer.1"
        )
    except Exception:
        pass


def _dark_palette() -> QPalette:
    palette = QPalette()
    colors = {
        QPalette.ColorRole.Window: "#0f1013",
        QPalette.ColorRole.WindowText: "#e7e9ee",
        QPalette.ColorRole.Base: "#141519",
        QPalette.ColorRole.AlternateBase: "#181a1f",
        QPalette.ColorRole.Text: "#e7e9ee",
        QPalette.ColorRole.Button: "#1d2026",
        QPalette.ColorRole.ButtonText: "#e7e9ee",
        QPalette.ColorRole.ToolTipBase: "#1c1f25",
        QPalette.ColorRole.ToolTipText: "#e7e9ee",
        QPalette.ColorRole.Highlight: "#2b303b",
        QPalette.ColorRole.HighlightedText: "#ffffff",
        QPalette.ColorRole.PlaceholderText: "#6f7580",
        QPalette.ColorRole.Link: "#9db4ff",
    }
    for role, value in colors.items():
        palette.setColor(role, QColor(value))
    for role in (
        QPalette.ColorRole.WindowText,
        QPalette.ColorRole.Text,
        QPalette.ColorRole.ButtonText,
    ):
        palette.setColor(
            QPalette.ColorGroup.Disabled, role, QColor("#5c616b")
        )
    return palette


def _run() -> int:
    _set_windows_app_id()
    app = QApplication(sys.argv)
    app.setApplicationName("Aurison")
    app.setApplicationDisplayName("Aurison")
    app.setOrganizationName("Aurison")
    app.setStyle("Fusion")
    app.setPalette(_dark_palette())
    app.setFont(QFont("Segoe UI", 10))
    app.setWindowIcon(app_icon())
    app.setStyleSheet(STYLESHEET)

    config = Config.load()
    set_language(config.language)
    window = MainWindow(config)
    window.show()
    return app.exec()


def main() -> int:
    try:
        return _run()
    except Exception:
        import traceback

        details = traceback.format_exc()
        log_path = None
        try:
            log_path = config_dir() / "error.log"
            log_path.write_text(details, encoding="utf-8")
        except OSError:
            pass
        message = tr("Не удалось запустить Aurison.")
        if log_path is not None:
            message += "\n\n" + tr("Подробности: {path}").format(path=log_path)
        try:
            ctypes.windll.user32.MessageBoxW(
                None, message, "Aurison", 0x10
            )
        except Exception:
            pass
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
