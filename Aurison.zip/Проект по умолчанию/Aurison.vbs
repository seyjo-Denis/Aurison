Option Explicit

Dim shell, fso, basePath
Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")

basePath = fso.GetParentFolderName(WScript.ScriptFullName)
shell.CurrentDirectory = basePath

On Error Resume Next
shell.Run Chr(34) & basePath & "\run.bat" & Chr(34), 0, False
If Err.Number <> 0 Then
    MsgBox "Could not start Aurison." & vbCrLf & _
           "Make sure Python is installed and pythonw.exe is available in PATH.", _
           16, "Aurison"
End If
