"""Tiny runtime translation layer for the Aurison player.

Russian is the source language: every user-facing string is written in
Russian and passed through :func:`tr`.  When the active language is English
the string is looked up in :data:`TRANSLATIONS`; unknown strings fall back to
the Russian original so a missing entry never breaks the UI.
"""

from __future__ import annotations

DEFAULT_LANGUAGE = "ru"
SUPPORTED_LANGUAGES = ("ru", "en")

_language = DEFAULT_LANGUAGE

TRANSLATIONS: dict[str, str] = {
    # Player bar / transport
    "Ничего не играет": "Nothing playing",
    "Воспроизведение": "Play",
    "Пауза": "Pause",
    "На паузе": "Paused",
    "Остановлен": "Stopped",
    "Играет": "Playing",
    "Предыдущий трек": "Previous track",
    "Следующий трек": "Next track",
    "Случайный порядок": "Shuffle",
    "Повтор одного трека": "Repeat one track",
    "Выключить звук": "Mute",
    "Включить звук": "Unmute",
    "Громкость": "Volume",
    "Не удалось воспроизвести файл": "Could not play file",
    "Перетащите, чтобы изменить порядок": "Drag to reorder",
    "Выход": "Quit",
    "Развернуть плеер": "Expand player",

    # Main window
    "Aurison — MP3-плеер": "Aurison — MP3 player",
    "Настройки (Ctrl+,)": "Settings (Ctrl+,)",
    "БИБЛИОТЕКА": "LIBRARY",
    "Обзор": "Browse",
    "Выбрать папку с музыкой": "Choose a music folder",
    "Обновить все папки и треки": "Refresh all folders and tracks",
    "Все треки": "All tracks",
    "ПАПКИ": "FOLDERS",
    "Правый клик по папке — удалить": "Right-click a folder to remove it",
    "Выберите папку с музыкой": "Choose a music folder",
    "Папка не найдена": "Folder not found",
    "Выбранная папка не существует или недоступна.": (
        "The selected folder does not exist or is unavailable."
    ),
    "Открыть в Проводнике": "Open in Explorer",
    "Обновить папку": "Refresh folder",
    "Удалить из библиотеки": "Remove from library",
    "Воспроизвести": "Play",
    "Открыть папку с файлом": "Open file location",
    "Переименовать": "Rename",
    "Переименовать трек": "Rename track",
    "Новое название файла:": "New file name:",
    "Файл с таким названием уже существует.": (
        "A file with this name already exists."
    ),
    "Удалить": "Delete",
    "Удалить трек": "Delete track",
    "Вы точно хотите удалить этот трек?": (
        "Are you sure you want to delete this track?"
    ),
    "Папки не добавлены": "No folders added",
    "Библиотека пуста": "Library is empty",
    "Нажмите «Обзор», чтобы добавить папку с музыкой.": (
        "Click “Browse” to add a music folder."
    ),
    "Сканирование библиотеки…": "Scanning library…",
    "Сканирование": "Scanning",
    "Сканирование…": "Scanning…",
    "Читаем треки и длительность. Это может занять немного времени.": (
        "Reading tracks and durations. This may take a moment."
    ),
    "0 треков": "0 tracks",
    "Здесь нет треков": "No tracks here",
    "Поддерживаются MP3, FLAC, WAV, OGG, M4A и другие форматы.": (
        "MP3, FLAC, WAV, OGG, M4A and other formats are supported."
    ),
    " · сканирование…": " · scanning…",
    "Папка недоступна": "Folder unavailable",
    "Возможно, она была перемещена или удалена. Удалите её из библиотеки через правый клик.": (
        "It may have been moved or deleted. Remove it from the library "
        "via right-click."
    ),

    # Hotkeys
    "Воспроизведение / пауза": "Play / pause",
    "Горячие клавиши": "Hotkeys",
    "Не удалось зарегистрировать глобальные сочетания:\n{names}\n\n"
    "Возможно, они уже заняты другой программой. Их можно изменить в настройках.": (
        "Could not register global hotkeys:\n{names}\n\n"
        "They may already be used by another program. "
        "You can change them in Settings."
    ),

    # Settings dialog
    "Настройки": "Settings",
    "Aurison · MP3-плеер": "Aurison · MP3 player",
    "ГОРЯЧИЕ КЛАВИШИ": "HOTKEYS",
    "Управляйте плеером из любого приложения, даже когда окно свёрнуто.": (
        "Control the player from any app, even when the window is minimized."
    ),
    "Включить глобальные горячие клавиши": "Enable global hotkeys",
    "Нужен хотя бы один модификатор: Ctrl, Alt или Win. Например: Ctrl+Alt+Space.": (
        "At least one modifier is required: Ctrl, Alt or Win. "
        "For example: Ctrl+Alt+Space."
    ),
    "Сбросить": "Reset",
    "Отмена": "Cancel",
    "Сохранить": "Save",
    "ЯЗЫК": "LANGUAGE",
    "Язык": "Language",
    "Русский": "Russian",
    "МИНИ-ПЛЕЕР": "MINI PLAYER",
    "Показывать мини-плеер при сворачивании": (
        "Show the mini player when minimized"
    ),
    "Когда включено, при сворачивании появляется компактный "
    "мини-плеер. Если выключено, окно сворачивается в панель "
    "задач, а музыка продолжает играть.": (
        "When enabled, a compact mini player appears when the window is "
        "minimized. When disabled, the window minimizes to the taskbar and "
        "music keeps playing."
    ),
    "Задайте сочетание для: {names}.": "Set a shortcut for: {names}.",
    "Сочетание «{sequence}» назначено дважды: «{first}» и «{second}».": (
        "The shortcut “{sequence}” is assigned twice: "
        "“{first}” and “{second}”."
    ),
    "Для «{label}» нужно одно сочетание с Ctrl, Alt или Win и поддерживаемой клавишей.": (
        "“{label}” needs a single shortcut with Ctrl, Alt or Win "
        "and a supported key."
    ),

    # Startup / errors
    "Не удалось запустить Aurison.": "Could not start Aurison.",
    "Подробности: {path}": "Details: {path}",
    "MP3-плеер": "MP3 player",

    # Online mode
    "Онлайн": "Online",
    "Оффлайн": "Offline",
    "Переключить онлайн-режим": "Toggle online mode",
    "Включить онлайн-режим": "Enable online mode",
    "Выключить онлайн-режим": "Disable online mode",
    "Онлайн-поиск": "Online search",
    "Поиск треков и альбомов в интернете": "Search tracks and albums online",
    "Искать:": "Search for:",
    "Треки": "Tracks",
    "Группы и альбомы": "Artists & albums",
    "Скачивать в:": "Download to:",
    "Нет папок": "No folders",
    "Введите название песни или исполнителя": (
        "Enter a song or artist name"
    ),
    "Найти": "Search",
    "Поиск...": "Search...",
    "Фильтры": "Filters",
    "Фильтры источников": "Source filters",
    "Источники поиска": "Search sources",
    "Снимите галочку, чтобы исключить источник из поиска.": (
        "Uncheck a source to exclude it from the search."
    ),
    "Все": "All",
    "Ничего": "None",
    "доступен": "available",
    "недоступен": "unavailable",
    "только превью 30 с": "30-second preview only",
    "поиск…": "searching…",
    "Источники не выбраны — выберите хотя бы один источник.": (
        "No sources selected — choose at least one source."
    ),
    "Ищем в: {sources}": "Searching in: {sources}",
    "отфильтровано источников: {count}": "filtered out: {count}",
    "Выберите хотя бы один источник": "Select at least one source",
    "По выбранным источникам ничего не найдено": (
        "Nothing found in the selected sources"
    ),
    "Попробуйте изменить запрос или включить другие источники.": (
        "Try a different query or enable other sources."
    ),
    "Источник": "Source",
    "Название": "Title",
    "Слушать": "Preview",
    "Стоп": "Stop",
    "Скачать": "Download",
    "Скачать трек": "Download track",
    "Скачать весь альбом": "Download the whole album",
    "Прослушать трек": "Preview track",
    "Прослушать первый трек альбома": "Preview the first album track",
    "Отменить прослушивание": "Cancel preview",
    "Остановить прослушивание": "Stop preview",
    "Не удалось включить прослушивание: {error}": (
        "Could not start preview: {error}"
    ),
    "Источник не вернул аудио для прослушивания": (
        "The source returned no audio for preview"
    ),
    "Для прослушивания нужен yt-dlp: python -m pip install yt-dlp": (
        "Preview requires yt-dlp: python -m pip install yt-dlp"
    ),
    "Найдено: {count}": "Found: {count}",
    "Введите название песни, группы или альбома, чтобы найти музыку в интернете.": (
        "Enter a song, artist or album name to find music online."
    ),
    "Поиск": "Search",
    "Ищем музыку в интернете. Это может занять немного времени.": (
        "Searching the web. This may take a moment."
    ),
    "Ничего не найдено": "Nothing found",
    "Попробуйте изменить запрос или выбрать другой режим поиска.": (
        "Try a different query or search mode."
    ),
    "Ошибка поиска": "Search failed",
    "Не удалось выполнить поиск. Проверьте подключение к интернету.": (
        "Could not search. Check your internet connection."
    ),
    "Источник не отвечает. Попробуйте другой или повторите позже": (
        "The source is not responding. Try another one or try again later."
    ),
    "Hitmo недоступен: {error}": "Hitmo is unavailable: {error}",
    "Hitmo недоступен (HTTP {code}).": "Hitmo is unavailable (HTTP {code}).",
    "нет соединения с сайтом.": "no connection to the site.",
    "Скачивание… {percent}%": "Downloading… {percent}%",
    "Альбомы и группы ищутся на YouTube; треки — во всех доступных источниках.": (
        "Albums and artists are searched on YouTube; "
        "tracks are searched across every available source."
    ),
    "фрагмент 30 сек": "preview (30s)",
    "Для этого источника доступен только 30-секундный фрагмент. Выберите другой результат.": (
        "Only a 30-second preview is available for this source. "
        "Pick another result."
    ),
    "альбом": "album",
    "yt-dlp не установлен": "yt-dlp is not installed",
    "Источник не вернул результаты": "The source returned no results",
    "Для онлайн-поиска нужен yt-dlp: python -m pip install yt-dlp": (
        "Online search requires yt-dlp: python -m pip install yt-dlp"
    ),
    "Для скачивания нужен yt-dlp: python -m pip install yt-dlp": (
        "Downloading requires yt-dlp: python -m pip install yt-dlp"
    ),
    "Некоторые источники недоступны": "Some sources are unavailable",
    "Некоторые источники недоступны: {details}": (
        "Some sources are unavailable: {details}"
    ),
    "Скачано в «{folder}»": "Downloaded to “{folder}”",
    "Скачано в «{folder}» · файлов: {count}": (
        "Downloaded to “{folder}” · files: {count}"
    ),
    "Скачано файлов: {count}": "Files downloaded: {count}",
    "Ошибка скачивания": "Download failed",
    "Ошибка скачивания: {error}": "Download failed: {error}",
    "Не удалось скачать файл.": "Could not download the file.",
    "Добавьте папку в библиотеку, чтобы выбрать место скачивания.": (
        "Add a folder to the library to choose a download destination."
    ),
    "LightAudio заблокировал запрос (капча или защита от ботов). Попробуйте позже.": (
        "LightAudio blocked the request (captcha or bot protection). "
        "Try again later."
    ),
    "LightAudio ограничил доступ (HTTP {code}). Попробуйте позже.": (
        "LightAudio rate-limited the request (HTTP {code}). Try again later."
    ),
    "LightAudio недоступен (HTTP {code}).": (
        "LightAudio is unavailable (HTTP {code})."
    ),
    "LightAudio не ответил за {seconds} секунд.": (
        "LightAudio did not respond within {seconds} seconds."
    ),
    "LightAudio недоступен: нет соединения с сайтом.": (
        "LightAudio is unavailable: could not connect to the site."
    ),
    "LightAudio недоступен: {error}": "LightAudio is unavailable: {error}",
    "LightAudio: превышен лимит одновременных запросов.": (
        "LightAudio: too many concurrent requests."
    ),
    "LightAudio вернул неожиданный ответ без списка треков.": (
        "LightAudio returned an unexpected response without a track list."
    ),
    "LightAudio: не удалось обновить ссылку на трек.": (
        "LightAudio: could not refresh the track link."
    ),
}


def _plural_ru(count: int) -> str:
    if 11 <= count % 100 <= 14:
        return "треков"
    last = count % 10
    if last == 1:
        return "трек"
    if 2 <= last <= 4:
        return "трека"
    return "треков"


def set_language(language: str | None) -> None:
    """Set the active UI language, ignoring unsupported values."""
    global _language
    value = (language or "").lower()
    _language = value if value in SUPPORTED_LANGUAGES else DEFAULT_LANGUAGE


def get_language() -> str:
    return _language


def tr(text: str) -> str:
    """Translate a Russian source string into the active language."""
    if _language == "en":
        return TRANSLATIONS.get(text, text)
    return text


def track_count(count: int) -> str:
    """Return a localized "N tracks" phrase."""
    if _language == "en":
        return f"{count} track" if count == 1 else f"{count} tracks"
    return f"{count} {_plural_ru(count)}"


def hotkey_labels() -> dict[str, str]:
    """Localized labels for the configurable global hotkeys."""
    return {
        "play_pause": tr("Воспроизведение / пауза"),
        "next": tr("Следующий трек"),
        "previous": tr("Предыдущий трек"),
    }
