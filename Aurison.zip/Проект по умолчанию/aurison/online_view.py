from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import QPoint, Qt, QTimer, Signal
from PySide6.QtGui import QColor
from PySide6.QtWidgets import (
    QAbstractItemView,
    QCheckBox,
    QComboBox,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QProgressBar,
    QPushButton,
    QStackedWidget,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from aurison.i18n import track_count, tr
from aurison.icons import icon
from aurison.music_service import (
    PROVIDERS,
    ProviderReport,
    ProviderSpec,
    provider_available,
)
from aurison.online import SearchResult
from aurison.widgets import ElidedLabel, Placeholder, repolish


_FILTER_STATUS_TEXT = {
    "ok": "доступен",
    "unavailable": "недоступен",
    "preview": "только превью 30 с",
    "pending": "поиск…",
}


class SourceFilterPanel(QFrame):
    """Popup with one checkbox per provider and live diagnostics."""

    selectionChanged = Signal(object)
    resetRequested = Signal()

    def __init__(
        self,
        specs: tuple[ProviderSpec, ...],
        parent: QWidget | None = None,
    ) -> None:
        super().__init__(parent)
        self.setObjectName("SourceFilterPanel")
        self.setWindowFlags(
            Qt.WindowType.Popup | Qt.WindowType.FramelessWindowHint
        )
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        self.setFixedWidth(440)
        self._specs = tuple(specs)
        self._checks: dict[str, QCheckBox] = {}
        self._counts: dict[str, QLabel] = {}
        self._badges: dict[str, QLabel] = {}
        self._updating = False

        root = QVBoxLayout(self)
        root.setContentsMargins(16, 14, 16, 14)
        root.setSpacing(10)

        self.title_label = QLabel(tr("Источники поиска"), self)
        self.title_label.setObjectName("FilterTitle")
        root.addWidget(self.title_label)

        self.subtitle_label = QLabel(
            tr("Снимите галочку, чтобы исключить источник из поиска."),
            self,
        )
        self.subtitle_label.setObjectName("FilterSubtitle")
        self.subtitle_label.setWordWrap(True)
        root.addWidget(self.subtitle_label)

        grid = QGridLayout()
        grid.setContentsMargins(0, 2, 0, 2)
        grid.setHorizontalSpacing(8)
        grid.setVerticalSpacing(6)
        grid.setColumnStretch(0, 1)
        for row, spec in enumerate(self._specs):
            check = QCheckBox(spec.label, self)
            check.setChecked(True)
            check.toggled.connect(self._on_toggled)
            count = QLabel("—", self)
            count.setObjectName("FilterCount")
            count.setAlignment(
                Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter
            )
            count.setFixedWidth(42)
            badge = QLabel(self)
            badge.setObjectName("FilterBadge")
            badge.setAlignment(Qt.AlignmentFlag.AlignCenter)
            badge.setFixedWidth(154)
            grid.addWidget(check, row, 0)
            grid.addWidget(count, row, 1)
            grid.addWidget(badge, row, 2)
            self._checks[spec.key] = check
            self._counts[spec.key] = count
            self._badges[spec.key] = badge
            self._apply_status(spec.key, self._default_status(spec))

        root.addLayout(grid)

        actions = QHBoxLayout()
        actions.setContentsMargins(0, 2, 0, 0)
        actions.setSpacing(6)
        self.all_btn = QPushButton(tr("Все"), self)
        self.all_btn.setObjectName("SecondaryButton")
        self.all_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.all_btn.clicked.connect(self._select_all)
        self.none_btn = QPushButton(tr("Ничего"), self)
        self.none_btn.setObjectName("SecondaryButton")
        self.none_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.none_btn.clicked.connect(self._select_none)
        self.reset_btn = QPushButton(tr("Сбросить"), self)
        self.reset_btn.setObjectName("GhostButton")
        self.reset_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.reset_btn.clicked.connect(self._reset)
        actions.addWidget(self.all_btn)
        actions.addWidget(self.none_btn)
        actions.addStretch(1)
        actions.addWidget(self.reset_btn)
        root.addLayout(actions)

    # ---- public API ----------------------------------------------------

    def set_sources(self, sources: set[str]) -> None:
        self._updating = True
        try:
            for key, check in self._checks.items():
                check.setChecked(key in sources)
        finally:
            self._updating = False

    def selected_sources(self) -> list[str]:
        return [
            spec.key
            for spec in self._specs
            if self._checks[spec.key].isChecked()
        ]

    def set_reports(self, reports: dict[str, ProviderReport]) -> None:
        for spec in self._specs:
            report = reports.get(spec.key)
            if report is None:
                self._counts[spec.key].setText("—")
                self._apply_status(
                    spec.key, self._default_status(spec)
                )
                continue
            self._counts[spec.key].setText(str(max(0, report.count)))
            self._apply_status(spec.key, report.status)

    def set_pending(self) -> None:
        for spec in self._specs:
            if self._checks[spec.key].isChecked():
                self._counts[spec.key].setText("…")
                self._apply_status(spec.key, "pending")
            else:
                self._counts[spec.key].setText("—")
                self._apply_status(
                    spec.key, self._default_status(spec)
                )

    def popup_at(self, button: QWidget) -> None:
        self.adjustSize()
        pos = button.mapToGlobal(
            QPoint(0, button.height() + 6)
        )
        screen = button.screen()
        if screen is not None:
            available = screen.availableGeometry()
            x = min(pos.x(), available.right() - self.width() + 1)
            x = max(available.left(), x)
            y = pos.y()
            if y + self.height() > available.bottom():
                y = (
                    button.mapToGlobal(
                        QPoint(0, -self.height() - 6)
                    ).y()
                )
            y = max(available.top(), y)
            self.move(x, y)
        else:
            self.move(pos)
        self.show()
        self.raise_()
        self.activateWindow()

    def retranslate(self) -> None:
        self.title_label.setText(tr("Источники поиска"))
        self.subtitle_label.setText(
            tr("Снимите галочку, чтобы исключить источник из поиска.")
        )
        self.all_btn.setText(tr("Все"))
        self.none_btn.setText(tr("Ничего"))
        self.reset_btn.setText(tr("Сбросить"))
        for spec in self._specs:
            self._apply_status(
                spec.key, self._current_status(spec.key)
            )

    # ---- internals -----------------------------------------------------

    @staticmethod
    def _default_status(spec: ProviderSpec) -> str:
        if not provider_available(spec):
            return "unavailable"
        if spec.preview_only:
            return "preview"
        return "ok"

    def _current_status(self, key: str) -> str:
        badge = self._badges[key]
        return str(badge.property("status") or "ok")

    def _apply_status(self, key: str, status: str) -> None:
        badge = self._badges[key]
        badge.setText(tr(_FILTER_STATUS_TEXT.get(status, "доступен")))
        badge.setProperty("status", status)
        repolish(badge)

    def _on_toggled(self, _checked: bool) -> None:
        if self._updating:
            return
        self.selectionChanged.emit(self.selected_sources())

    def _set_all(self, checked: bool) -> None:
        self._updating = True
        try:
            for check in self._checks.values():
                check.setChecked(checked)
        finally:
            self._updating = False
        self.selectionChanged.emit(self.selected_sources())

    def _select_all(self) -> None:
        self._set_all(True)

    def _select_none(self) -> None:
        self._set_all(False)

    def _reset(self) -> None:
        self._updating = True
        try:
            for check in self._checks.values():
                check.setChecked(True)
        finally:
            self._updating = False
        self.resetRequested.emit()
        self.selectionChanged.emit(self.selected_sources())


class OnlineView(QWidget):
    """Search field, scope selector and remote result table."""

    searchRequested = Signal(str, str)
    downloadRequested = Signal(object, str)
    previewRequested = Signal(object)
    previewStopRequested = Signal()
    folderChanged = Signal(str)
    scopeChanged = Signal(str)
    sourcesChanged = Signal(object)

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setObjectName("OnlineView")
        self._results: list[SearchResult] = []
        self._folders: list[str] = []
        self._folder_names: dict[str, str] = {}
        self._download_buttons: list[QPushButton] = []
        self._preview_buttons: list[QPushButton] = []
        self._preview_result: SearchResult | None = None
        self._preview_loading = False
        self._searching = False
        self._downloading = False
        self._progress_percent = 0
        self._progress_detail = ""
        self._state = "idle"
        self._search_query = ""
        self._error_message = ""
        self._status_key = ""
        self._status_args: dict[str, object] = {}
        self._status_error = False
        self._enabled_sources: set[str] = {
            spec.key for spec in PROVIDERS
        }
        self._provider_reports: dict[str, ProviderReport] = {}
        self._search_sources: list[str] = []

        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(10)

        controls = QHBoxLayout()
        controls.setContentsMargins(0, 0, 0, 0)
        controls.setSpacing(10)
        self.scope_label = QLabel(tr("Искать:"), self)
        self.scope_label.setObjectName("FieldLabel")
        self.scope_combo = QComboBox(self)
        self.scope_combo.setObjectName("OnlineCombo")
        self.scope_combo.addItem(tr("Треки"), "tracks")
        self.scope_combo.addItem(tr("Группы и альбомы"), "albums")
        self.scope_combo.setFixedWidth(190)
        controls.addWidget(self.scope_label)
        controls.addWidget(self.scope_combo)
        self.filter_btn = QPushButton(tr("Фильтры"), self)
        self.filter_btn.setObjectName("FilterButton")
        self.filter_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.filter_btn.setFixedHeight(34)
        self.filter_btn.setMinimumWidth(104)
        self.filter_btn.setIcon(icon("filter", "#c3c8d2", 15))
        self.filter_btn.setToolTip(tr("Фильтры источников"))
        controls.addWidget(self.filter_btn)

        controls.addStretch(1)

        self.folder_label = QLabel(tr("Скачивать в:"), self)
        self.folder_label.setObjectName("FieldLabel")
        self.folder_combo = QComboBox(self)
        self.folder_combo.setObjectName("OnlineCombo")
        self.folder_combo.setMinimumWidth(230)
        controls.addWidget(self.folder_label)
        controls.addWidget(self.folder_combo)
        root.addLayout(controls)

        self.source_panel = SourceFilterPanel(PROVIDERS, self)
        self.source_panel.set_sources(self._enabled_sources)

        search_row = QHBoxLayout()
        search_row.setContentsMargins(0, 0, 0, 0)
        search_row.setSpacing(8)
        self.search_edit = QLineEdit(self)
        self.search_edit.setObjectName("OnlineSearch")
        self.search_edit.setPlaceholderText(
            tr("Введите название песни или исполнителя")
        )
        self.search_edit.setClearButtonEnabled(True)
        self.search_edit.setMinimumHeight(40)
        self.search_edit.addAction(
            icon("search", "#6f7580", 16),
            QLineEdit.ActionPosition.LeadingPosition,
        )
        self.search_btn = QPushButton(tr("Найти"), self)
        self.search_btn.setObjectName("PrimaryButton")
        self.search_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.search_btn.setFixedHeight(40)
        self.search_btn.setMinimumWidth(100)
        search_row.addWidget(self.search_edit, 1)
        search_row.addWidget(self.search_btn)
        root.addLayout(search_row)

        self.source_hint = QLabel(self)
        self.source_hint.setObjectName("Hint")
        self.source_hint.setWordWrap(True)
        root.addWidget(self.source_hint)

        self.status_label = ElidedLabel("", self)
        self.status_label.setObjectName("OnlineStatus")
        self.status_label.hide()
        root.addWidget(self.status_label)

        self.progress_bar = QProgressBar(self)
        self.progress_bar.setObjectName("DownloadProgress")
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setTextVisible(False)
        self.progress_bar.setFixedHeight(4)
        self.progress_bar.hide()
        root.addWidget(self.progress_bar)

        self.results_stack = QStackedWidget(self)
        self.placeholder = Placeholder(self.results_stack)
        self.table = QTableWidget(0, 4, self.results_stack)
        self._setup_table()
        self.results_stack.addWidget(self.placeholder)
        self.results_stack.addWidget(self.table)
        root.addWidget(self.results_stack, 1)

        self.search_btn.clicked.connect(self._submit_search)
        self.search_edit.returnPressed.connect(self._submit_search)
        self.search_edit.textChanged.connect(self._on_text_changed)
        self.scope_combo.currentIndexChanged.connect(self._on_scope_changed)
        self.folder_combo.currentIndexChanged.connect(self._on_folder_changed)
        self.filter_btn.clicked.connect(self._show_filters)
        self.source_panel.selectionChanged.connect(
            self._on_sources_changed
        )
        self.source_panel.resetRequested.connect(self._on_filter_reset)

        self._search_timer = QTimer(self)
        self._search_timer.setSingleShot(True)
        self._search_timer.setInterval(750)
        self._search_timer.timeout.connect(self._submit_search)

        self._set_state("idle")
        self._update_source_hint()

    # ---- public API ----------------------------------------------------

    def set_folders(
        self,
        folders: list[str],
        names: dict[str, str],
        selected: str,
    ) -> str:
        self._folders = list(folders)
        self._folder_names = dict(names)
        self.folder_combo.blockSignals(True)
        self.folder_combo.clear()
        if not folders:
            self.folder_combo.addItem(tr("Нет папок"), "")
            self.folder_combo.setEnabled(False)
            self.folder_label.setEnabled(False)
            current = ""
        else:
            self.folder_label.setEnabled(True)
            self.folder_combo.setEnabled(True)
            for folder in folders:
                label = names.get(folder) or Path(folder).name or folder
                self.folder_combo.addItem(label, folder)
            index = self.folder_combo.findData(selected)
            if index < 0:
                index = 0
            self.folder_combo.setCurrentIndex(index)
            current = self.folder_combo.currentData() or ""
        self.folder_combo.blockSignals(False)
        self._update_action_buttons()
        return current

    def current_folder(self) -> str:
        return self.folder_combo.currentData() or ""

    def scope(self) -> str:
        return self.scope_combo.currentData() or "tracks"

    def set_scope(self, scope: str) -> None:
        index = self.scope_combo.findData(scope)
        if index < 0:
            index = 0
        self.scope_combo.blockSignals(True)
        self.scope_combo.setCurrentIndex(index)
        self.scope_combo.blockSignals(False)
        self._update_source_hint()

    def set_sources(self, sources: list[str] | None) -> None:
        """Load the persisted source selection (``None`` means all)."""
        known = {spec.key for spec in PROVIDERS}
        if sources is None:
            enabled = set(known)
        else:
            enabled = {
                str(source) for source in sources if str(source) in known
            }
        self._enabled_sources = enabled
        self.source_panel.set_sources(enabled)
        self._update_source_hint()

    def selected_sources(self) -> list[str]:
        return [
            spec.key
            for spec in PROVIDERS
            if spec.key in self._enabled_sources
        ]

    def active_sources(self) -> list[str]:
        """Enabled sources that apply to the current search scope."""
        return self._active_sources()

    def set_provider_reports(
        self,
        reports: dict[str, ProviderReport] | None,
    ) -> None:
        known = {spec.key for spec in PROVIDERS}
        self._provider_reports = {
            key: report
            for key, report in (reports or {}).items()
            if key in known
        }
        self.source_panel.set_reports(self._provider_reports)

    def clear_provider_reports(self) -> None:
        self._provider_reports = {}
        self.source_panel.set_reports({})

    def set_query(self, text: str) -> None:
        self.search_edit.setText(text)

    def focus_search(self) -> None:
        self.search_edit.setFocus(Qt.FocusReason.OtherFocusReason)

    def set_searching(self, searching: bool, query: str = "") -> None:
        self._searching = searching
        self._search_query = query
        if searching:
            self._set_state("searching")
            self.source_panel.set_pending()
        self.search_btn.setEnabled(not searching and not self._downloading)
        self.search_edit.setEnabled(not self._downloading)
        self.scope_combo.setEnabled(not searching and not self._downloading)
        self.table.setEnabled(not searching)
        self._update_action_buttons()

    def set_results(self, results: list[SearchResult]) -> None:
        self._results = list(results)
        self._searching = False
        self.clear_preview()
        self._render_results()
        self._update_action_buttons()
        self.search_btn.setEnabled(not self._downloading)
        self.scope_combo.setEnabled(not self._downloading)
        self.table.setEnabled(True)
        if results:
            self._set_state("results")
            self.set_status_template(
                "Найдено: {count}", {"count": len(results)}
            )
        else:
            self._set_state("empty")
            self.set_status("")
        self.source_panel.set_reports(self._provider_reports)

    def show_error(self, message: str, details: str = "") -> None:
        self._searching = False
        self._error_message = message
        self._set_state("error")
        self.set_status(details, error=True)
        self.search_btn.setEnabled(not self._downloading)
        self.scope_combo.setEnabled(not self._downloading)
        self.table.setEnabled(True)

    def show_selected_empty(self) -> None:
        """Show the "no results in the selected sources" placeholder."""
        self._searching = False
        self._results = []
        self._error_message = ""
        self.clear_preview()
        self._render_results()
        self._set_state("empty_selected")
        self.set_status("")
        self.search_btn.setEnabled(not self._downloading)
        self.scope_combo.setEnabled(not self._downloading)
        self.table.setEnabled(True)
        self._update_action_buttons()

    def show_downloaded(self, folder: str, count: int) -> None:
        if count > 0:
            self.set_status_template(
                "Скачано в «{folder}» · файлов: {count}",
                {"folder": folder, "count": count},
            )
        else:
            self.set_status_template(
                "Скачано в «{folder}»", {"folder": folder}
            )

    def show_download_error(self, message: str) -> None:
        self.set_status_template(
            "Ошибка скачивания: {error}",
            {"error": message or tr("Не удалось скачать файл.")},
            error=True,
        )

    def set_previewing(
        self,
        result: SearchResult | None,
        loading: bool = False,
    ) -> None:
        self._preview_result = result
        self._preview_loading = bool(result is not None and loading)
        self._update_action_buttons()

    def clear_preview(self) -> None:
        self.set_previewing(None)

    def show_preview_error(self, message: str) -> None:
        self.set_status_template(
            "Не удалось включить прослушивание: {error}",
            {"error": message or tr("Не удалось воспроизвести файл")},
            error=True,
        )

    def show_source_warnings(self, errors: list[str]) -> None:
        names: list[str] = []
        for error in errors:
            name = error.split(":", 1)[0].strip()
            for spec in PROVIDERS:
                if error.startswith(spec.label):
                    name = spec.label
                    break
            if name and name not in names:
                names.append(name)
        self.set_status_template(
            "Некоторые источники недоступны: {details}",
            {"details": ", ".join(names) or "; ".join(errors)},
        )

    def clear_folder_hint(self) -> None:
        if (
            self._status_key
            == "Добавьте папку в библиотеку, чтобы выбрать место скачивания."
        ):
            self.set_status("")

    def set_status(self, text: str, error: bool = False) -> None:
        self._set_status_key(text, {}, error)

    def set_status_template(
        self,
        key: str,
        args: dict[str, object] | None = None,
        error: bool = False,
    ) -> None:
        self._set_status_key(key, args or {}, error)

    def _set_status_key(
        self,
        key: str,
        args: dict[str, object],
        error: bool,
    ) -> None:
        self._status_key = key
        self._status_args = args
        self._status_error = error
        self._render_status()

    def _render_status(self) -> None:
        if not self._status_key:
            text = ""
        else:
            try:
                text = tr(self._status_key).format(**self._status_args)
            except (KeyError, IndexError, ValueError):
                text = tr(self._status_key)
        self._apply_status_text(text, self._status_error)

    def _apply_status_text(self, text: str, error: bool) -> None:
        self._status_error = error
        self.status_label.setText(text)
        self.status_label.setToolTip(text)
        self.status_label.setProperty("error", error)
        self.status_label.setVisible(bool(text))
        repolish(self.status_label)

    def set_downloading(self, active: bool) -> None:
        self._downloading = active
        self.search_edit.setEnabled(not active)
        self.search_btn.setEnabled(not active and not self._searching)
        self.scope_combo.setEnabled(not active and not self._searching)
        self.folder_combo.setEnabled(not active and bool(self._folders))
        self.progress_bar.setVisible(active)
        if active:
            self._progress_percent = 0
            self._progress_detail = ""
            self.progress_bar.setValue(0)
            self._update_progress_status()
        else:
            self.progress_bar.hide()
        self._update_action_buttons()

    def set_download_progress(self, percent: int, detail: str = "") -> None:
        self._progress_percent = max(0, min(100, int(percent)))
        self._progress_detail = detail
        self.progress_bar.setValue(self._progress_percent)
        self._update_progress_status()

    def retranslate(self) -> None:
        self.scope_label.setText(tr("Искать:"))
        scope = self.scope()
        self.scope_combo.blockSignals(True)
        self.scope_combo.clear()
        self.scope_combo.addItem(tr("Треки"), "tracks")
        self.scope_combo.addItem(tr("Группы и альбомы"), "albums")
        index = self.scope_combo.findData(scope)
        self.scope_combo.setCurrentIndex(max(0, index))
        self.scope_combo.blockSignals(False)

        self.folder_label.setText(tr("Скачивать в:"))
        selected = self.current_folder()
        self.folder_combo.blockSignals(True)
        self.folder_combo.clear()
        if not self._folders:
            self.folder_combo.addItem(tr("Нет папок"), "")
            self.folder_combo.setEnabled(False)
        else:
            for folder in self._folders:
                label = (
                    self._folder_names.get(folder)
                    or Path(folder).name
                    or folder
                )
                self.folder_combo.addItem(label, folder)
            index = self.folder_combo.findData(selected)
            self.folder_combo.setCurrentIndex(max(0, index))
            self.folder_combo.setEnabled(True)
        self.folder_combo.blockSignals(False)

        self.search_edit.setPlaceholderText(
            tr("Введите название песни или исполнителя")
        )
        self.search_btn.setText(tr("Найти"))
        self.filter_btn.setText(tr("Фильтры"))
        self.filter_btn.setToolTip(tr("Фильтры источников"))
        self.source_panel.retranslate()
        self._update_header_labels()
        self._update_source_hint()
        self._render_results()
        self._update_action_buttons()

        if self._searching:
            self._set_state("searching")
        elif self._state == "error":
            self._set_state("error")
        elif not self._results and self._state == "empty_selected":
            self._set_state("empty_selected")
        elif not self._results and self._state in ("empty", "results"):
            self._set_state("empty")
        elif not self._results and self._state == "idle":
            self._set_state("idle")

        if self._downloading:
            self._update_progress_status()
        else:
            self._render_status()

    # ---- table ---------------------------------------------------------

    def _setup_table(self) -> None:
        self.table.setObjectName("OnlineTable")
        self.table.setShowGrid(False)
        self.table.setSelectionBehavior(
            QAbstractItemView.SelectionBehavior.SelectRows
        )
        self.table.setSelectionMode(
            QAbstractItemView.SelectionMode.SingleSelection
        )
        self.table.setEditTriggers(
            QAbstractItemView.EditTrigger.NoEditTriggers
        )
        self.table.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.table.setWordWrap(False)
        self.table.setTextElideMode(Qt.TextElideMode.ElideRight)
        self.table.setVerticalScrollMode(
            QAbstractItemView.ScrollMode.ScrollPerPixel
        )
        self.table.setHorizontalScrollBarPolicy(
            Qt.ScrollBarPolicy.ScrollBarAlwaysOff
        )
        self.table.verticalHeader().setVisible(False)
        self.table.verticalHeader().setDefaultSectionSize(58)
        header = self.table.horizontalHeader()
        header.setFixedHeight(28)
        header.setSectionResizeMode(0, QHeaderView.ResizeMode.Fixed)
        header.resizeSection(0, 112)
        header.setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        header.setSectionResizeMode(2, QHeaderView.ResizeMode.Fixed)
        header.resizeSection(2, 108)
        header.setSectionResizeMode(3, QHeaderView.ResizeMode.Fixed)
        header.resizeSection(3, 126)
        self._update_header_labels()

    def _update_header_labels(self) -> None:
        self.table.setHorizontalHeaderLabels(
            [tr("Источник"), tr("Название"), tr("Слушать"), tr("Скачать")]
        )
        title_item = self.table.horizontalHeaderItem(1)
        if title_item is not None:
            title_item.setTextAlignment(
                Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter
            )

    def _render_results(self) -> None:
        self.table.clearContents()
        self.table.setRowCount(0)
        self._download_buttons = []
        self._preview_buttons = []
        if not self._results:
            return
        self.table.setRowCount(len(self._results))
        for row, result in enumerate(self._results):
            source_item = QTableWidgetItem(result.source_name)
            source_item.setFlags(
                Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsSelectable
            )
            source_item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            source_item.setForeground(QColor("#9db4ff"))
            source_item.setToolTip(result.source_name)
            self.table.setItem(row, 0, source_item)

            cell = QWidget(self.table)
            cell_layout = QVBoxLayout(cell)
            cell_layout.setContentsMargins(8, 5, 8, 5)
            cell_layout.setSpacing(1)
            title = ElidedLabel(result.title, cell)
            title.setObjectName("OnlineTitle")
            title.setToolTip(result.title)
            meta = ElidedLabel(result.subtitle(), cell)
            meta.setObjectName("OnlineMeta")
            cell_layout.addWidget(title)
            cell_layout.addWidget(meta)
            self.table.setCellWidget(row, 1, cell)

            preview = QPushButton(tr("Слушать"), self.table)
            preview.setObjectName("PreviewButton")
            preview.setCursor(Qt.CursorShape.PointingHandCursor)
            preview.setFixedHeight(30)
            preview.setToolTip(
                tr("Прослушать первый трек альбома")
                if result.is_album
                else tr("Прослушать трек")
            )
            preview.clicked.connect(
                lambda checked=False, item=result: self._preview_clicked(
                    item
                )
            )
            preview_wrapper = QWidget(self.table)
            preview_layout = QHBoxLayout(preview_wrapper)
            preview_layout.setContentsMargins(8, 0, 8, 0)
            preview_layout.addWidget(preview)
            self.table.setCellWidget(row, 2, preview_wrapper)
            self._preview_buttons.append(preview)

            button = QPushButton(tr("Скачать"), self.table)
            button.setObjectName("DownloadButton")
            button.setCursor(Qt.CursorShape.PointingHandCursor)
            button.setFixedHeight(30)
            button.setToolTip(
                tr("Скачать весь альбом")
                if result.is_album
                else tr("Скачать трек")
            )
            button.clicked.connect(
                lambda checked=False, item=result: self._download(item)
            )
            wrapper = QWidget(self.table)
            wrapper_layout = QHBoxLayout(wrapper)
            wrapper_layout.setContentsMargins(8, 0, 8, 0)
            wrapper_layout.addWidget(button)
            self.table.setCellWidget(row, 3, wrapper)
            self._download_buttons.append(button)
        self._apply_preview_state()

    def _apply_preview_state(self) -> None:
        for button, result in zip(self._preview_buttons, self._results):
            if self._preview_loading:
                if result is self._preview_result:
                    button.setText(tr("Отмена"))
                    button.setToolTip(tr("Отменить прослушивание"))
                    button.setEnabled(True)
                else:
                    button.setText(tr("Слушать"))
                    button.setEnabled(False)
            elif result is self._preview_result:
                button.setText(tr("Стоп"))
                button.setToolTip(tr("Остановить прослушивание"))
                button.setEnabled(not self._searching)
            else:
                button.setText(tr("Слушать"))
                button.setToolTip(
                    tr("Прослушать первый трек альбома")
                    if result.is_album
                    else tr("Прослушать трек")
                )
                button.setEnabled(
                    not self._searching and not self._downloading
                )

    def _update_action_buttons(self) -> None:
        has_folder = bool(self.current_folder())
        self._apply_preview_state()
        for button in self._download_buttons:
            button.setEnabled(
                has_folder and not self._downloading and not self._searching
            )

    # ---- state ---------------------------------------------------------

    def _set_state(self, state: str) -> None:
        self._state = state
        if state == "results":
            self.results_stack.setCurrentWidget(self.table)
            return
        if state == "idle":
            self.placeholder.set_state(
                tr("Онлайн-поиск"),
                tr(
                    "Введите название песни, группы или альбома, "
                    "чтобы найти музыку в интернете."
                ),
                "search",
            )
        elif state == "searching":
            self.placeholder.set_state(
                tr("Поиск"),
                tr("Ищем музыку в интернете. Это может занять немного времени."),
                "search",
                loading=True,
            )
        elif state == "empty":
            self.placeholder.set_state(
                tr("Ничего не найдено"),
                tr("Попробуйте изменить запрос или выбрать другой режим поиска."),
                "search",
            )
        elif state == "empty_selected":
            self.placeholder.set_state(
                tr("По выбранным источникам ничего не найдено"),
                tr(
                    "Попробуйте изменить запрос или включить другие источники."
                ),
                "search",
            )
        elif state == "error":
            if self._error_message == "Ничего не найдено":
                title = tr("Ничего не найдено")
                text = tr(
                    "Попробуйте изменить запрос или выбрать другой "
                    "режим поиска."
                )
            else:
                title = tr(self._error_message or "Ошибка поиска")
                text = tr(
                    "Не удалось выполнить поиск. "
                    "Проверьте подключение к интернету."
                )
            self.placeholder.set_state(title, text, "search")
        self.results_stack.setCurrentWidget(self.placeholder)

    def _update_progress_status(self) -> None:
        text = tr("Скачивание… {percent}%").format(
            percent=self._progress_percent
        )
        if self._progress_detail:
            text = f"{self._progress_detail} · {text}"
        self._apply_status_text(text, False)

    def _update_source_hint(self) -> None:
        specs = self._scope_specs()
        enabled = [
            spec for spec in specs if spec.key in self._enabled_sources
        ]
        if not enabled:
            self.source_hint.setText(
                tr("Источники не выбраны — выберите хотя бы один источник.")
            )
            return
        labels = ", ".join(spec.label for spec in enabled)
        text = tr("Ищем в: {sources}").format(sources=labels)
        disabled = len(specs) - len(enabled)
        if disabled > 0:
            text += " · " + tr(
                "отфильтровано источников: {count}"
            ).format(count=disabled)
        self.source_hint.setText(text)

    def _scope_specs(self) -> list[ProviderSpec]:
        albums = self.scope() == "albums"
        return [
            spec
            for spec in PROVIDERS
            if not albums or spec.albums
        ]

    def _active_sources(self) -> list[str]:
        return [
            spec.key
            for spec in self._scope_specs()
            if spec.key in self._enabled_sources
        ]

    # ---- signals -------------------------------------------------------

    def _on_text_changed(self, text: str) -> None:
        if self._downloading:
            return
        query = text.strip()
        if len(query) >= 2:
            self._search_timer.start()
        else:
            self._search_timer.stop()
            if not query and self._state in ("empty", "error"):
                self._results = []
                self._render_results()
                self._set_state("idle")
                self.set_status("")

    def _on_scope_changed(self, _index: int) -> None:
        self._search_timer.stop()
        self._update_source_hint()
        self.scopeChanged.emit(self.scope())

    def _show_filters(self) -> None:
        self.source_panel.popup_at(self.filter_btn)

    def _on_sources_changed(self, sources: object) -> None:
        known = {spec.key for spec in PROVIDERS}
        self._enabled_sources = {
            str(source)
            for source in (sources or [])
            if str(source) in known
        }
        self._update_source_hint()
        self.sourcesChanged.emit(self.selected_sources())

    def _on_filter_reset(self) -> None:
        self.clear_provider_reports()

    def _on_folder_changed(self, _index: int) -> None:
        folder = self.current_folder()
        self._update_action_buttons()
        if folder:
            self.folderChanged.emit(folder)

    def _submit_search(self) -> None:
        self._search_timer.stop()
        query = self.search_edit.text().strip()
        if not query or self._searching or self._downloading:
            return
        if not self._active_sources():
            self.set_status(
                tr("Выберите хотя бы один источник"), error=True
            )
            return
        self._search_sources = self.active_sources()
        self.searchRequested.emit(query, self.scope())

    def _preview_clicked(self, result: SearchResult) -> None:
        if self._preview_loading:
            if result is self._preview_result:
                self.previewStopRequested.emit()
            return
        if result is self._preview_result:
            self.previewStopRequested.emit()
            return
        if self._searching or self._downloading:
            return
        self.previewRequested.emit(result)

    def _download(self, result: SearchResult) -> None:
        folder = self.current_folder()
        if not folder or self._downloading:
            return
        self.downloadRequested.emit(result, folder)
