"""Track-title cleanup shared by the online and offline layers.

Kept dependency-free so the offline library can import it without pulling in
the online backend (there is a regression test for that).
"""

from __future__ import annotations

import re

# Titles of downloaded tracks often carry download-page noise.  Bracketed
# version tags ("slowed", "nightcore", ...) are part of the real name and
# must survive; links, "official ..." tags and random ID-like tokens inside
# square brackets are dropped.
_TITLE_KEEP_WORDS = re.compile(
    r"\b(?:slowed|super\s+slowed|ultra\s+slowed|sped\s*up|speed\s*up|"
    r"hardtekk|hard\s*tek|reverb|nightcore|daycore|bass\s*boost|"
    r"8d|remix|remixed|extended|instrumental|karaoke|acoustic|live|"
    r"cover|edit|mashup|bootleg|phonk)\b",
    re.IGNORECASE,
)
_TITLE_DROP_WORDS = re.compile(
    r"\b(?:official|video|audio|lyrics?|visualizer|hd|hq|hdr|"
    r"explicit|music|clip|topic|vevo|kbps)\b",
    re.IGNORECASE,
)
_TITLE_URL = re.compile(
    r"(?:https?://|www\.|\b[\w-]+\.(?:ru|com|net|org|fm|io|me|tv)\b)",
    re.IGNORECASE,
)
# Any bare link/domain left in the name (even without brackets) is noise.
_TITLE_BARE_URL = re.compile(
    r"(?:https?://\S+|www\.\S+|"
    r"\b[\w-]+\.(?:ru|com|net|org|fm|io|me|tv)\b)",
    re.IGNORECASE,
)
_TITLE_BRACKET = re.compile(r"[(（]([^()（）]*)[)）]|\[([^\[\]]*)\]")


def _clean_title_bracket(match: re.Match[str]) -> str:
    opening = match.group(0)[0]
    inner = match.group(1) if opening in "(（" else match.group(2)
    flat = re.sub(r"\s+", " ", inner or "").strip()
    if _TITLE_KEEP_WORDS.search(flat):
        return f"({flat})" if opening in "(（" else f"[{flat}]"
    if _TITLE_URL.search(flat) or _TITLE_DROP_WORDS.search(flat):
        return " "
    if opening == "[":
        compact = flat.replace(" ", "")
        if (
            len(compact) >= 4
            and re.fullmatch(r"[A-Za-z0-9_\-=+/]+", compact)
            and (
                any(char.isdigit() for char in compact)
                or "_" in compact
                or re.search(r"[a-z][A-Z]", compact)
            )
        ):
            return " "
    return match.group(0)


def clean_track_title(name: str) -> str:
    """Remove download-page noise from a track title.

    Brackets with version tags (slowed, nightcore, bass boost, ...) are kept
    as-is; links, "official" tags and random square-bracket tokens are
    dropped.
    """
    original = (name or "").strip()
    cleaned = _TITLE_BRACKET.sub(_clean_title_bracket, original)
    cleaned = _TITLE_BARE_URL.sub(" ", cleaned)
    cleaned = re.sub(r"\(\s*\)|\[\s*\]", " ", cleaned)
    cleaned = re.sub(r"\s+", " ", cleaned).strip()
    cleaned = cleaned.strip(" -–—_.,;:")
    return cleaned or original
