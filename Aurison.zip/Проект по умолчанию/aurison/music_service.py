from __future__ import annotations

import concurrent.futures
import html
import json
import os
import re
import shutil
import socket
import threading
import time
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable
from urllib.parse import parse_qs, quote, quote_plus, urlsplit

from aurison.config import config_dir
from aurison.i18n import track_count, tr
from aurison.net import install_doh_fallback
from aurison.titles import clean_track_title

install_doh_fallback()

try:
    import yt_dlp
except Exception:  # pragma: no cover - optional dependency
    yt_dlp = None


SEARCH_LIMIT = 10
MIN_TRACK_MS = 30_000
MAX_TRACK_MS = 20 * 60_000
DOWNLOAD_FORMAT = (
    "bestaudio[ext=m4a]/bestaudio[ext=mp3]/bestaudio[ext=opus]/"
    "bestaudio[ext=ogg]/bestaudio/best"
)
SOURCE_ORDER = (
    "youtube",
    "rutube",
    # Full-track providers come before the 30-second preview sources so a
    # preview never hides a complete result during deduplication.
    "vk",
    "lightaudio",
    "hitmo",
    "deezer",
    "itunes",
)
SOURCE_LABELS = {
    "youtube": "YouTube",
    "rutube": "RUTUBE",
    "deezer": "Deezer",
    "vk": "VK Music",
    "lightaudio": "LightAudio",
    "hitmo": "Hitmo",
    "itunes": "iTunes",
}
ALBUM_SOURCES = ("youtube",)
SOURCE_FORMATS = {
    # RUTUBE only serves muxed HLS video; keep those files small.
    "rutube": "best[height<=360][ext=mp4]/best[height<=360]/best",
}
PREVIEW_ONLY_SOURCES = frozenset({"deezer", "itunes"})
PROVIDER_ENV_VARS = {"vk": "AURISON_VK_TOKEN"}


@dataclass(frozen=True)
class ProviderSpec:
    """Registry entry for one search adapter.

    The UI builds its source filter from this registry, so adding a new
    adapter to :data:`SOURCE_ORDER` and :data:`SOURCE_LABELS` is enough for it
    to appear in the filter panel automatically.
    """

    key: str
    label: str
    preview_only: bool = False
    albums: bool = False
    env_var: str = ""


PROVIDERS = tuple(
    ProviderSpec(
        key=source,
        label=SOURCE_LABELS[source],
        preview_only=source in PREVIEW_ONLY_SOURCES,
        albums=source in ALBUM_SOURCES,
        env_var=PROVIDER_ENV_VARS.get(source, ""),
    )
    for source in SOURCE_ORDER
)
PROVIDER_REGISTRY = PROVIDERS
PROVIDER_KEYS = tuple(spec.key for spec in PROVIDERS)
PROVIDERS_BY_KEY = {spec.key: spec for spec in PROVIDERS}


def provider_available(spec: ProviderSpec | str) -> bool:
    """Whether an adapter can run in the current environment."""
    if isinstance(spec, str):
        known = PROVIDERS_BY_KEY.get(spec)
        if known is None:
            return False
        spec = known
    if not spec.env_var:
        return True
    return bool(os.environ.get(spec.env_var, "").strip())


RUTUBE_SEARCH_URL = "https://rutube.ru/api/search/video/"
DEEZER_SEARCH_URL = "https://api.deezer.com/search"
ITUNES_SEARCH_URL = "https://itunes.apple.com/search"
VK_SEARCH_URL = "https://api.vk.com/method/audio.search"
LIGHTAUDIO_SEARCH_URL = "https://web.ligaudio.ru/mp3/"
LIGHTAUDIO_BASE_URL = "https://web.ligaudio.ru"
LIGHTAUDIO_TIMEOUT = 12.0
LIGHTAUDIO_MAX_CONCURRENCY = 2

HITMO_MIRRORS = (
    "https://ru.hitmox.net",
    "https://hitmos.fm",
)
HITMO_TIMEOUT = 10.0
HITMO_USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/124.0.0.0 Safari/537.36"
)


def hitmo_cache_dir() -> Path:
    """Folder where Hitmo previews are cached as local files."""
    directory = config_dir() / "hitmo_preview_cache"
    try:
        directory.mkdir(parents=True, exist_ok=True)
    except OSError:
        pass
    return directory


def prepare_hitmo_cache() -> Path:
    """Empty the preview cache; called once when the player starts."""
    directory = config_dir() / "hitmo_preview_cache"
    shutil.rmtree(directory, ignore_errors=True)
    return hitmo_cache_dir()

# Hard wall-clock limit for one online stage (search request, link
# resolution or download).  Workers use it in addition to the per-request
# socket timeout so a stalled response can never freeze the UI.
ONLINE_STAGE_TIMEOUT = 15.0

_DEFAULT_INVIDIOUS_INSTANCES = (
    "https://yt.chocolatemoo53.com",
    "https://inv.nadeko.net",
    "https://invidious.nerdvpn.de",
    "https://invidious.tiekoetter.com",
    "https://invidious.f5.si",
    "https://yewtu.be",
    "https://invidious.privacyredirect.com",
    "https://iv.melmac.space",
    "https://invidious.jing.rocks",
    "https://invidious.reallyaweso.me",
)
_DEFAULT_PIPED_INSTANCES = (
    "https://api.piped.private.coffee",
    "https://pipedapi.ducks.party",
    "https://pipedapi.kavin.rocks",
    "https://pipedapi.reallyaweso.me",
    "https://pipedapi.leptons.xyz",
    "https://pipedapi.orangenet.cc",
    "https://pipedapi-libre.kavin.rocks",
    "https://piped-api.privacy.com.de",
)


def _env_instances(name: str, default: tuple[str, ...]) -> tuple[str, ...]:
    raw = os.environ.get(name, "").strip()
    if not raw:
        return default
    parts = re.split(r"[,;\s]+", raw)
    values = tuple(part.strip().rstrip("/") for part in parts if part.strip())
    return values or default


INVIDIOUS_INSTANCES = _env_instances(
    "AURISON_INVIDIOUS_INSTANCES", _DEFAULT_INVIDIOUS_INSTANCES
)
PIPED_INSTANCES = _env_instances(
    "AURISON_PIPED_INSTANCES", _DEFAULT_PIPED_INSTANCES
)

INSTANCE_SEARCH_TIMEOUT = 6.0
INSTANCE_STREAM_TIMEOUT = 3.0

_preferred_instances: dict[str, str] = {}
_preferred_lock = threading.Lock()


def format_for(source: str) -> str:
    return SOURCE_FORMATS.get(source, DOWNLOAD_FORMAT)


@dataclass
class SearchResult:
    source: str
    title: str
    uploader: str
    duration_ms: int
    url: str
    kind: str = "track"
    track_count: int = 0
    preview_only: bool = False
    stream_url: str = ""
    download_url: str = ""
    provider: str = ""

    @property
    def source_name(self) -> str:
        return SOURCE_LABELS.get(self.source, self.source)

    @property
    def artist(self) -> str:
        """Normalized provider-independent artist name."""
        return self.uploader

    @property
    def duration(self) -> int:
        """Normalized provider-independent duration in milliseconds."""
        return self.duration_ms

    @property
    def is_album(self) -> bool:
        return self.kind == "album"

    def subtitle(self) -> str:
        parts: list[str] = []
        if self.uploader:
            parts.append(self.uploader)
        if self.is_album:
            parts.append(tr("альбом"))
            if self.track_count > 0:
                parts.append(track_count(self.track_count))
        elif self.duration_ms > 0:
            parts.append(_format_duration(self.duration_ms))
        if self.preview_only:
            parts.append(tr("фрагмент 30 сек"))
        return " · ".join(parts)


class DownloadCancelled(Exception):
    pass


class SourceTimeoutError(RuntimeError):
    """A network stage exceeded the hard online deadline."""

    def __init__(self, message: str | None = None) -> None:
        super().__init__(
            message
            or tr(
                "Источник не отвечает. Попробуйте другой или повторите позже"
            )
        )


class HitmoError(RuntimeError):
    """A user-facing Hitmo failure (unreachable mirror, bad HTML)."""


def _is_timeout(error: object) -> bool:
    if isinstance(error, (TimeoutError, socket.timeout)):
        return True
    reason = getattr(error, "reason", None)
    if isinstance(reason, (TimeoutError, socket.timeout)):
        return True
    text = f"{reason or ''} {error}".casefold()
    return "timed out" in text or "timeout" in text


class LightAudioError(RuntimeError):
    """A user-facing LightAudio failure (blocked, unreachable, bad HTML)."""


_lightaudio_gate = threading.BoundedSemaphore(
    LIGHTAUDIO_MAX_CONCURRENCY
)


@dataclass
class ProviderReport:
    """Per-source outcome of one aggregated search."""

    source: str
    label: str
    count: int = 0
    error: str = ""
    requested: bool = True
    preview_only: bool = False
    available: bool = True

    @property
    def status(self) -> str:
        if not self.available or self.error:
            return "unavailable"
        if self.preview_only:
            return "preview"
        return "ok"


@dataclass
class SearchReport:
    """Results, errors and per-source diagnostics for one search."""

    results: list[SearchResult] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    providers: dict[str, ProviderReport] = field(default_factory=dict)
    requested_sources: tuple[str, ...] = ()

    @property
    def any_success(self) -> bool:
        """True when at least one enabled adapter answered successfully."""
        return any(
            report.requested and report.available and not report.error
            for report in self.providers.values()
        )

    @property
    def successful_sources(self) -> list[str]:
        return [
            key
            for key, report in self.providers.items()
            if report.requested and report.available and not report.error
        ]


class MusicAggregatorService:
    """Provider-independent online music service.

    Search fans out to all adapters in parallel, normalizes results, removes
    duplicates and keeps only plausible music tracks.  Preview and download
    prefer a provider's direct audio URL (Invidious/Piped, VK, LightAudio,
    Hitmo) and use yt-dlp only as a last resort with retry/cookie fallback.
    """

    def search(
        self,
        query: str,
        scope: str = "tracks",
        limit: int = SEARCH_LIMIT,
        sources: list[str] | set[str] | tuple[str, ...] | None = None,
    ) -> tuple[list[SearchResult], list[str]]:
        report = self.search_report(query, scope, limit, sources)
        return report.results, report.errors

    def search_report(
        self,
        query: str,
        scope: str = "tracks",
        limit: int = SEARCH_LIMIT,
        sources: list[str] | set[str] | tuple[str, ...] | None = None,
    ) -> SearchReport:
        """Search only the selected adapters and return per-source details.

        ``sources=None`` means "every provider" (the historic behaviour).
        An empty collection is a valid selection meaning "no adapters": no
        network request is sent at all.  Unknown keys are ignored.
        """
        specs = [
            spec for spec in PROVIDERS if scope != "albums" or spec.albums
        ]
        spec_keys = {spec.key for spec in specs}
        if sources is None:
            enabled = set(spec_keys)
        else:
            enabled = {
                str(source) for source in sources if str(source) in spec_keys
            }

        reports = {
            spec.key: ProviderReport(
                source=spec.key,
                label=spec.label,
                requested=spec.key in enabled,
                preview_only=spec.preview_only,
                available=provider_available(spec),
            )
            for spec in specs
        }
        requested = [spec for spec in specs if spec.key in enabled]
        report = SearchReport(
            providers=reports,
            requested_sources=tuple(spec.key for spec in requested),
        )
        if not requested:
            return report

        providers: list[
            tuple[str, Callable[[str, int], list[SearchResult]]]
        ] = []
        for spec in requested:
            if scope == "albums":
                providers.append((spec.key, search_youtube_albums))
            else:
                providers.append(
                    (
                        spec.key,
                        lambda query, limit, key=spec.key: search_tracks(
                            key, query, limit
                        ),
                    )
                )

        results: list[SearchResult] = []
        max_workers = max(1, len(providers))
        executor = concurrent.futures.ThreadPoolExecutor(
            max_workers=max_workers
        )
        try:
            futures = {
                executor.submit(provider, query, limit): source
                for source, provider in providers
            }
            for future in concurrent.futures.as_completed(
                futures, timeout=max(1.0, ONLINE_STAGE_TIMEOUT - 1.0)
            ):
                source = futures[future]
                provider_report = reports[source]
                try:
                    found = future.result()
                except Exception as error:  # noqa: BLE001 - report to UI
                    provider_report.error = clean_error(error)
                    provider_report.available = False
                    label = SOURCE_LABELS.get(source, source)
                    detail = provider_report.error
                    if not detail.startswith(label):
                        detail = f"{label}: {detail}"
                    report.errors.append(detail)
                    continue
                provider_report.count = len(found)
                provider_report.error = ""
                results.extend(found)
        except concurrent.futures.TimeoutError:
            # One slow source must not hold back the whole stage: the
            # healthy adapters above keep their results and the stalled
            # ones are reported as unavailable.
            message = tr(
                "Источник не отвечает. Попробуйте другой или повторите позже"
            )
            for future, source in futures.items():
                if future.done():
                    continue
                provider_report = reports[source]
                if provider_report.error or not provider_report.requested:
                    continue
                provider_report.error = message
                provider_report.available = False
                label = SOURCE_LABELS.get(source, source)
                report.errors.append(f"{label}: {message}")
        finally:
            executor.shutdown(wait=False, cancel_futures=True)

        report.results = self._dedupe(
            [result for result in results if track_duration_ok(result)]
        )
        return report

    def resolve_preview(
        self,
        result: SearchResult,
    ) -> tuple[str, str, int]:
        if result.preview_only and result.url:
            return result.url, result.title, 30_000

        if result.source == "hitmo":
            # Hitmo trickles direct links out too slowly for streaming, so
            # download the whole file to the local cache and play that.
            return self._cache_hitmo_preview(result)

        # Invidious/Piped put a ready-to-play audio proxy URL on the search
        # result, so YouTube playback starts immediately instead of waiting
        # for yt-dlp to extract a signed stream.
        if result.stream_url:
            return result.stream_url, result.title, result.duration_ms

        if result.source == "youtube":
            try:
                stream_url = self._resolve_youtube_stream(result)
                if stream_url:
                    return stream_url, result.title, result.duration_ms
            except Exception:  # noqa: BLE001 - fall through to yt-dlp
                pass
        elif result.source == "lightaudio":
            stream_url = self._resolve_lightaudio_urls(
                result, force_refresh=False
            )
            return stream_url, result.title, result.duration_ms

        options = self._media_options(result)
        try:
            info = self._extract_info(result.url, options)
            stream_url, title, duration_ms = stream_from_info(info, result)
        except Exception as error:  # noqa: BLE001 - fall back to a preview
            fallback = self._itunes_preview(result)
            if fallback is not None:
                return fallback
            raise error
        if not stream_url:
            fallback = self._itunes_preview(result)
            if fallback is not None:
                return fallback
            raise RuntimeError(
                tr("Источник не вернул аудио для прослушивания")
            )
        # YouTube streams extracted by yt-dlp are still signed googlevideo
        # URLs and may already answer 403/503.  Check once so the player
        # gets the iTunes preview instead of an avoidable playback error.
        if (
            result.source == "youtube"
            and not _stream_available(stream_url)
        ):
            fallback = self._itunes_preview(result)
            if fallback is not None:
                return fallback
        return stream_url, title, duration_ms

    def resolve_preview_fallback(
        self,
        result: SearchResult,
    ) -> tuple[str, str, int]:
        """Find a playable preview after the resolved stream failed.

        Signed Deezer URLs can expire between search and playback, so a
        preview-only result is refreshed first.  For YouTube the Invidious
        and Piped instances are asked again for a fresh proxy URL, yt-dlp is
        tried once, and the iTunes preview is the last resort.
        """
        if result.preview_only:
            refreshed = self._refresh_preview(result)
            if refreshed is not None:
                return refreshed
        if result.source == "youtube":
            try:
                stream_url = self._resolve_youtube_stream(
                    result, force_refresh=True
                )
                if stream_url:
                    return stream_url, result.title, result.duration_ms
            except Exception:  # noqa: BLE001 - try yt-dlp below
                pass
            try:
                info = self._extract_info(
                    result.url, self._media_options(result)
                )
                stream_url, title, duration_ms = stream_from_info(
                    info, result
                )
                # Do not hand the player a signed URL that already answers
                # 403/503; the iTunes preview is a better last resort.
                if stream_url and _stream_available(stream_url):
                    return stream_url, title, duration_ms
            except Exception:  # noqa: BLE001 - use the iTunes preview
                pass
        elif result.source == "lightaudio":
            try:
                stream_url = self._resolve_lightaudio_urls(
                    result, force_refresh=True
                )
                if stream_url:
                    return stream_url, result.title, result.duration_ms
            except Exception:  # noqa: BLE001 - use the iTunes preview
                pass
        elif result.source == "hitmo":
            try:
                return self._cache_hitmo_preview(result, force_refresh=True)
            except Exception:  # noqa: BLE001 - use the iTunes preview
                pass
        fallback = self._itunes_preview(result)
        if fallback is not None:
            return fallback
        raise RuntimeError(
            tr("Источник не вернул аудио для прослушивания")
        )

    def _refresh_preview(
        self, result: SearchResult
    ) -> tuple[str, str, int] | None:
        if result.source not in ("deezer", "itunes"):
            return None
        query = self._preview_query(result)
        if not query:
            return None
        try:
            candidates = search_tracks(result.source, query, 5)
        except Exception:  # noqa: BLE001 - optional fallback
            return None
        key = dedupe_key(result)
        for candidate in candidates:
            if not candidate.preview_only or not candidate.url:
                continue
            if dedupe_key(candidate) != key:
                continue
            title = f"{candidate.title} · {tr('фрагмент 30 сек')}"
            return candidate.url, title, 30_000
        return None

    @staticmethod
    def _preview_query(result: SearchResult) -> str:
        return " ".join(
            part for part in (result.uploader, result.title) if part
        ).strip()

    def _refresh_hitmo(
        self, result: SearchResult
    ) -> tuple[str, str, int] | None:
        """Find a fresh Hitmo file link after a playback failure."""
        query = self._preview_query(result)
        if not query:
            return None
        try:
            candidates = search_tracks("hitmo", query, 5)
        except Exception:  # noqa: BLE001 - optional fallback
            return None
        key = dedupe_key(result)
        for candidate in candidates:
            if not candidate.download_url:
                continue
            if dedupe_key(candidate) != key:
                continue
            result.stream_url = candidate.stream_url
            result.download_url = candidate.download_url
            result.url = candidate.url
            return (
                candidate.download_url,
                candidate.title,
                candidate.duration_ms,
            )
        return None

    def _cache_hitmo_preview(
        self, result: SearchResult, force_refresh: bool = False
    ) -> tuple[str, str, int]:
        """Download a Hitmo track into the preview cache and return its path."""
        url = "" if force_refresh else (result.stream_url or result.download_url)
        if not url:
            refreshed = self._refresh_hitmo(result)
            if refreshed is not None:
                url = refreshed[0]
        if not url:
            raise HitmoError(
                tr("Hitmo: не удалось получить ссылку на трек.")
            )
        try:
            path = self._http_download(url, hitmo_cache_dir(), result)
        except (DownloadCancelled, SourceTimeoutError):
            raise
        except Exception:
            if force_refresh:
                raise
            refreshed = self._refresh_hitmo(result)
            if refreshed is None:
                raise
            path = self._http_download(
                refreshed[0], hitmo_cache_dir(), result
            )
        return str(path), result.title, result.duration_ms

    def download(
        self,
        result: SearchResult,
        target_folder: str | Path,
        progress_hook: Callable[[dict], None] | None = None,
    ) -> SearchResult:
        target = Path(target_folder)
        target.mkdir(parents=True, exist_ok=True)

        candidates: list[SearchResult] = []
        if not result.preview_only:
            candidates.append(result)
        else:
            alternative = self._find_alternative(result)
            if alternative is not None:
                candidates.append(alternative)

        last_error: Exception | None = None
        for candidate in candidates:
            # Providers that expose a direct audio URL (Invidious/Piped,
            # VK, LightAudio) are downloaded over plain HTTP first.  This is
            # much faster and far more reliable than yt-dlp extraction.
            direct_url = ""
            try:
                direct_url = self._direct_download_url(candidate)
            except DownloadCancelled:
                raise
            except SourceTimeoutError:
                # Do not start another blocking yt-dlp stage after a hard
                # timeout: the user already waited 15 seconds.
                raise
            except Exception as error:  # noqa: BLE001 - use yt-dlp below
                last_error = error
            if direct_url:
                try:
                    self._http_download(
                        direct_url, target, candidate, progress_hook
                    )
                    return candidate
                except DownloadCancelled:
                    raise
                except SourceTimeoutError:
                    raise
                except Exception as error:  # noqa: BLE001 - try yt-dlp
                    last_error = error
                    if candidate.source == "lightaudio":
                        # The storage link can expire between search and
                        # download.  Re-resolve it from the saved results
                        # page and retry once instead of restarting the
                        # whole aggregated search.
                        try:
                            refreshed = self._resolve_lightaudio_urls(
                                candidate, force_refresh=True
                            )
                            self._http_download(
                                refreshed,
                                target,
                                candidate,
                                progress_hook,
                            )
                            return candidate
                        except DownloadCancelled:
                            raise
                        except SourceTimeoutError:
                            raise
                        except Exception as retry_error:  # noqa: BLE001
                            last_error = retry_error
                            continue
            if candidate.source in ("lightaudio", "hitmo"):
                # These providers serve plain HTTP files; yt-dlp is never
                # the right fallback and would only hide the real error.
                continue

            options = self._download_options(
                candidate, target, progress_hook
            )
            try:
                self._download_url(candidate.url, options)
                return candidate
            except DownloadCancelled:
                raise
            except Exception as error:  # noqa: BLE001 - try the next source
                last_error = error
                if candidate is result and not result.preview_only:
                    alternative = self._find_alternative(result)
                    if alternative is not None:
                        candidates.append(alternative)

        if last_error is not None:
            raise last_error
        raise RuntimeError(
            tr(
                "Для этого источника доступен только 30-секундный "
                "фрагмент. Выберите другой результат."
            )
        )

    # ---- direct audio helpers ------------------------------------------

    def _direct_download_url(self, result: SearchResult) -> str:
        if result.is_album:
            return ""
        if result.source == "youtube":
            # Re-resolve so a stale search-time proxy URL is not reused.
            return self._resolve_youtube_stream(
                result, force_refresh=True
            ) or ""
        if result.source == "lightaudio":
            return self._resolve_lightaudio_urls(
                result, force_refresh=False
            )
        if result.source == "hitmo":
            return result.stream_url or result.download_url
        if result.download_url:
            return result.download_url
        if result.source == "vk":
            return result.stream_url or ""
        return ""

    def _resolve_youtube_stream(
        self,
        result: SearchResult,
        force_refresh: bool = False,
    ) -> str:
        """Return a directly playable YouTube audio URL.

        Invidious' ``/latest_version`` proxy hides the signed
        ``googlevideo`` URL that frequently answers 403/503; Piped's
        ``/streams`` endpoint is raced alongside it.  Callers fall back to
        yt-dlp when this raises.
        """
        if result.stream_url and not force_refresh:
            return result.stream_url

        video_id = youtube_video_id(result.url)
        if not video_id:
            raise RuntimeError(
                tr("Источник не вернул аудио для прослушивания")
            )

        # Race both backends together: a blocked Invidious list must not
        # delay a working Piped instance (and vice versa).
        candidates: list[
            tuple[str, str, Callable[[], str | None]]
        ] = [
            (
                "invidious",
                base,
                lambda base=base: _validated_invidious_audio(
                    base, video_id
                ),
            )
            for base in INVIDIOUS_INSTANCES
        ]
        candidates.extend(
            (
                "piped",
                base,
                lambda base=base: _piped_audio_url(base, video_id),
            )
            for base in PIPED_INSTANCES
        )
        stream_url = (
            _race_loaders(candidates, timeout=INSTANCE_STREAM_TIMEOUT)
            if candidates
            else None
        )
        if isinstance(stream_url, str) and stream_url:
            return stream_url

        raise RuntimeError(
            tr("Источник не вернул аудио для прослушивания")
        )

    def _resolve_lightaudio_urls(
        self,
        result: SearchResult,
        force_refresh: bool = False,
    ) -> str:
        """Return a fresh LightAudio file URL.

        Storage links can expire after a while.  The search result remembers
        the original results page (``result.url`` plus the item id in the
        fragment), so only that page is requested again and the matching
        item is refreshed instead of rerunning a full aggregated search.
        """
        if not force_refresh and result.download_url:
            return result.stream_url or result.download_url

        page_url = (result.url or "").split("#", 1)[0]
        if page_url.startswith("http"):
            try:
                page = _lightaudio_fetch(page_url)
                refreshed = _find_lightaudio_result(page, page_url, result)
            except LightAudioError:
                refreshed = None
            if refreshed is not None:
                result.stream_url = refreshed.stream_url
                result.download_url = refreshed.download_url
                result.url = refreshed.url
                return result.stream_url or result.download_url
            if result.download_url:
                # Keep the old link as a last chance: some storage hosts
                # accept it long after the page token changes.
                return result.stream_url or result.download_url
            raise LightAudioError(
                tr("LightAudio: не удалось обновить ссылку на трек.")
            )

        if result.download_url:
            return result.stream_url or result.download_url
        raise LightAudioError(
            tr("LightAudio: не удалось обновить ссылку на трек.")
        )

    def _http_download(
        self,
        url: str,
        target: Path,
        result: SearchResult,
        progress_hook: Callable[[dict], None] | None = None,
    ) -> Path:
        request = urllib.request.Request(
            url,
            headers={
                "User-Agent": DEFAULT_USER_AGENT,
                "Accept": "audio/*,video/*,*/*",
            },
        )
        try:
            with urllib.request.urlopen(
                request, timeout=ONLINE_STAGE_TIMEOUT
            ) as response:
                content_type = response.headers.get("Content-Type", "")
                try:
                    total = int(
                        response.headers.get("Content-Length") or 0
                    )
                except (TypeError, ValueError):
                    total = 0
                extension = _audio_extension(url, content_type)
                # The file name always comes from the cleaned track title;
                # whatever the server suggests (Content-Disposition) is
                # ignored on purpose.
                path = _unique_path(
                    target,
                    safe_folder_name(clean_track_title(result.title)),
                    extension,
                )
                downloaded = 0
                last_report = 0.0
                try:
                    with path.open("wb") as handle:
                        while True:
                            chunk = response.read(64 * 1024)
                            if not chunk:
                                break
                            handle.write(chunk)
                            downloaded += len(chunk)
                            now = time.monotonic()
                            if (
                                progress_hook is not None
                                and now - last_report >= 0.2
                            ):
                                last_report = now
                                progress_hook(
                                    {
                                        "status": "downloading",
                                        "downloaded_bytes": downloaded,
                                        "total_bytes": total or None,
                                    }
                                )
                except DownloadCancelled:
                    path.unlink(missing_ok=True)
                    raise
                except Exception:
                    path.unlink(missing_ok=True)
                    raise
        except (TimeoutError, socket.timeout) as error:
            raise SourceTimeoutError() from error
        except urllib.error.URLError as error:
            if _is_timeout(error):
                raise SourceTimeoutError() from error
            raise
        if progress_hook is not None:
            progress_hook(
                {"status": "finished", "filename": str(path)}
            )
        return path

    # ---- yt-dlp helpers ------------------------------------------------

    def _extract_info(self, url: str, options: dict) -> object:
        if yt_dlp is None:
            raise RuntimeError(tr("yt-dlp не установлен"))
        last_error: Exception | None = None
        for attempt in range(2):
            attempt_options = dict(options)
            if attempt == 1:
                attempt_options.update(cookie_options())
            try:
                with yt_dlp.YoutubeDL(attempt_options) as ydl:
                    return ydl.extract_info(url, download=False)
            except Exception as error:  # noqa: BLE001 - retry/fallback
                last_error = error
                if attempt == 0 and retryable(error):
                    time.sleep(0.8)
                    continue
                raise
        if last_error is not None:
            raise last_error
        raise RuntimeError(tr("Источник не вернул результаты"))

    def _download_url(self, url: str, options: dict) -> None:
        if yt_dlp is None:
            raise RuntimeError(tr("yt-dlp не установлен"))
        last_error: Exception | None = None
        for attempt in range(2):
            attempt_options = dict(options)
            if attempt == 1:
                attempt_options.update(cookie_options())
            try:
                with yt_dlp.YoutubeDL(attempt_options) as ydl:
                    ydl.download([url])
                return
            except DownloadCancelled:
                raise
            except Exception as error:  # noqa: BLE001 - retry/fallback
                last_error = error
                if attempt == 0 and retryable(error):
                    time.sleep(0.8)
                    continue
                raise
        if last_error is not None:
            raise last_error

    def _media_options(self, result: SearchResult) -> dict:
        options: dict = {
            "quiet": True,
            "no_warnings": True,
            "logger": _QuietLogger(),
            "format": format_for(result.source),
            "noplaylist": not result.is_album,
            "ignoreerrors": False,
            "socket_timeout": int(ONLINE_STAGE_TIMEOUT),
            "retries": 1,
            "fragment_retries": 1,
            "cachedir": False,
            "noprogress": True,
        }
        if result.is_album:
            options["playlistend"] = 1
        return options

    def _download_options(
        self,
        result: SearchResult,
        target: Path,
        progress_hook: Callable[[dict], None] | None,
    ) -> dict:
        if result.is_album:
            album_folder = safe_folder_name(
                clean_track_title(result.title)
            )
            outtmpl = str(
                target
                / album_folder
                / "%(playlist_index)02d - %(title).100B.%(ext)s"
            )
        else:
            filename = safe_folder_name(
                clean_track_title(result.title)
            ).replace("%", "%%")
            outtmpl = str(target / f"{filename}.%(ext)s")
        options: dict = {
            "quiet": True,
            "no_warnings": True,
            "logger": _QuietLogger(),
            "format": format_for(result.source),
            "noplaylist": not result.is_album,
            "ignoreerrors": False,
            "socket_timeout": int(ONLINE_STAGE_TIMEOUT),
            "retries": 2,
            "fragment_retries": 2,
            "windowsfilenames": True,
            "overwrites": False,
            "continuedl": True,
            "outtmpl": outtmpl,
            "cachedir": False,
            "noprogress": True,
            "consoletitle": False,
        }
        if progress_hook is not None:
            options["progress_hooks"] = [progress_hook]
        return options

    def _find_alternative(
        self, result: SearchResult
    ) -> SearchResult | None:
        query = self._preview_query(result)
        if not query:
            return None
        try:
            candidates, _errors = self.search(query, "tracks", 6)
        except Exception:  # noqa: BLE001 - best effort fallback
            return None
        for candidate in candidates:
            if candidate.preview_only:
                continue
            if candidate.url == result.url:
                continue
            if result.duration_ms > 0 and candidate.duration_ms > 0:
                if abs(candidate.duration_ms - result.duration_ms) > 20_000:
                    continue
            return candidate
        return None

    def _itunes_preview(
        self, result: SearchResult
    ) -> tuple[str, str, int] | None:
        query = self._preview_query(result)
        if not query:
            return None
        try:
            data = http_json(
                f"{ITUNES_SEARCH_URL}?term={quote(query)}"
                "&entity=song&limit=5&country=RU"
            )
        except Exception:  # noqa: BLE001 - optional fallback
            return None
        entries = data.get("results") if isinstance(data, dict) else None
        if not isinstance(entries, list):
            return None
        best: dict | None = None
        best_delta: float | None = None
        for entry in entries:
            if not isinstance(entry, dict):
                continue
            preview = entry.get("previewUrl")
            if not isinstance(preview, str) or not preview:
                continue
            delta: float | None = None
            if result.duration_ms > 0:
                try:
                    entry_ms = int(entry.get("trackTimeMillis") or 0)
                except (TypeError, ValueError):
                    entry_ms = 0
                if entry_ms > 0:
                    delta = abs(entry_ms - result.duration_ms)
            if best is None or (
                delta is not None
                and (best_delta is None or delta < best_delta)
            ):
                best = entry
                best_delta = delta
        if best is None:
            return None
        preview = str(best.get("previewUrl") or "")
        title = str(
            best.get("trackName") or result.title
        ).strip() or result.title
        title = f"{title} · {tr('фрагмент 30 сек')}"
        return preview, title, 30_000

    def _dedupe(
        self, results: list[SearchResult]
    ) -> list[SearchResult]:
        order = {source: index for index, source in enumerate(SOURCE_ORDER)}
        ranked = sorted(
            results,
            key=lambda item: (
                order.get(item.source, 99),
                1 if item.preview_only else 0,
            ),
        )
        seen: set[tuple[str, str]] = set()
        unique: list[SearchResult] = []
        for result in ranked:
            key = dedupe_key(result)
            if key in seen:
                continue
            seen.add(key)
            unique.append(result)
        return unique


class _QuietLogger:
    def debug(self, message: str) -> None:
        pass

    def warning(self, message: str) -> None:
        pass

    def error(self, message: str) -> None:
        pass


def _format_duration(duration_ms: int) -> str:
    total_seconds = max(0, int(duration_ms) // 1000)
    minutes, seconds = divmod(total_seconds, 60)
    hours, minutes = divmod(minutes, 60)
    if hours:
        return f"{hours}:{minutes:02d}:{seconds:02d}"
    return f"{minutes}:{seconds:02d}"


def clean_error(error: object) -> str:
    text = str(error).replace("\x1b[0;31m", "").replace("\x1b[0m", "")
    lines = [line.strip() for line in text.splitlines() if line.strip()]
    message = ""
    for line in lines:
        candidate = line
        while candidate.startswith("ERROR:"):
            candidate = candidate[6:].strip()
        if candidate and candidate not in ("ERROR", "ERROR:"):
            message = candidate
            break
    if not message:
        message = lines[0] if lines else type(error).__name__
    if message.startswith("[download] "):
        message = message[11:]
    return message[:320]


def retryable(error: object) -> bool:
    text = str(error).lower()
    return any(
        token in text
        for token in (
            "403",
            "429",
            "forbidden",
            "too many requests",
            "timed out",
            "timeout",
            "temporarily unavailable",
            "service unavailable",
            "connection reset",
            "connection aborted",
            "remote end closed",
            "getaddrinfo failed",
            "503",
            "502",
            "504",
        )
    )


def cookie_options() -> dict:
    browser = os.environ.get("AURISON_COOKIE_BROWSER", "").strip()
    if not browser:
        browser = "edge"
    return {"cookiesfrombrowser": (browser,)}


DEFAULT_USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/124.0 Safari/537.36"
)


def http_json(
    url: str, timeout: float = ONLINE_STAGE_TIMEOUT
) -> object:
    request = urllib.request.Request(
        url,
        headers={
            "User-Agent": DEFAULT_USER_AGENT,
            "Accept": "application/json",
        },
    )
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            return json.loads(
                response.read().decode("utf-8", "replace")
            )
    except (TimeoutError, socket.timeout) as error:
        raise SourceTimeoutError() from error
    except urllib.error.URLError as error:
        if _is_timeout(error):
            raise SourceTimeoutError() from error
        raise


def http_text(
    url: str,
    timeout: float = ONLINE_STAGE_TIMEOUT,
    headers: dict[str, str] | None = None,
) -> str:
    request_headers = {
        "User-Agent": DEFAULT_USER_AGENT,
        "Accept": "text/html,application/xhtml+xml",
    }
    if headers:
        request_headers.update(headers)
    request = urllib.request.Request(url, headers=request_headers)
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            return response.read().decode("utf-8", "replace")
    except (TimeoutError, socket.timeout) as error:
        raise SourceTimeoutError() from error
    except urllib.error.URLError as error:
        if _is_timeout(error):
            raise SourceTimeoutError() from error
        raise


def youtube_video_id(value: str) -> str:
    """Extract an 11-character YouTube id from a URL or raw id."""
    text = (value or "").strip()
    if not text:
        return ""
    if re.fullmatch(r"[A-Za-z0-9_-]{11}", text):
        return text
    try:
        parts = urlsplit(text)
    except ValueError:
        return ""
    host = parts.netloc.casefold()
    path = parts.path
    candidate = ""
    if host.endswith("youtu.be"):
        candidate = path.strip("/").split("/")[0]
    elif "youtube" in host:
        if path.startswith("/watch"):
            candidate = parse_qs(parts.query).get("v", [""])[0]
        elif path.startswith(("/shorts/", "/embed/", "/v/")):
            candidate = path.strip("/").split("/")[1]
    elif path.startswith("/watch"):
        # Piped search returns relative URLs like "/watch?v=ID".
        candidate = parse_qs(parts.query).get("v", [""])[0]
    if re.fullmatch(r"[A-Za-z0-9_-]{11}", candidate or ""):
        return candidate
    return ""


def _preferred_instance(kind: str) -> str:
    with _preferred_lock:
        return _preferred_instances.get(kind, "")


def _remember_instance(kind: str, base: str) -> None:
    with _preferred_lock:
        _preferred_instances[kind] = base


def _reset_instance_cache() -> None:
    """Clear the preferred-instance cache (used by tests)."""
    with _preferred_lock:
        _preferred_instances.clear()


def _race_loaders(
    candidates: list[tuple[str, str, Callable[[], object]]],
    timeout: float,
) -> object:
    """Return the first successful loader result.

    A successful empty list is a valid answer (the query has no matches).
    ``None`` means every instance failed.
    """
    if not candidates:
        return None

    # A previously working instance is tried alone first so the common path
    # performs a single request instead of waking the whole instance list.
    preferred_empty = False
    for kind, base, loader in candidates:
        if _preferred_instance(kind) != base:
            continue
        try:
            value = loader()
        except Exception:  # noqa: BLE001 - fall back to the full race
            continue
        if value is None:
            continue
        if isinstance(value, list) and not value:
            # An empty answer may be genuine, but a degraded instance would
            # otherwise hide results available elsewhere.  Give the others
            # a short grace period to produce something better.
            preferred_empty = True
            break
        return value

    executor = concurrent.futures.ThreadPoolExecutor(
        max_workers=max(1, len(candidates))
    )
    fallback_empty: list = []
    saw_empty = preferred_empty
    race_timeout = min(1.5, timeout) if preferred_empty else timeout
    try:
        futures = {
            executor.submit(loader): (kind, base)
            for kind, base, loader in candidates
        }
        try:
            for future in concurrent.futures.as_completed(
                futures, timeout=race_timeout
            ):
                kind, base = futures[future]
                try:
                    value = future.result()
                except Exception:  # noqa: BLE001 - try another instance
                    continue
                if value is None:
                    continue
                if isinstance(value, list) and not value:
                    saw_empty = True
                    fallback_empty = value
                    continue
                _remember_instance(kind, base)
                return value
        except concurrent.futures.TimeoutError:
            pass
    finally:
        executor.shutdown(wait=False, cancel_futures=True)
    if saw_empty:
        return fallback_empty
    return None


def _stream_available(url: str, timeout: float = 4.0) -> bool:
    request = urllib.request.Request(
        url,
        headers={
            "User-Agent": DEFAULT_USER_AGENT,
            "Accept": "audio/*,*/*",
            "Range": "bytes=0-1",
        },
    )
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            status = getattr(response, "status", 200)
            content_type = response.headers.get("Content-Type", "")
    except Exception:  # noqa: BLE001 - this instance cannot serve audio
        return False
    if status not in (200, 206, 416):
        return False
    if status == 416:
        return True
    media_type = content_type.casefold()
    return (
        "text/html" not in media_type
        and "application/json" not in media_type
    )


def _validated_invidious_audio(
    base: str, video_id: str
) -> str | None:
    # itag 140 is m4a/AAC (widely supported by Qt); 251 is Opus fallback.
    for itag in ("140", "251"):
        url = (
            f"{base}/latest_version?id={video_id}"
            f"&itag={itag}&local=true"
        )
        if _stream_available(url):
            return url
    return None


def _piped_audio_url(base: str, video_id: str) -> str | None:
    data = http_json(
        f"{base}/streams/{video_id}",
        timeout=int(INSTANCE_STREAM_TIMEOUT),
    )
    if not isinstance(data, dict):
        return None
    streams = data.get("audioStreams") or data.get("audio_streams") or []
    if not isinstance(streams, list):
        return None
    def rank(stream: dict) -> tuple[int, int]:
        mime = str(stream.get("mimeType") or "").casefold()
        codec = str(stream.get("codec") or "").casefold()
        # Prefer AAC/m4a: it plays everywhere Qt Multimedia is available.
        is_aac = "mp4" in mime or "m4a" in mime or "aac" in codec
        return (
            0 if is_aac else 1,
            -int(stream.get("bitrate") or 0),
        )

    ranked = sorted(
        (item for item in streams if isinstance(item, dict)),
        key=rank,
    )
    for stream in ranked:
        url = str(stream.get("url") or "").strip()
        if url.startswith(("http://", "https://")):
            return url
        proxy = str(stream.get("proxyUrl") or "").strip()
        if proxy.startswith(("http://", "https://")):
            return proxy
    proxy = str(data.get("proxyUrl") or "").strip()
    if proxy.startswith(("http://", "https://")):
        return proxy
    return None


_AUDIO_EXTENSIONS = {
    "audio/mp4": ".m4a",
    "audio/m4a": ".m4a",
    "audio/x-m4a": ".m4a",
    "audio/mpeg": ".mp3",
    "audio/mp3": ".mp3",
    "audio/webm": ".webm",
    "audio/ogg": ".ogg",
    "audio/opus": ".opus",
    "audio/aac": ".aac",
    "audio/flac": ".flac",
    "audio/wav": ".wav",
    "audio/x-wav": ".wav",
}


def _audio_extension(url: str, content_type: str) -> str:
    media_type = content_type.split(";", 1)[0].strip().casefold()
    if media_type in _AUDIO_EXTENSIONS:
        return _AUDIO_EXTENSIONS[media_type]
    suffix = Path(urlsplit(url).path).suffix.casefold()
    if suffix in {
        ".m4a",
        ".mp3",
        ".webm",
        ".ogg",
        ".opus",
        ".aac",
        ".flac",
        ".wav",
    }:
        return suffix
    return ".m4a"


def _unique_path(target: Path, stem: str, extension: str) -> Path:
    path = target / f"{stem}{extension}"
    counter = 1
    while path.exists():
        path = target / f"{stem} ({counter}){extension}"
        counter += 1
    return path


def flat_extract(
    url: str, limit: int, noplaylist: bool = True
) -> list[dict]:
    if yt_dlp is None:
        raise RuntimeError(tr("yt-dlp не установлен"))
    options = {
        "quiet": True,
        "no_warnings": True,
        "logger": _QuietLogger(),
        "extract_flat": "in_playlist",
        "skip_download": True,
        "noplaylist": noplaylist,
        "ignoreerrors": False,
        "socket_timeout": 10,
        "retries": 1,
        "playlistend": max(1, limit),
        "cachedir": False,
    }
    last_error: Exception | None = None
    for attempt in range(2):
        attempt_options = dict(options)
        if attempt == 1:
            attempt_options.update(cookie_options())
        try:
            with yt_dlp.YoutubeDL(attempt_options) as ydl:
                info = ydl.extract_info(url, download=False)
            break
        except Exception as error:  # noqa: BLE001 - retry once
            last_error = error
            if attempt == 0 and retryable(error):
                time.sleep(0.8)
                continue
            raise
    else:  # pragma: no cover - defensive
        raise RuntimeError(tr("Источник не вернул результаты"))

    if not isinstance(info, dict):
        raise RuntimeError(tr("Источник не вернул результаты"))
    entries = info.get("entries")
    return [entry for entry in (entries or []) if isinstance(entry, dict)]


def entry_to_result(
    entry: dict, source: str, kind: str
) -> SearchResult | None:
    url = (
        entry.get("url")
        or entry.get("webpage_url")
        or entry.get("original_url")
    )
    title = str(entry.get("title") or "").strip()
    if not isinstance(url, str) or not url or not title:
        return None

    if kind == "album" and not (
        "list=" in url or "/playlist" in url or "/sets/" in url
    ):
        return None

    uploader = str(
        entry.get("uploader")
        or entry.get("channel")
        or entry.get("artist")
        or entry.get("creator")
        or ""
    ).strip()
    duration_raw = entry.get("duration")
    try:
        duration_ms = int(float(duration_raw) * 1000) if duration_raw else 0
    except (TypeError, ValueError):
        duration_ms = 0

    count_raw = (
        entry.get("playlist_count")
        or entry.get("n_entries")
        or entry.get("track_count")
        or 0
    )
    try:
        count = int(count_raw)
    except (TypeError, ValueError):
        count = 0

    return SearchResult(
        source=source,
        title=title,
        uploader=uploader,
        duration_ms=duration_ms,
        url=url,
        kind=kind,
        track_count=count,
    )


def track_duration_ok(result: SearchResult) -> bool:
    if result.is_album:
        return True
    duration = result.duration_ms
    if duration <= 0:
        return True
    return MIN_TRACK_MS <= duration <= MAX_TRACK_MS


def _filter_tracks(
    results: list[SearchResult], limit: int
) -> list[SearchResult]:
    filtered = [result for result in results if track_duration_ok(result)]
    return filtered[:limit]


def search_tracks(source: str, query: str, limit: int) -> list[SearchResult]:
    fetch_limit = min(max(limit * 3, limit), 40)
    if source == "youtube":
        return _search_youtube_tracks(query, limit, fetch_limit)
    if source == "rutube":
        return _search_rutube(query, limit, fetch_limit)
    if source == "deezer":
        return _search_deezer(query, limit, fetch_limit)
    if source == "vk":
        return _search_vk(query, limit, fetch_limit)
    if source == "lightaudio":
        return _search_lightaudio(query, limit)
    if source == "hitmo":
        return _search_hitmo(query, limit)
    if source == "itunes":
        return _search_itunes(query, limit)
    return []


def _search_youtube_tracks(
    query: str, limit: int, fetch_limit: int
) -> list[SearchResult]:
    # Invidious and Piped are raced in parallel.  Both are plain JSON APIs
    # without JavaScript challenges and return an audio proxy URL, so search
    # and playback do not wait for yt-dlp.
    results = _search_youtube_instances(query, fetch_limit)
    if results is None:
        # Last resort only: every instance failed.  yt-dlp can still find
        # the track, though it is slower.
        entries = flat_extract(
            f"ytsearch{fetch_limit}:{query}", fetch_limit
        )
        results = []
        for entry in entries:
            result = entry_to_result(entry, "youtube", "track")
            if result is not None:
                results.append(result)
    return _filter_tracks(results, limit)


def _search_youtube_instances(
    query: str, fetch_limit: int
) -> list[SearchResult] | None:
    """Search YouTube through Invidious/Piped.

    Returns ``None`` when no instance answered, and a (possibly empty) list
    when at least one instance answered successfully.
    """
    candidates: list[
        tuple[str, str, Callable[[], list[SearchResult]]]
    ] = []
    for base in INVIDIOUS_INSTANCES:
        candidates.append(
            (
                "invidious",
                base,
                lambda base=base: _invidious_search(base, query),
            )
        )
    for base in PIPED_INSTANCES:
        candidates.append(
            (
                "piped",
                base,
                lambda base=base: _piped_search(base, query),
            )
        )
    if not candidates:
        return None
    result = _race_loaders(candidates, timeout=INSTANCE_SEARCH_TIMEOUT)
    return result if isinstance(result, list) else None


def _invidious_search(base: str, query: str) -> list[SearchResult]:
    data = http_json(
        f"{base}/api/v1/search?q={quote(query)}&type=video",
        timeout=int(INSTANCE_SEARCH_TIMEOUT),
    )
    if not isinstance(data, list):
        raise RuntimeError(tr("Источник не вернул результаты"))
    results: list[SearchResult] = []
    for item in data:
        if not isinstance(item, dict):
            continue
        video_id = str(item.get("videoId") or "").strip()
        title = str(item.get("title") or "").strip()
        if not video_id or not title:
            continue
        try:
            duration_ms = int(
                float(item.get("lengthSeconds") or 0) * 1000
            )
        except (TypeError, ValueError):
            duration_ms = 0
        uploader = str(
            item.get("author") or item.get("authorId") or ""
        ).strip()
        results.append(
            SearchResult(
                source="youtube",
                title=title,
                uploader=uploader,
                duration_ms=duration_ms,
                url=f"https://www.youtube.com/watch?v={video_id}",
                stream_url=(
                    f"{base}/latest_version?id={video_id}"
                    "&itag=140&local=true"
                ),
                download_url=(
                    f"{base}/latest_version?id={video_id}"
                    "&itag=140&local=true"
                ),
                provider="invidious",
            )
        )
    return results


def _piped_search(base: str, query: str) -> list[SearchResult]:
    data = http_json(
        f"{base}/search?q={quote(query)}&filter=videos",
        timeout=int(INSTANCE_SEARCH_TIMEOUT),
    )
    items = data.get("items") if isinstance(data, dict) else None
    if not isinstance(items, list):
        raise RuntimeError(tr("Источник не вернул результаты"))
    results: list[SearchResult] = []
    for item in items:
        if not isinstance(item, dict):
            continue
        raw_url = str(
            item.get("url") or item.get("path") or ""
        ).strip()
        title = str(item.get("title") or "").strip()
        video_id = youtube_video_id(raw_url)
        if not video_id or not title:
            continue
        try:
            duration_ms = int(float(item.get("duration") or 0) * 1000)
        except (TypeError, ValueError):
            duration_ms = 0
        if duration_ms <= 0:
            continue
        uploader = str(
            item.get("uploaderName") or item.get("uploader") or ""
        ).strip()
        results.append(
            SearchResult(
                source="youtube",
                title=title,
                uploader=uploader,
                duration_ms=duration_ms,
                url=f"https://www.youtube.com/watch?v={video_id}",
                provider="piped",
            )
        )
    return results


def _search_rutube(
    query: str, limit: int, fetch_limit: int
) -> list[SearchResult]:
    data = http_json(
        f"{RUTUBE_SEARCH_URL}?query={quote(query)}"
        f"&limit={fetch_limit}&offset=0"
    )
    if not isinstance(data, dict):
        raise RuntimeError(tr("Источник не вернул результаты"))

    results: list[SearchResult] = []
    for item in data.get("results") or []:
        if not isinstance(item, dict):
            continue
        if any(
            item.get(flag)
            for flag in (
                "is_hidden",
                "is_deleted",
                "is_paid",
                "is_livestream",
            )
        ):
            continue
        video_url = item.get("video_url")
        title = str(item.get("title") or "").strip()
        if not isinstance(video_url, str) or not video_url or not title:
            continue
        author = item.get("author")
        uploader = ""
        if isinstance(author, dict):
            uploader = str(author.get("name") or "").strip()
        if not uploader:
            uploader = str(item.get("feed_name") or "").strip()
        duration_raw = item.get("duration")
        try:
            duration_ms = (
                int(float(duration_raw) * 1000) if duration_raw else 0
            )
        except (TypeError, ValueError):
            duration_ms = 0
        results.append(
            SearchResult(
                source="rutube",
                title=title,
                uploader=uploader,
                duration_ms=duration_ms,
                url=video_url,
                kind="track",
            )
        )
    return _filter_tracks(results, limit)


def _search_deezer(
    query: str, limit: int, fetch_limit: int
) -> list[SearchResult]:
    data = http_json(
        f"{DEEZER_SEARCH_URL}?q={quote(query)}&limit={fetch_limit}"
    )
    entries = data.get("data") if isinstance(data, dict) else None
    if not isinstance(entries, list):
        raise RuntimeError(tr("Источник не вернул результаты"))

    results: list[SearchResult] = []
    for entry in entries:
        if not isinstance(entry, dict):
            continue
        title = str(entry.get("title") or "").strip()
        preview = entry.get("preview")
        artist = entry.get("artist")
        uploader = ""
        if isinstance(artist, dict):
            uploader = str(artist.get("name") or "").strip()
        if not title or not isinstance(preview, str) or not preview:
            continue
        duration_raw = entry.get("duration")
        try:
            duration_ms = (
                int(float(duration_raw) * 1000) if duration_raw else 0
            )
        except (TypeError, ValueError):
            duration_ms = 0
        results.append(
            SearchResult(
                source="deezer",
                title=title,
                uploader=uploader,
                duration_ms=duration_ms,
                url=preview,
                kind="track",
                preview_only=True,
            )
        )
    return _filter_tracks(results, limit)


def _search_itunes(query: str, limit: int) -> list[SearchResult]:
    data = http_json(
        f"{ITUNES_SEARCH_URL}?term={quote(query)}"
        f"&entity=song&limit={min(max(limit * 2, 10), 50)}&country=RU"
    )
    entries = data.get("results") if isinstance(data, dict) else None
    if not isinstance(entries, list):
        raise RuntimeError(tr("Источник не вернул результаты"))

    results: list[SearchResult] = []
    for entry in entries:
        if not isinstance(entry, dict):
            continue
        title = str(entry.get("trackName") or "").strip()
        preview = entry.get("previewUrl")
        uploader = str(entry.get("artistName") or "").strip()
        if not title or not isinstance(preview, str) or not preview:
            continue
        try:
            duration_ms = int(entry.get("trackTimeMillis") or 0)
        except (TypeError, ValueError):
            duration_ms = 0
        results.append(
            SearchResult(
                source="itunes",
                title=title,
                uploader=uploader,
                duration_ms=duration_ms,
                url=preview,
                kind="track",
                preview_only=True,
            )
        )
    return _filter_tracks(results, limit)


def _search_vk(
    query: str, limit: int, fetch_limit: int
) -> list[SearchResult]:
    """Optional VK Music adapter, enabled by an access token."""
    token = os.environ.get("AURISON_VK_TOKEN", "").strip()
    if not token:
        return []
    data = http_json(
        f"{VK_SEARCH_URL}?q={quote(query)}&count={fetch_limit}"
        f"&access_token={quote(token)}&v=5.131"
    )
    if not isinstance(data, dict):
        raise RuntimeError(tr("Источник не вернул результаты"))
    response = data.get("response")
    items: object
    if isinstance(response, dict):
        items = response.get("items")
    elif isinstance(response, list):
        items = response
    else:
        error = data.get("error")
        if isinstance(error, dict):
            raise RuntimeError(
                str(error.get("error_msg") or "VK Music error")
            )
        items = None
    if not isinstance(items, list):
        raise RuntimeError(tr("Источник не вернул результаты"))

    results: list[SearchResult] = []
    for item in items:
        if not isinstance(item, dict):
            continue
        title = str(item.get("title") or "").strip()
        artist = str(item.get("artist") or "").strip()
        stream_url = str(
            item.get("url") or item.get("stream_url") or ""
        ).strip()
        if not title or not stream_url:
            continue
        try:
            duration_ms = int(float(item.get("duration") or 0) * 1000)
        except (TypeError, ValueError):
            duration_ms = 0
        results.append(
            SearchResult(
                source="vk",
                title=title,
                uploader=artist,
                duration_ms=duration_ms,
                url=stream_url,
                stream_url=stream_url,
                download_url=stream_url,
                provider="vk",
            )
        )
    return _filter_tracks(results, limit)


def _search_lightaudio(query: str, limit: int) -> list[SearchResult]:
    """Search LightAudio's HTML results page.

    LightAudio is a regular HTTP source: one page request returns both the
    track metadata and the direct MP3/M4A storage URL.  Requests are
    serialized by a small semaphore so a search, a preview refresh and a
    download cannot hammer the site at the same time.
    """
    page_url = f"{LIGHTAUDIO_SEARCH_URL}{quote(query, safe='')}"
    text = _lightaudio_fetch(page_url)
    if _lightaudio_looks_blocked(text):
        raise LightAudioError(
            tr(
                "LightAudio заблокировал запрос (капча или защита "
                "от ботов). Попробуйте позже."
            )
        )

    results = _parse_lightaudio_items(text, page_url)
    if results:
        return _filter_tracks(results, limit)
    if 'id="result"' in text or 'class="foundnum"' in text:
        # The page is a valid results page that genuinely has no tracks.
        return []
    raise LightAudioError(
        tr("LightAudio вернул неожиданный ответ без списка треков.")
    )


def _lightaudio_fetch(url: str) -> str:
    """Fetch one LightAudio page under the shared concurrency limit."""
    acquired = _lightaudio_gate.acquire(timeout=LIGHTAUDIO_TIMEOUT)
    if not acquired:
        raise LightAudioError(
            tr("LightAudio: превышен лимит одновременных запросов.")
        )
    try:
        return http_text(
            url,
            timeout=int(LIGHTAUDIO_TIMEOUT),
            headers={
                "User-Agent": (
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                    "AppleWebKit/537.36 (KHTML, like Gecko) "
                    "Chrome/124.0.0.0 Safari/537.36"
                ),
                "Accept": (
                    "text/html,application/xhtml+xml,"
                    "application/xml;q=0.9,*/*;q=0.8"
                ),
                "Accept-Language": "ru-RU,ru;q=0.9,en;q=0.8",
                "Referer": "https://web.ligaudio.ru/",
            },
        )
    except urllib.error.HTTPError as error:
        if error.code in (403, 429):
            raise LightAudioError(
                tr(
                    "LightAudio ограничил доступ (HTTP {code}). "
                    "Попробуйте позже."
                ).format(code=error.code)
            ) from error
        raise LightAudioError(
            tr("LightAudio недоступен (HTTP {code}).").format(
                code=error.code
            )
        ) from error
    except urllib.error.URLError as error:
        reason = str(error.reason or "")
        if "timed out" in reason.lower() or "timeout" in reason.lower():
            raise LightAudioError(
                tr("LightAudio не ответил за {seconds} секунд.").format(
                    seconds=int(LIGHTAUDIO_TIMEOUT)
                )
            ) from error
        raise LightAudioError(
            tr("LightAudio недоступен: нет соединения с сайтом.")
        ) from error
    except TimeoutError as error:
        raise LightAudioError(
            tr("LightAudio не ответил за {seconds} секунд.").format(
                seconds=int(LIGHTAUDIO_TIMEOUT)
            )
        ) from error
    except SourceTimeoutError as error:
        raise LightAudioError(
            tr("LightAudio не ответил за {seconds} секунд.").format(
                seconds=int(LIGHTAUDIO_TIMEOUT)
            )
        ) from error
    except Exception as error:  # noqa: BLE001 - report a readable message
        raise LightAudioError(
            tr("LightAudio недоступен: {error}").format(
                error=clean_error(error)
            )
        ) from error
    finally:
        _lightaudio_gate.release()


def _lightaudio_looks_blocked(text: str) -> bool:
    sample = (text or "")[:20000].casefold()
    markers = (
        "captcha",
        "cf-chl",
        "cloudflare",
        "ddos-guard",
        "access denied",
        "too many requests",
        "подтвердите, что вы не робот",
        "доступ ограничен",
        "проверка браузера",
    )
    return any(marker in sample for marker in markers)


_LIGHTAUDIO_ITEM_RE = re.compile(
    r'(<div[^>]*itemprop="track"[^>]*>)(.*?)'
    r"(?=<div[^>]*itemprop=\"track\"|"
    r'<div[^>]*class="[^"]*pagination[^"]*"|</body>|\Z)',
    re.IGNORECASE | re.DOTALL,
)


def _parse_lightaudio_items(
    text: str, page_url: str
) -> list[SearchResult]:
    results: list[SearchResult] = []
    for match in _LIGHTAUDIO_ITEM_RE.finditer(text or ""):
        block = f"{match.group(1)}{match.group(2)}"
        item = _parse_lightaudio_item(block, page_url)
        if item is not None:
            results.append(item)
    return results


def _parse_lightaudio_item(
    block: str, page_url: str
) -> SearchResult | None:
    title_match = re.search(
        r'<span[^>]*class="[^"]*\btitle\b[^"]*"[^>]*'
        r'itemprop="name"[^>]*>(.*?)</span>',
        block,
        re.DOTALL | re.IGNORECASE,
    )
    if title_match is None:
        title_match = re.search(
            r'<span[^>]*itemprop="name"[^>]*>(.*?)</span>',
            block,
            re.DOTALL | re.IGNORECASE,
        )
    title = _strip_tags(title_match.group(1)) if title_match else ""
    title = re.sub(r"\s+([,.;:!?])", r"\1", title).strip()
    if not title:
        return None

    artist_match = re.search(
        r'<span[^>]*class="[^"]*\bautor\b[^"]*"[^>]*>'
        r"(.*?)</span>",
        block,
        re.DOTALL | re.IGNORECASE,
    )
    artist = (
        _strip_tags(artist_match.group(1)) if artist_match else ""
    )
    artist = re.sub(r"\s+([,.;:!?])", r"\1", artist).strip()
    if not artist:
        artist = _lightaudio_meta(block, "byArtist")

    download_url = ""
    for tag in re.findall(
        r"<a\b[^>]*>", block, re.IGNORECASE
    ):
        if not re.search(
            r'class="[^"]*\bdown\b[^"]*"', tag, re.IGNORECASE
        ):
            continue
        href_match = re.search(
            r'href="([^"]+)"', tag, re.IGNORECASE
        )
        if href_match is not None:
            download_url = _normalize_lightaudio_url(
                href_match.group(1)
            )
            break
    if not download_url:
        return None

    duration_ms = _parse_iso_duration(
        _lightaudio_meta(block, "duration")
    )
    if duration_ms <= 0:
        clock_match = re.search(
            r'<span[^>]*class="[^"]*\bd\b[^"]*"[^>]*>'
            r"(.*?)</span>",
            block,
            re.DOTALL | re.IGNORECASE,
        )
        if clock_match is not None:
            duration_ms = _parse_clock(
                _strip_tags(clock_match.group(1))
            )

    item_id_match = re.search(
        r'\bid="([^"]+)"', block, re.IGNORECASE
    )
    item_id = item_id_match.group(1).strip() if item_id_match else ""
    track_url = (
        f"{page_url}#{item_id}" if item_id else page_url
    )
    return SearchResult(
        source="lightaudio",
        title=title,
        uploader=artist,
        duration_ms=duration_ms,
        url=track_url,
        kind="track",
        stream_url=download_url,
        download_url=download_url,
        provider="lightaudio",
    )


def _lightaudio_meta(block: str, prop: str) -> str:
    for tag in re.findall(r"<meta\b[^>]*>", block, re.IGNORECASE):
        if f'itemprop="{prop}"' not in tag:
            continue
        match = re.search(
            r'content="([^"]*)"', tag, re.IGNORECASE
        )
        if match is not None:
            return html.unescape(match.group(1)).strip()
    return ""


def _normalize_lightaudio_url(value: str) -> str:
    url = html.unescape(value or "").strip()
    if url.startswith("//"):
        return f"https:{url}"
    if url.startswith("/"):
        return f"{LIGHTAUDIO_BASE_URL}{url}"
    return url


def _parse_iso_duration(value: str) -> int:
    text = (value or "").strip().upper()
    if not text.startswith("P"):
        return 0
    total = 0
    for amount, unit in re.findall(r"(\d+)([HMS])", text):
        multiplier = {"H": 3_600_000, "M": 60_000, "S": 1_000}[unit]
        total += int(amount) * multiplier
    return total


def _find_lightaudio_result(
    text: str, page_url: str, target: SearchResult
) -> SearchResult | None:
    candidates = _parse_lightaudio_items(text, page_url)
    fragment = urlsplit(target.url).fragment
    if fragment:
        for candidate in candidates:
            if urlsplit(candidate.url).fragment == fragment:
                return candidate
    key = dedupe_key(target)
    for candidate in candidates:
        if dedupe_key(candidate) != key:
            continue
        if (
            target.duration_ms > 0
            and candidate.duration_ms > 0
            and abs(candidate.duration_ms - target.duration_ms) > 15_000
        ):
            continue
        return candidate
    return None


def _search_hitmo(query: str, limit: int) -> list[SearchResult]:
    """Search Hitmo, trying its mirrors in order.

    Each mirror answers with a normal HTML page (the RU mirror uses the
    classic ``tracks__item`` markup, hitmos.fm renders a Next.js payload).
    A failed mirror is reported separately and never turns into a silent
    empty result.
    """
    failures: list[Exception] = []
    answered = False
    for mirror in HITMO_MIRRORS:
        try:
            text = _hitmo_fetch(mirror, query)
        except DownloadCancelled:
            raise
        except SourceTimeoutError as error:
            failures.append(error)
            continue
        except Exception as error:  # noqa: BLE001 - try the next mirror
            failures.append(error)
            continue

        answered = True
        results = _parse_hitmo_items(text, mirror)
        if results:
            return _filter_tracks(results, limit)

    if answered:
        # At least one mirror returned a valid page without matches; that
        # is a healthy empty result, not an error.
        return []

    timeout_error = next(
        (item for item in failures if isinstance(item, SourceTimeoutError)),
        None,
    )
    if timeout_error is not None:
        raise timeout_error
    last = failures[-1] if failures else None
    raise HitmoError(
        tr("Hitmo недоступен: {error}").format(
            error=clean_error(last)
            if last is not None
            else tr("нет соединения с сайтом.")
        )
    )


def _hitmo_fetch(mirror: str, query: str) -> str:
    url = f"{mirror.rstrip('/')}/search?q={quote(query)}"
    try:
        return http_text(
            url,
            timeout=int(HITMO_TIMEOUT),
            headers={
                "User-Agent": HITMO_USER_AGENT,
                "Accept": (
                    "text/html,application/xhtml+xml,"
                    "application/xml;q=0.9,*/*;q=0.8"
                ),
                "Accept-Language": "ru-RU,ru;q=0.9,en;q=0.8",
                "Referer": f"{mirror.rstrip('/')}/",
            },
        )
    except (DownloadCancelled, SourceTimeoutError):
        raise
    except urllib.error.HTTPError as error:
        raise HitmoError(
            tr("Hitmo недоступен (HTTP {code}).").format(
                code=error.code
            )
        ) from error


def _parse_hitmo_items(text: str, mirror: str) -> list[SearchResult]:
    results = _parse_hitmo_classic(text, mirror)
    if not results:
        results = _parse_hitmo_next(text, mirror)

    unique: list[SearchResult] = []
    seen: set[tuple[str, str]] = set()
    for result in results:
        key = (result.title.casefold(), result.uploader.casefold())
        if key in seen:
            continue
        seen.add(key)
        unique.append(result)
    return unique


def _parse_hitmo_classic(text: str, mirror: str) -> list[SearchResult]:
    """Parse the ``tracks__item`` markup used by ru.hitmox.net."""
    results: list[SearchResult] = []
    pattern = re.compile(
        r"(<li[^>]*class=\"[^\"]*tracks__item[^\"]*\"[^>]*>"
        r".*?</li>)",
        re.IGNORECASE | re.DOTALL,
    )
    for block in pattern.findall(text or ""):
        meta_match = re.search(
            r"data-musmeta=(['\"])(.*?)\1",
            block,
            re.DOTALL,
        )
        if meta_match is None:
            continue
        try:
            meta = json.loads(html.unescape(meta_match.group(2)))
        except (TypeError, ValueError):
            continue
        if not isinstance(meta, dict):
            continue

        title = str(meta.get("title") or "").strip()
        artist = str(meta.get("artist") or "").strip()
        file_url = str(meta.get("url") or "").strip()
        if not title:
            title_match = re.search(
                r'class="[^"]*track__title[^"]*"[^>]*>(.*?)</div>',
                block,
                re.DOTALL | re.IGNORECASE,
            )
            title = (
                _strip_tags(title_match.group(1))
                if title_match is not None
                else ""
            )
        if not artist:
            artist_match = re.search(
                r'class="[^"]*track__desc[^"]*"[^>]*>(.*?)</div>',
                block,
                re.DOTALL | re.IGNORECASE,
            )
            artist = (
                _strip_tags(artist_match.group(1))
                if artist_match is not None
                else ""
            )
        if not file_url:
            link_match = re.search(
                r'class="[^"]*track__download-btn[^"]*"[^>]*href="([^"]+)"',
                block,
                re.IGNORECASE,
            )
            if link_match is None:
                link_match = re.search(
                    r'href="([^"]+)"[^>]*class="[^"]*track__download-btn',
                    block,
                    re.IGNORECASE,
                )
            file_url = link_match.group(1) if link_match is not None else ""
        file_url = _hitmo_absolute_url(mirror, file_url)
        if not title or not file_url:
            continue

        duration_ms = 0
        clock_match = re.search(
            r'class="[^"]*track__fulltime[^"]*"[^>]*>(.*?)</div>',
            block,
            re.DOTALL | re.IGNORECASE,
        )
        if clock_match is not None:
            duration_ms = _parse_clock(
                _strip_tags(clock_match.group(1))
            )

        results.append(
            SearchResult(
                source="hitmo",
                title=title,
                uploader=artist,
                duration_ms=duration_ms,
                url=file_url,
                kind="track",
                stream_url=file_url,
                download_url=file_url,
                provider="hitmo",
            )
        )
    return results


def _parse_hitmo_next(text: str, mirror: str) -> list[SearchResult]:
    """Parse the Next.js payload used by hitmos.fm."""
    payload = _decode_next_payload(text)
    if not payload:
        return []

    results: list[SearchResult] = []
    start = 0
    while True:
        marker = payload.find('"list":[', start)
        if marker < 0:
            break
        start = marker + len('"list":')
        items = _extract_json_array(payload, start)
        if items is None:
            continue
        for item in items:
            if not isinstance(item, dict):
                continue
            download_url = str(
                item.get("download") or item.get("play") or ""
            ).strip()
            title = str(item.get("title") or "").strip()
            artist = str(item.get("artist") or "").strip()
            if not download_url or not title:
                continue
            try:
                duration_ms = int(item.get("duration") or 0) * 1000
            except (TypeError, ValueError):
                duration_ms = 0
            file_url = _hitmo_absolute_url(mirror, download_url)
            results.append(
                SearchResult(
                    source="hitmo",
                    title=html.unescape(title),
                    uploader=html.unescape(artist),
                    duration_ms=duration_ms,
                    url=file_url,
                    kind="track",
                    stream_url=file_url,
                    download_url=file_url,
                    provider="hitmo",
                )
            )
    return results


def _decode_next_payload(text: str) -> str:
    chunks: list[str] = []
    pattern = re.compile(
        r"self\.__next_f\.push\(\[1,(\"(?:[^\"\\]|\\.)*\")\]\)",
        re.DOTALL,
    )
    for match in pattern.finditer(text or ""):
        try:
            chunks.append(json.loads(match.group(1)))
        except ValueError:
            continue
    return "".join(chunks)


def _extract_json_array(payload: str, start: int) -> list | None:
    if start >= len(payload) or payload[start] != "[":
        return None
    depth = 0
    in_string = False
    escaped = False
    for index in range(start, len(payload)):
        char = payload[index]
        if in_string:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == '"':
                in_string = False
            continue
        if char == '"':
            in_string = True
        elif char == "[":
            depth += 1
        elif char == "]":
            depth -= 1
            if depth == 0:
                try:
                    value = json.loads(payload[start : index + 1])
                except ValueError:
                    return None
                return value if isinstance(value, list) else None
    return None


def _hitmo_absolute_url(mirror: str, value: str) -> str:
    url = html.unescape(value or "").strip()
    if url.startswith("//"):
        return f"https:{url}"
    if url.startswith("/"):
        return f"{mirror.rstrip('/')}{url}"
    return url


def _strip_tags(value: str) -> str:
    text = re.sub(r"<[^>]+>", " ", value or "")
    return re.sub(r"\s+", " ", html.unescape(text)).strip()


def _parse_clock(value: str) -> int:
    total = 0
    matched = False
    for part in (value or "").strip().split(":"):
        if not part.isdigit():
            return 0
        matched = True
        total = total * 60 + int(part)
    return total * 1000 if matched else 0


def search_youtube_albums(
    query: str, limit: int
) -> list[SearchResult]:
    candidates: list[
        tuple[str, str, Callable[[], list[SearchResult]]]
    ] = [
        (
            "invidious",
            base,
            lambda base=base: _invidious_album_search(
                base, query, limit
            ),
        )
        for base in INVIDIOUS_INSTANCES
    ]
    albums = (
        _race_loaders(candidates, timeout=INSTANCE_SEARCH_TIMEOUT)
        if candidates
        else None
    )
    if isinstance(albums, list) and albums:
        return albums[:limit]

    # Last resort: yt-dlp can still enumerate YouTube playlists.
    url = (
        "https://www.youtube.com/results?search_query="
        + quote_plus(query)
        + "&sp=EgIQAw%253D%253D"
    )
    entries = flat_extract(url, max(limit * 3, 24), noplaylist=False)
    results: list[SearchResult] = []
    for entry in entries:
        result = entry_to_result(entry, "youtube", "album")
        if result is not None:
            results.append(result)
        if len(results) >= limit:
            break
    return results


def _invidious_album_search(
    base: str, query: str, limit: int
) -> list[SearchResult]:
    data = http_json(
        f"{base}/api/v1/search?q={quote(query)}&type=playlist",
        timeout=int(INSTANCE_SEARCH_TIMEOUT),
    )
    if not isinstance(data, list):
        raise RuntimeError(tr("Источник не вернул результаты"))
    results: list[SearchResult] = []
    for item in data:
        if not isinstance(item, dict):
            continue
        playlist_id = str(
            item.get("playlistId") or item.get("playlist_id") or ""
        ).strip()
        title = str(item.get("title") or "").strip()
        if not playlist_id or not title:
            continue
        count_raw = item.get("videoCount") or item.get("video_count") or 0
        try:
            count = int(count_raw)
        except (TypeError, ValueError):
            count = 0
        results.append(
            SearchResult(
                source="youtube",
                title=title,
                uploader=str(
                    item.get("author") or item.get("authorId") or ""
                ).strip(),
                duration_ms=0,
                url=(
                    "https://www.youtube.com/playlist?list="
                    f"{playlist_id}"
                ),
                kind="album",
                track_count=count,
                provider="invidious",
            )
        )
    return results


def stream_from_info(
    info: object,
    result: SearchResult,
) -> tuple[str, str, int]:
    """Pick a playable stream from a track or the first album entry."""
    if not isinstance(info, dict):
        return "", result.title, result.duration_ms

    entries = info.get("entries")
    if isinstance(entries, list):
        for entry in entries:
            if not isinstance(entry, dict):
                continue
            stream_url = entry.get("url")
            if not isinstance(stream_url, str) or not stream_url.startswith(
                ("http://", "https://")
            ):
                continue
            title = str(entry.get("title") or result.title).strip()
            duration = entry.get("duration")
            try:
                duration_ms = (
                    int(float(duration) * 1000)
                    if duration
                    else result.duration_ms
                )
            except (TypeError, ValueError):
                duration_ms = result.duration_ms
            return stream_url, title or result.title, duration_ms

    stream_url = info.get("url")
    if isinstance(stream_url, str) and stream_url.startswith(
        ("http://", "https://")
    ):
        title = str(info.get("title") or result.title).strip()
        duration = info.get("duration")
        try:
            duration_ms = (
                int(float(duration) * 1000)
                if duration
                else result.duration_ms
            )
        except (TypeError, ValueError):
            duration_ms = result.duration_ms
        return stream_url, title or result.title, duration_ms
    return "", result.title, result.duration_ms


def safe_folder_name(name: str) -> str:
    value = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", name).strip(" .")
    value = re.sub(r"\s+", " ", value)
    if len(value) > 80:
        value = value[:80].rstrip(" .")
    return value or "Album"


_NOISE_WORDS = re.compile(
    r"\b(official|unofficial|video|audio|lyrics?|lyric|hd|hq|hdr|"
    r"remaster(?:ed)?|music|clip|topic|vevo|feat|ft|explicit|visualizer)\b",
    re.IGNORECASE,
)
_BRACKETS = re.compile(r"\([^)]*\)|\[[^\]]*\]")
_FEATURING = re.compile(r"\b(?:feat\.?|ft\.?|featuring)\b", re.IGNORECASE)
_PUNCTUATION = re.compile(r"[^0-9a-zа-яё]+", re.IGNORECASE)


def _normalize(text: str) -> str:
    value = _BRACKETS.sub(" ", text or "")
    value = value.replace("ё", "е").replace("Ё", "Е")
    value = _NOISE_WORDS.sub(" ", value)
    value = _PUNCTUATION.sub(" ", value.lower())
    return re.sub(r"\s+", " ", value).strip()


def dedupe_key(result: SearchResult) -> tuple[str, str]:
    # YouTube titles usually look like "Artist - Track"; the channel name is
    # often a lyrics/cover page, so prefer the artist embedded in the title.
    raw_title = _BRACKETS.sub(" ", result.title or "")
    parts = re.split(r"\s+[-–—]\s+", raw_title, maxsplit=1)
    if len(parts) == 2:
        artist_raw = _FEATURING.split(parts[0], maxsplit=1)[0]
        title_raw = _FEATURING.split(parts[1], maxsplit=1)[0]
        artist = _normalize(artist_raw)
        title = _normalize(title_raw)
        if artist and title:
            return artist, title

    artist = _normalize(result.uploader)
    title = _normalize(result.title)
    if artist and title.startswith(artist):
        title = title[len(artist) :].strip()
    return artist, title
