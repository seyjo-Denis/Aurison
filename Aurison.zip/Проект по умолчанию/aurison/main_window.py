from __future__ import annotations

import math
import os
from difflib import SequenceMatcher
from pathlib import Path

from PySide6.QtCore import (
    QByteArray,
    QEvent,
    QPoint,
    QPointF,
    QRectF,
    QSize,
    Qt,
    QTimer,
    QUrl,
    Signal,
)
from PySide6.QtGui import (
    QBrush,
    QColor,
    QDesktopServices,
    QFont,
    QKeySequence,
    QPainter,
    QPen,
    QShortcut,
)
from PySide6.QtMultimedia import QMediaPlayer
from PySide6.QtWidgets import (
    QAbstractItemView,
    QApplication,
    QDialog,
    QFileDialog,
    QFrame,
    QHBoxLayout,
    QHeaderView,
    QInputDialog,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QMainWindow,
    QMenu,
    QMessageBox,
    QPushButton,
    QStackedWidget,
    QStyledItemDelegate,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from aurison.config import ALL_TRACKS, Config
from aurison.duration_probe import DurationProbe
from aurison.hotkeys import GlobalHotkeys
from aurison.i18n import hotkey_labels, set_language, track_count, tr
from aurison.icons import app_icon, icon
from aurison.library import (
    FolderScanThread,
    Track,
    TrackCache,
    format_duration,
    natural_key,
)
from aurison.mini_player import MiniPlayer
from aurison.music_service import (
    PROVIDER_KEYS,
    prepare_hitmo_cache,
    safe_folder_name,
)
from aurison.online import (
    DownloadWorker,
    PreviewWorker,
    SearchResult,
    SearchWorker,
)
from aurison.online_view import OnlineView
from aurison.player import PlaybackController
from aurison.settings_dialog import SettingsDialog
from aurison.widgets import (
    ACCENT,
    ElidedLabel,
    Placeholder,
    PlayerBar,
    ToggleSwitch,
    make_icon_button,
    repolish,
)

BASE_TITLE_COLOR = "#c6cad3"
BASE_TIME_COLOR = "#7f8591"
CURRENT_BG = "#1a1e27"
CURRENT_TITLE = "#aebcff"
CURRENT_TIME = "#96a4d8"
UNKNOWN_DURATION = "—:—"
GRIP_COLOR = "#5d6370"
GRIP_HOVER_COLOR = "#a9b0bf"
GRIP_CURRENT_COLOR = "#8f9bc4"
INDICATOR_PAUSED_COLOR = "#6f7b9f"
# Search hits use their own dark-grey fill plus a bright outline so they can
# never be confused with the (blue) playing row.
SEARCH_BG = "#333842"
SEARCH_BORDER = "#c6cad3"
# Typos are tolerated only above this difflib similarity (60%); exact
# substring matches are always preferred and checked first.
FUZZY_MATCH_THRESHOLD = 0.6


def fuzzy_title_score(query: str, title: str) -> float:
    """Best difflib ratio between the query and a slice of the title.

    Comparing against the whole title punishes long names ("03 - Bravo" vs
    "bravl"), so the query is also slid along titles of similar length.
    """
    if not query or not title:
        return 0.0
    best = SequenceMatcher(None, query, title).ratio()
    size = len(query)
    if size < len(title):
        for start in range(len(title) - size + 1):
            score = SequenceMatcher(
                None, query, title[start : start + size]
            ).ratio()
            if score > best:
                best = score
    return best


class TrackDelegate(QStyledItemDelegate):
    """Paints the playing/hovered row behind the regular item contents."""

    def __init__(self, table: "TrackTable") -> None:
        super().__init__(table)
        self._table = table

    def paint(self, painter, option, index) -> None:
        row = index.row()
        current = row == self._table.current_row_index()
        searched = not current and row == self._table.highlight_row_index()
        hovered = row == self._table.hover_row
        if current:
            painter.fillRect(option.rect, QColor(CURRENT_BG))
        elif searched:
            painter.fillRect(option.rect, QColor(SEARCH_BG))
        elif hovered:
            painter.fillRect(option.rect, QColor("#15181d"))

        if searched:
            self._paint_search_outline(
                painter, option.rect, index.column()
            )

        if index.column() == 0:
            if current:
                self._paint_equalizer(painter, option.rect)
                return
            super().paint(painter, option, index)
            return

        if index.column() == TrackTable.GRIP_COLUMN:
            if current:
                color = GRIP_CURRENT_COLOR
            elif hovered:
                color = GRIP_HOVER_COLOR
            else:
                color = GRIP_COLOR
            painter.save()
            painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
            pen = QPen(QColor(color), 1.4)
            pen.setCapStyle(Qt.PenCapStyle.RoundCap)
            painter.setPen(pen)
            center = option.rect.center()
            for offset in (-4.0, 0.0, 4.0):
                painter.drawLine(
                    QPointF(center.x() - 5.0, center.y() + offset),
                    QPointF(center.x() + 5.0, center.y() + offset),
                )
            painter.restore()
            return

        super().paint(painter, option, index)

    def _paint_search_outline(self, painter, rect, column: int) -> None:
        painter.save()
        painter.setPen(QPen(QColor(SEARCH_BORDER), 1.4))
        painter.drawLine(rect.topLeft(), rect.topRight())
        painter.drawLine(rect.bottomLeft(), rect.bottomRight())
        if column == 0:
            painter.drawLine(rect.topLeft(), rect.bottomLeft())
        if column == TrackTable.GRIP_COLUMN:
            painter.drawLine(rect.topRight(), rect.bottomRight())
        painter.restore()

    def _paint_equalizer(self, painter, rect) -> None:
        playing = self._table.animation_playing()
        phase = self._table.animation_phase()
        if playing:
            heights = [
                4.0
                + 8.0
                * (0.5 + 0.5 * math.sin(phase + index * 1.05))
                for index in range(4)
            ]
            color = QColor(ACCENT)
        else:
            heights = [5.0, 9.0, 6.0, 10.0]
            color = QColor(INDICATOR_PAUSED_COLOR)
        bar_width = 2.6
        gap = 2.4
        total = 4 * bar_width + 3 * gap
        left = rect.center().x() - total / 2.0
        center_y = rect.center().y()
        painter.save()
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(color)
        for index, height in enumerate(heights):
            x = left + index * (bar_width + gap)
            painter.drawRoundedRect(
                QRectF(
                    float(x),
                    float(center_y) - height / 2.0,
                    bar_width,
                    height,
                ),
                1.3,
                1.3,
            )
        painter.restore()


class TrackTable(QTableWidget):
    trackActivated = Signal(int)
    orderChanged = Signal(list)

    GRIP_COLUMN = 3
    GRIP_WIDTH = 30
    DRAG_THRESHOLD = 4
    ANIMATION_INTERVAL_MS = 50
    ANIMATION_STEP = 0.16

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(0, 4, parent)
        self.setObjectName("TrackTable")
        self.setShowGrid(False)
        self.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.setWordWrap(False)
        self.setTextElideMode(Qt.TextElideMode.ElideRight)
        self.setVerticalScrollMode(QAbstractItemView.ScrollMode.ScrollPerPixel)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.setAlternatingRowColors(False)
        self.setIconSize(QSize(14, 14))
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.viewport().setCursor(Qt.CursorShape.PointingHandCursor)
        self.viewport().setMouseTracking(True)
        self.setMouseTracking(True)
        self.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.setItemDelegate(TrackDelegate(self))
        self.verticalHeader().setVisible(False)
        self.verticalHeader().setDefaultSectionSize(42)
        self.horizontalHeader().setVisible(False)
        header = self.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.ResizeMode.Fixed)
        header.resizeSection(0, 38)
        header.setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        header.setSectionResizeMode(2, QHeaderView.ResizeMode.Fixed)
        header.resizeSection(2, 76)
        header.setSectionResizeMode(self.GRIP_COLUMN, QHeaderView.ResizeMode.Fixed)
        header.resizeSection(self.GRIP_COLUMN, self.GRIP_WIDTH)

        self._rows: dict[str, int] = {}
        self._current_path: str | None = None
        self._highlight_path: str | None = None
        self.hover_row = -1
        self._drag_row: int | None = None
        self._drag_origin_y = 0
        self._drag_active = False
        self._drop_row: int | None = None
        self._playing = False
        self._anim_phase = 0.0
        self._anim_timer = QTimer(self)
        self._anim_timer.setInterval(self.ANIMATION_INTERVAL_MS)
        self._anim_timer.timeout.connect(self._advance_animation)
        self._title_font = QFont(self.font())
        self._title_font.setPointSizeF(10.0)
        self._title_bold = QFont(self._title_font)
        self._title_bold.setBold(True)
        self._duration_font = QFont(self.font())
        self._duration_font.setPointSizeF(9.0)

        self.cellDoubleClicked.connect(self._on_double_clicked)

    def set_tracks(self, tracks: list[Track]) -> None:
        self._anim_timer.stop()
        self._playing = False
        self._rows.clear()
        self._current_path = None
        self._highlight_path = None
        self.clearContents()
        self.setRowCount(len(tracks))
        for row, track in enumerate(tracks):
            indicator = QTableWidgetItem("")
            indicator.setFlags(
                Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsSelectable
            )
            indicator.setTextAlignment(Qt.AlignmentFlag.AlignCenter)

            title = QTableWidgetItem(track.title)
            title.setData(Qt.ItemDataRole.UserRole, track.path)
            title.setToolTip(track.title)
            title.setFont(self._title_font)
            title.setForeground(QColor(BASE_TITLE_COLOR))
            title.setTextAlignment(
                Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter
            )

            duration = QTableWidgetItem(
                format_duration(track.duration_ms)
                if track.duration_ms > 0
                else UNKNOWN_DURATION
            )
            duration.setFont(self._duration_font)
            duration.setForeground(QColor(BASE_TIME_COLOR))
            duration.setTextAlignment(
                Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter
            )

            grip = QTableWidgetItem("")
            grip.setFlags(
                Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsSelectable
            )
            grip.setToolTip(tr("Перетащите, чтобы изменить порядок"))

            self.setItem(row, 0, indicator)
            self.setItem(row, 1, title)
            self.setItem(row, 2, duration)
            self.setItem(row, self.GRIP_COLUMN, grip)
            self._rows[track.path] = row
        self.clearSelection()

    def set_current_path(self, path: str | None, playing: bool) -> None:
        if self._current_path and self._current_path in self._rows:
            self._style_row(self._rows[self._current_path], False)
        self._current_path = path if path in self._rows else None
        if self._current_path:
            self._style_row(self._rows[self._current_path], True)
        self._playing = bool(playing) and self._current_path is not None
        self._update_animation()
        self.viewport().update()

    def _style_row(self, row: int, current: bool) -> None:
        for column in range(self.columnCount()):
            if column == self.GRIP_COLUMN:
                continue
            item = self.item(row, column)
            if item is None:
                continue
            item.setBackground(QBrush())
            if column == 0:
                item.setIcon(icon(""))
            elif column == 1:
                item.setFont(self._title_bold if current else self._title_font)
                item.setForeground(
                    QColor(CURRENT_TITLE if current else BASE_TITLE_COLOR)
                )
            elif column == 2:
                item.setFont(self._duration_font)
                item.setForeground(
                    QColor(CURRENT_TIME if current else BASE_TIME_COLOR)
                )
            if current:
                item.setBackground(QColor(CURRENT_BG))

    def animation_playing(self) -> bool:
        return self._playing and self._current_path is not None

    def animation_phase(self) -> float:
        return self._anim_phase

    def _update_animation(self) -> None:
        if (
            self._playing
            and self._current_path is not None
            and self.isVisible()
        ):
            if not self._anim_timer.isActive():
                self._anim_timer.start()
        else:
            self._anim_timer.stop()

    def _advance_animation(self) -> None:
        self._anim_phase = (
            self._anim_phase + self.ANIMATION_STEP
        ) % (2.0 * math.pi)
        row = self.current_row_index()
        item = self.item(row, 0) if row >= 0 else None
        if item is not None:
            self.viewport().update(self.visualItemRect(item))
        else:
            self.viewport().update()

    def showEvent(self, event) -> None:  # noqa: N802
        super().showEvent(event)
        self._update_animation()

    def hideEvent(self, event) -> None:  # noqa: N802
        self._anim_timer.stop()
        super().hideEvent(event)

    def update_duration(self, path: str, duration_ms: int) -> None:
        row = self._rows.get(path)
        if row is None:
            return
        item = self.item(row, 2)
        if item is not None:
            item.setText(
                format_duration(duration_ms)
                if duration_ms > 0
                else UNKNOWN_DURATION
            )

    def retranslate(self) -> None:
        for row in range(self.rowCount()):
            item = self.item(row, self.GRIP_COLUMN)
            if item is not None:
                item.setToolTip(tr("Перетащите, чтобы изменить порядок"))

    def current_row_index(self) -> int:
        return self._rows.get(self._current_path or "", -1)

    def current_track_path(self) -> str | None:
        row = self.currentRow()
        if row < 0:
            return None
        item = self.item(row, 1)
        return item.data(Qt.ItemDataRole.UserRole) if item else None

    def select_path(self, path: str) -> None:
        row = self._rows.get(path)
        if row is None:
            self.clearSelection()
            return
        self.blockSignals(True)
        self.setCurrentCell(row, 1)
        self.blockSignals(False)

    def scroll_to_path(self, path: str) -> None:
        row = self._rows.get(path)
        if row is None:
            return
        item = self.item(row, 1)
        if item is not None:
            self.scrollToItem(
                item, QAbstractItemView.ScrollHint.PositionAtCenter
            )

    def highlight_path(self, path: str) -> None:
        """Mark a row as the current search hit and center it in the view."""
        row = self._rows.get(path)
        if row is None:
            return
        self._highlight_path = path
        self.scroll_to_path(path)
        self.viewport().update()

    def highlight_row_index(self) -> int:
        return self._rows.get(self._highlight_path or "", -1)

    def mousePressEvent(self, event) -> None:  # noqa: N802
        if (
            event.button() == Qt.MouseButton.LeftButton
            and self._highlight_path
        ):
            # Any click in the list drops the search highlight.
            self._highlight_path = None
            self.viewport().update()
        if event.button() == Qt.MouseButton.LeftButton:
            position = event.position().toPoint()
            row = self._grip_row_at(position)
            if row >= 0:
                self._drag_row = row
                self._drag_origin_y = position.y()
                self._drag_active = False
                self._drop_row = row
                self.viewport().setCursor(Qt.CursorShape.ClosedHandCursor)
                self.blockSignals(True)
                self.setCurrentCell(row, 1)
                self.blockSignals(False)
                event.accept()
                return
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event) -> None:  # noqa: N802
        position = event.position().toPoint()
        if self._drag_row is not None:
            if not (event.buttons() & Qt.MouseButton.LeftButton):
                self._reset_drag()
                return
            if (
                abs(position.y() - self._drag_origin_y)
                >= self.DRAG_THRESHOLD
            ):
                self._drag_active = True
            if self._drag_active:
                self._auto_scroll(position.y())
                self._drop_row = self._target_row_at(position.y())
                self.hover_row = self._drag_row
                self.viewport().update()
                event.accept()
                return

        index = self.indexAt(position)
        row = index.row() if index.isValid() else -1
        if row != self.hover_row:
            self.hover_row = row
            self.viewport().update()
        over_grip = (
            index.isValid() and index.column() == self.GRIP_COLUMN
        )
        self.viewport().setCursor(
            Qt.CursorShape.OpenHandCursor
            if over_grip
            else Qt.CursorShape.PointingHandCursor
        )
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event) -> None:  # noqa: N802
        if (
            self._drag_row is not None
            and event.button() == Qt.MouseButton.LeftButton
        ):
            if self._drag_active and self._drop_row is not None:
                self._move_row(self._drag_row, self._drop_row)
            self._reset_drag()
            event.accept()
            return
        super().mouseReleaseEvent(event)

    def leaveEvent(self, event) -> None:  # noqa: N802
        if self._drag_row is None and self.hover_row != -1:
            self.hover_row = -1
            self.viewport().update()
        super().leaveEvent(event)

    def paintEvent(self, event) -> None:  # noqa: N802
        super().paintEvent(event)
        if (
            not self._drag_active
            or self._drag_row is None
            or self._drop_row is None
            or self.rowCount() == 0
        ):
            return
        target = self._drop_target()
        if target == self._drag_row:
            return
        if target >= self.rowCount():
            y = self.rowViewportPosition(
                self.rowCount() - 1
            ) + self.rowHeight(self.rowCount() - 1)
        else:
            y = self.rowViewportPosition(target)
        y = max(0, min(y, self.viewport().height() - 1))
        painter = QPainter(self.viewport())
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        pen = QPen(QColor(ACCENT), 2)
        pen.setCapStyle(Qt.PenCapStyle.RoundCap)
        painter.setPen(pen)
        painter.drawLine(
            QPointF(8.0, float(y)),
            QPointF(float(self.viewport().width() - 8), float(y)),
        )

    def _grip_row_at(self, position: QPoint) -> int:
        index = self.indexAt(position)
        if not index.isValid() or index.column() != self.GRIP_COLUMN:
            return -1
        return index.row()

    def _target_row_at(self, y: int) -> int:
        if self.rowCount() == 0:
            return 0
        y = max(0, min(y, self.viewport().height() - 1))
        index = self.indexAt(QPoint(self.GRIP_WIDTH // 2, y))
        if not index.isValid():
            return 0 if y <= 0 else self.rowCount()
        rect = self.visualRect(index)
        if y > rect.center().y():
            return index.row() + 1
        return index.row()

    def _drop_target(self) -> int:
        if self._drag_row is None or self._drop_row is None:
            return 0
        target = self._drop_row
        if target > self._drag_row:
            target -= 1
        return max(0, min(target, self.rowCount() - 1))

    def _auto_scroll(self, y: int) -> None:
        margin = 26
        bar = self.verticalScrollBar()
        if y < margin:
            bar.setValue(max(bar.minimum(), bar.value() - 7))
        elif y > self.viewport().height() - margin:
            bar.setValue(min(bar.maximum(), bar.value() + 7))

    def _reset_drag(self) -> None:
        if self._drag_row is None:
            return
        self._drag_row = None
        self._drag_active = False
        self._drop_row = None
        self.viewport().setCursor(Qt.CursorShape.PointingHandCursor)
        self.viewport().update()

    def _move_row(self, source: int, drop: int) -> None:
        if self.rowCount() < 2:
            return
        target = drop - 1 if drop > source else drop
        target = max(0, min(target, self.rowCount() - 1))
        if target == source:
            return
        items = [
            self.takeItem(source, column)
            for column in range(self.columnCount())
        ]
        self.removeRow(source)
        self.insertRow(target)
        for column, item in enumerate(items):
            if item is not None:
                self.setItem(target, column, item)
        self._rebuild_rows()
        self.blockSignals(True)
        self.setCurrentCell(target, 1)
        self.blockSignals(False)
        self.viewport().update()
        self.orderChanged.emit(self.current_paths())

    def _rebuild_rows(self) -> None:
        self._rows.clear()
        for row in range(self.rowCount()):
            item = self.item(row, 1)
            path = (
                item.data(Qt.ItemDataRole.UserRole) if item is not None else None
            )
            if path:
                self._rows[path] = row

    def current_paths(self) -> list[str]:
        paths: list[str] = []
        for row in range(self.rowCount()):
            item = self.item(row, 1)
            path = (
                item.data(Qt.ItemDataRole.UserRole) if item is not None else None
            )
            if path:
                paths.append(path)
        return paths

    def _on_double_clicked(self, row: int, column: int) -> None:
        if row >= 0 and column != self.GRIP_COLUMN:
            self.trackActivated.emit(row)

    def keyPressEvent(self, event) -> None:  # noqa: N802
        if event.key() in (Qt.Key.Key_Return, Qt.Key.Key_Enter):
            row = self.currentRow()
            if row >= 0:
                self.trackActivated.emit(row)
                event.accept()
                return
        super().keyPressEvent(event)


class FolderList(QListWidget):
    """Folder list with a three-line drag handle on each row."""

    orderChanged = Signal(list)

    GRIP_WIDTH = 28
    DRAG_THRESHOLD = 4

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setMouseTracking(True)
        self.viewport().setMouseTracking(True)
        self._hover_grip_row = -1
        self._drag_row: int | None = None
        self._drag_origin_y = 0
        self._drag_active = False
        self._drop_row: int | None = None

    def mousePressEvent(self, event) -> None:  # noqa: N802
        if event.button() == Qt.MouseButton.LeftButton:
            position = event.position().toPoint()
            row = self._grip_row_at(position)
            if row >= 0:
                self._drag_row = row
                self._drag_origin_y = position.y()
                self._drag_active = False
                self._drop_row = row
                self.viewport().setCursor(Qt.CursorShape.ClosedHandCursor)
                event.accept()
                return
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event) -> None:  # noqa: N802
        position = event.position().toPoint()
        if self._drag_row is not None:
            if not (event.buttons() & Qt.MouseButton.LeftButton):
                self._reset_drag()
                return
            if (
                abs(position.y() - self._drag_origin_y)
                >= self.DRAG_THRESHOLD
            ):
                self._drag_active = True
            if self._drag_active:
                self._auto_scroll(position.y())
                self._drop_row = self._target_row_at(position.y())
                self.viewport().update()
                event.accept()
                return

        hover = self._grip_row_at(position)
        if hover != self._hover_grip_row:
            self._hover_grip_row = hover
            self.viewport().update()
        self.viewport().setCursor(
            Qt.CursorShape.OpenHandCursor
            if hover >= 0
            else Qt.CursorShape.ArrowCursor
        )
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event) -> None:  # noqa: N802
        if (
            self._drag_row is not None
            and event.button() == Qt.MouseButton.LeftButton
        ):
            if self._drag_active and self._drop_row is not None:
                self._move_row(self._drag_row, self._drop_row)
            self._reset_drag()
            event.accept()
            return
        super().mouseReleaseEvent(event)

    def leaveEvent(self, event) -> None:  # noqa: N802
        if self._hover_grip_row != -1:
            self._hover_grip_row = -1
            self.viewport().update()
        super().leaveEvent(event)

    def paintEvent(self, event) -> None:  # noqa: N802
        super().paintEvent(event)
        painter = QPainter(self.viewport())
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        for row in range(self.count()):
            item = self.item(row)
            if item is None:
                continue
            rect = self.visualItemRect(item)
            if (
                rect.isEmpty()
                or rect.bottom() < 0
                or rect.top() > self.viewport().height()
            ):
                continue
            if row == self._hover_grip_row or (
                row == self._drag_row and self._drag_active
            ):
                color = GRIP_HOVER_COLOR
            else:
                color = GRIP_COLOR
            pen = QPen(QColor(color), 1.4)
            pen.setCapStyle(Qt.PenCapStyle.RoundCap)
            painter.setPen(pen)
            center_y = float(rect.center().y())
            center_x = float(rect.right() - 13)
            for offset in (-4.0, 0.0, 4.0):
                painter.drawLine(
                    QPointF(center_x - 5.0, center_y + offset),
                    QPointF(center_x + 5.0, center_y + offset),
                )

        if (
            not self._drag_active
            or self._drag_row is None
            or self._drop_row is None
            or self.count() == 0
        ):
            return
        target = self._drop_target()
        if target == self._drag_row:
            return
        if target >= self.count():
            rect = self.visualItemRect(self.item(self.count() - 1))
            y = float(rect.bottom())
        else:
            rect = self.visualItemRect(self.item(target))
            y = float(rect.top())
        y = max(1.0, min(y, float(self.viewport().height() - 2)))
        pen = QPen(QColor(ACCENT), 2)
        pen.setCapStyle(Qt.PenCapStyle.RoundCap)
        painter.setPen(pen)
        painter.drawLine(
            QPointF(8.0, y),
            QPointF(float(self.viewport().width() - 8), y),
        )

    def _grip_row_at(self, position: QPoint) -> int:
        item = self.itemAt(position)
        if item is None:
            return -1
        rect = self.visualItemRect(item)
        if position.x() < rect.right() - self.GRIP_WIDTH:
            return -1
        return self.row(item)

    def _target_row_at(self, y: int) -> int:
        if self.count() == 0:
            return 0
        y = max(0, min(y, self.viewport().height() - 1))
        row = self.indexAt(QPoint(8, y)).row()
        if row < 0:
            return 0 if y <= 0 else self.count()
        item = self.item(row)
        if item is None:
            return row
        rect = self.visualItemRect(item)
        if y > rect.center().y():
            return row + 1
        return row

    def _drop_target(self) -> int:
        if self._drag_row is None or self._drop_row is None:
            return 0
        target = self._drop_row
        if target > self._drag_row:
            target -= 1
        return max(0, min(target, self.count() - 1))

    def _auto_scroll(self, y: int) -> None:
        margin = 26
        bar = self.verticalScrollBar()
        if y < margin:
            bar.setValue(max(bar.minimum(), bar.value() - 7))
        elif y > self.viewport().height() - margin:
            bar.setValue(min(bar.maximum(), bar.value() + 7))

    def _reset_drag(self) -> None:
        if self._drag_row is None:
            return
        self._drag_row = None
        self._drag_active = False
        self._drop_row = None
        self.viewport().setCursor(Qt.CursorShape.ArrowCursor)
        self.viewport().update()

    def _move_row(self, source: int, drop: int) -> None:
        if self.count() < 2:
            return
        target = drop - 1 if drop > source else drop
        target = max(0, min(target, self.count() - 1))
        if target == source:
            return
        item = self.item(source)
        if item is None:
            return
        current = self.currentItem()
        was_current = current is item
        self.blockSignals(True)
        moved = self.takeItem(source)
        self.insertItem(target, moved)
        if was_current:
            self.setCurrentItem(moved)
        elif current is not None:
            self.setCurrentItem(current)
        self.blockSignals(False)
        self.viewport().update()
        folders: list[str] = []
        for row in range(self.count()):
            entry = self.item(row)
            folder = (
                entry.data(Qt.ItemDataRole.UserRole) if entry else None
            )
            if folder:
                folders.append(folder)
        self.orderChanged.emit(folders)


class MainWindow(QMainWindow):
    def __init__(
        self,
        config: Config,
        enable_hotkeys: bool = True,
    ) -> None:
        super().__init__()
        self.config = config
        self._enable_hotkeys = enable_hotkeys
        # Hitmo previews are cached on disk; drop leftovers from a crash.
        prepare_hitmo_cache()
        self._cache = TrackCache()
        self._tracks_by_folder: dict[str, list[Track]] = {}
        self._scanned: set[str] = set()
        self._scan_threads: dict[str, FolderScanThread] = {}
        self._pending_rescans: set[str] = set()
        self._view_tracks: list[Track] = []
        self._view_paths: tuple[str, ...] = ()
        self._folder_names: dict[str, str] = {}
        self._updating_ui = False
        self._closing = False
        self._title_applied = False
        self._centered = False
        self._mini_placed = False
        self._online_mode = False
        self._search_thread: SearchWorker | None = None
        self._download_thread: DownloadWorker | None = None
        self._preview_thread: PreviewWorker | None = None
        self._search_generation = 0
        self._preview_generation = 0
        self._preview_result: SearchResult | None = None
        self._preview_fallback_used = False
        self._hitmo_preview_path: str | None = None
        self._download_result: SearchResult | None = None

        self.setWindowTitle("")
        self.setWindowIcon(app_icon())
        self.setMinimumSize(980, 620)
        self.resize(1200, 760)
        if config.geometry:
            try:
                self.restoreGeometry(
                    QByteArray.fromBase64(config.geometry.encode("ascii"))
                )
            except (ValueError, TypeError):
                pass

        self.playback = PlaybackController(self)
        self.mini = MiniPlayer()
        self._probe = DurationProbe(self)
        self._cache_timer = QTimer(self)
        self._cache_timer.setSingleShot(True)
        self._cache_timer.setInterval(700)
        self._cache_timer.timeout.connect(self._cache.save)
        self._save_timer = QTimer(self)
        self._save_timer.setSingleShot(True)
        self._save_timer.setInterval(450)
        self._save_timer.timeout.connect(self._save_config)

        self._build_ui()
        self._connect_signals()
        self._setup_shortcuts()
        self._restore_modes()
        self._normalize_selection()
        self._populate_folder_list()
        self._show_selection()
        self._update_mode_ui()
        # The player always starts offline; the last online/offline state is
        # deliberately not restored.
        self.config.online_mode = False
        self._set_online_mode(False, persist=False)
        QTimer.singleShot(0, self._startup)

    # ---- UI construction ----------------------------------------------

    def _build_ui(self) -> None:
        root = QWidget(self)
        root.setObjectName("Root")
        self.setCentralWidget(root)
        root_layout = QVBoxLayout(root)
        root_layout.setContentsMargins(0, 0, 0, 0)
        root_layout.setSpacing(0)

        root_layout.addWidget(self._build_header())

        body = QWidget(root)
        body_layout = QHBoxLayout(body)
        body_layout.setContentsMargins(0, 0, 0, 0)
        body_layout.setSpacing(0)
        self.sidebar = self._build_sidebar()
        body_layout.addWidget(self.sidebar)
        body_layout.addWidget(self._build_content(), 1)
        root_layout.addWidget(body, 1)

        self.player_bar = PlayerBar(root)
        root_layout.addWidget(self.player_bar)

    def _build_header(self) -> QWidget:
        header = QWidget(self)
        header.setObjectName("Header")
        header.setFixedHeight(64)
        layout = QHBoxLayout(header)
        layout.setContentsMargins(20, 0, 14, 0)
        layout.setSpacing(10)

        logo = QLabel(header)
        logo.setPixmap(app_icon().pixmap(QSize(44, 44)))
        logo.setFixedSize(44, 44)
        layout.addWidget(logo, 0, Qt.AlignmentFlag.AlignVCenter)

        brand_box = QVBoxLayout()
        brand_box.setContentsMargins(0, 0, 0, 0)
        brand_box.setSpacing(0)

        brand = QLabel("AURISON", header)
        brand.setObjectName("Brand")
        brand.setStyleSheet("font-size: 24px; font-weight: 800;")
        self.brand_label = brand

        brand_sub = QLabel(tr("MP3-плеер"), header)
        brand_sub.setObjectName("BrandSub")
        brand_sub.setStyleSheet("font-size: 13px;")
        self.brand_sub_label = brand_sub

        brand_box.addWidget(brand)
        brand_box.addWidget(brand_sub)
        layout.addLayout(brand_box)
        layout.addStretch(1)

        self.mode_label = QLabel("", header)
        self.mode_label.setObjectName("ModeLabel")
        layout.addWidget(self.mode_label)

        self.mode_toggle = ToggleSwitch(header)
        self.mode_toggle.setToolTip(tr("Переключить онлайн-режим"))
        layout.addWidget(self.mode_toggle)
        layout.addSpacing(6)

        self.settings_btn = make_icon_button(
            header,
            "settings",
            "#aab0bb",
            18,
            36,
            tr("Настройки (Ctrl+,)"),
            "IconButton",
        )
        layout.addWidget(self.settings_btn)
        return header

    def _build_sidebar(self) -> QWidget:
        sidebar = QWidget(self)
        sidebar.setObjectName("Sidebar")
        sidebar.setFixedWidth(262)
        layout = QVBoxLayout(sidebar)
        layout.setContentsMargins(16, 18, 16, 14)
        layout.setSpacing(8)

        section = QLabel(tr("БИБЛИОТЕКА"), sidebar)
        section.setObjectName("Section")
        self.library_section = section
        layout.addWidget(section)

        browse_group = QFrame(sidebar)
        browse_group.setObjectName("BrowseGroup")
        browse_group.setFixedHeight(38)
        browse_layout = QHBoxLayout(browse_group)
        browse_layout.setContentsMargins(0, 0, 0, 0)
        browse_layout.setSpacing(0)

        self.browse_btn = QPushButton(tr("Обзор"), browse_group)
        self.browse_btn.setObjectName("BrowseMain")
        self.browse_btn.setIcon(icon("plus", "#d4d9e2", 16))
        self.browse_btn.setIconSize(QSize(16, 16))
        self.browse_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.browse_btn.setToolTip(tr("Выбрать папку с музыкой"))

        self.refresh_btn = QPushButton(browse_group)
        self.refresh_btn.setObjectName("BrowseRefresh")
        self.refresh_btn.setIcon(icon("refresh", "#99a0ab", 16))
        self.refresh_btn.setIconSize(QSize(16, 16))
        self.refresh_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.refresh_btn.setFixedWidth(40)
        self.refresh_btn.setToolTip(tr("Обновить все папки и треки"))

        browse_layout.addWidget(self.browse_btn, 1)
        browse_layout.addWidget(self.refresh_btn)
        layout.addWidget(browse_group)

        layout.addSpacing(2)

        self.all_btn = QPushButton(tr("Все треки"), sidebar)
        self.all_btn.setObjectName("AllTracks")
        self.all_btn.setCheckable(True)
        self.all_btn.setIcon(icon("library", "#aab0bb", 16))
        self.all_btn.setIconSize(QSize(16, 16))
        self.all_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.all_btn.setFixedHeight(36)
        layout.addWidget(self.all_btn)

        layout.addSpacing(6)
        folders_label = QLabel(tr("ПАПКИ"), sidebar)
        folders_label.setObjectName("Section")
        self.folders_section = folders_label
        layout.addWidget(folders_label)

        self.folder_list = FolderList(sidebar)
        self.folder_list.setObjectName("FolderList")
        self.folder_list.setIconSize(QSize(18, 18))
        self.folder_list.setSpacing(1)
        self.folder_list.setUniformItemSizes(True)
        self.folder_list.setSelectionMode(
            QAbstractItemView.SelectionMode.SingleSelection
        )
        self.folder_list.setTextElideMode(Qt.TextElideMode.ElideRight)
        self.folder_list.setContextMenuPolicy(
            Qt.ContextMenuPolicy.CustomContextMenu
        )
        layout.addWidget(self.folder_list, 1)
        return sidebar

    def _build_content(self) -> QWidget:
        content = QWidget(self)
        content.setObjectName("Content")
        layout = QVBoxLayout(content)
        layout.setContentsMargins(28, 24, 28, 10)
        layout.setSpacing(0)

        head = QHBoxLayout()
        head.setContentsMargins(0, 0, 0, 0)
        head.setSpacing(12)
        titles = QVBoxLayout()
        titles.setContentsMargins(0, 0, 0, 0)
        titles.setSpacing(2)
        self.content_title = ElidedLabel(tr("Все треки"), content)
        self.content_title.setObjectName("ContentTitle")
        self.content_meta = QLabel("", content)
        self.content_meta.setObjectName("ContentMeta")
        titles.addWidget(self.content_title)
        titles.addWidget(self.content_meta)
        head.addLayout(titles, 1)

        self.search_input = QLineEdit(content)
        self.search_input.setObjectName("ListSearch")
        self.search_input.setPlaceholderText(tr("Поиск..."))
        self.search_input.setFixedWidth(200)
        self.search_input.returnPressed.connect(self._search_in_list)
        head.addWidget(self.search_input)

        self.search_button = QPushButton(tr("Найти"), content)
        self.search_button.clicked.connect(self._search_in_list)
        head.addWidget(self.search_button)
        layout.addLayout(head)

        layout.addSpacing(14)
        divider = QFrame(content)
        divider.setObjectName("Divider")
        divider.setFixedHeight(1)
        layout.addWidget(divider)
        layout.addSpacing(4)

        self.stack = QStackedWidget(content)
        self.table = TrackTable(self.stack)
        self.placeholder = Placeholder(self.stack)
        self.online_view = OnlineView(self.stack)
        self.stack.addWidget(self.table)
        self.stack.addWidget(self.placeholder)
        self.stack.addWidget(self.online_view)
        layout.addWidget(self.stack, 1)
        return content

    # ---- signal wiring -------------------------------------------------

    def _connect_signals(self) -> None:
        self.browse_btn.clicked.connect(self._browse_folder)
        self.all_btn.clicked.connect(self._on_all_clicked)
        self.folder_list.currentItemChanged.connect(self._on_folder_changed)
        self.folder_list.itemClicked.connect(self._on_folder_clicked)
        self.folder_list.customContextMenuRequested.connect(
            self._show_folder_menu
        )
        self.folder_list.orderChanged.connect(self._on_folders_reordered)
        self.refresh_btn.clicked.connect(self._refresh_all)
        self.table.trackActivated.connect(self._play_row)
        self.table.orderChanged.connect(self._on_track_order_changed)
        self.table.customContextMenuRequested.connect(self._show_track_menu)
        self.settings_btn.clicked.connect(self._open_settings)
        self.mode_toggle.toggled.connect(self._set_online_mode)
        self.online_view.searchRequested.connect(self._start_online_search)
        self.online_view.downloadRequested.connect(
            self._start_online_download
        )
        self.online_view.previewRequested.connect(
            self._start_online_preview
        )
        self.online_view.previewStopRequested.connect(
            self._stop_online_preview
        )
        self.online_view.folderChanged.connect(
            self._on_online_folder_changed
        )
        self.online_view.scopeChanged.connect(self._on_online_scope_changed)
        self.online_view.sourcesChanged.connect(
            self._on_online_sources_changed
        )

        self.player_bar.playPauseClicked.connect(self._on_play_pause)
        self.player_bar.nextClicked.connect(self._on_next)
        self.player_bar.previousClicked.connect(self._on_previous)
        self.player_bar.shuffleToggled.connect(self._on_shuffle_toggled)
        self.player_bar.repeatToggled.connect(self._on_repeat_toggled)
        self.player_bar.muteClicked.connect(self._on_mute_clicked)
        self.player_bar.volumeChanged.connect(self._on_volume_changed)
        self.player_bar.seekRequested.connect(self.playback.seek)

        self.playback.trackChanged.connect(self._on_track_changed)
        self.playback.playbackStateChanged.connect(self._on_playback_state)
        self.playback.positionChanged.connect(self._on_position)
        self.playback.durationChanged.connect(self._on_duration)
        self.playback.shuffleChanged.connect(self._on_shuffle_changed)
        self.playback.repeatChanged.connect(self._on_repeat_changed)
        self.playback.previewFinished.connect(self._on_preview_finished)
        self.playback.errorOccurred.connect(self._on_playback_error)

        self.mini.playPauseClicked.connect(self._on_play_pause)
        self.mini.nextClicked.connect(self._on_next)
        self.mini.previousClicked.connect(self._on_previous)
        self.mini.expandClicked.connect(self._restore_from_mini)
        self.mini.quitRequested.connect(self._quit_app)
        self.mini.seekRequested.connect(self.playback.seek)
        self.mini.volumeChanged.connect(self._on_volume_changed)
        self.mini.muteClicked.connect(self._on_mute_clicked)

        self._probe.resolved.connect(self._on_duration_resolved)

    def _setup_shortcuts(self) -> None:
        QShortcut(QKeySequence("Space"), self, activated=self._on_play_pause)
        QShortcut(QKeySequence("Ctrl+O"), self, activated=self._browse_folder)
        QShortcut(QKeySequence("Ctrl+,"), self, activated=self._open_settings)

    def _restore_modes(self) -> None:
        self.playback.set_volume(self.config.volume)
        self.player_bar.set_volume(self.config.volume, False)
        self.mini.set_volume(self.config.volume, False)
        self.playback.set_shuffle(self.config.shuffle)
        self.playback.set_repeat_one(self.config.repeat_one)
        self.player_bar.set_shuffle_state(self.config.shuffle)
        self.player_bar.set_repeat_state(self.config.repeat_one)

    # ---- startup / selection ------------------------------------------

    def _normalize_selection(self) -> None:
        if self.config.selected_folder == ALL_TRACKS:
            return
        if self.config.selected_folder not in self.config.folders:
            self.config.selected_folder = (
                self.config.folders[0] if self.config.folders else ALL_TRACKS
            )

    def _compute_folder_names(self) -> None:
        grouped: dict[str, list[str]] = {}
        for folder in self.config.folders:
            base = Path(folder).name or folder
            grouped.setdefault(base.casefold(), []).append(folder)
        names: dict[str, str] = {}
        for folder in self.config.folders:
            base = Path(folder).name or folder
            if len(grouped[base.casefold()]) > 1:
                parent = Path(folder).parent.name
                names[folder] = f"{parent} / {base}" if parent else base
            else:
                names[folder] = base
        self._folder_names = names

    def _populate_folder_list(self) -> None:
        self._compute_folder_names()
        self._updating_ui = True
        try:
            self.folder_list.clear()
            selected_item = None
            for folder in self.config.folders:
                item = QListWidgetItem(
                    icon("folder", "#7f8591", 18),
                    self._folder_names.get(folder, Path(folder).name),
                )
                item.setData(Qt.ItemDataRole.UserRole, folder)
                item.setToolTip(folder)
                item.setSizeHint(QSize(0, 38))
                self.folder_list.addItem(item)
                if folder == self.config.selected_folder:
                    selected_item = item
            if selected_item is not None:
                self.folder_list.setCurrentItem(selected_item)
        finally:
            self._updating_ui = False
        self.all_btn.setChecked(self.config.selected_folder == ALL_TRACKS)
        self._update_refresh_state()
        self._sync_online_folders()

    def _show_selection(self) -> None:
        if self.config.selected_folder == ALL_TRACKS:
            self._show_all()
        else:
            self._show_folder(self.config.selected_folder)

    def _show_all(self) -> None:
        for folder in list(self.config.folders):
            if folder not in self._scanned:
                self._start_scan(folder)
        self._refresh_view()

    def _show_folder(self, folder: str) -> None:
        if folder not in self._scanned:
            self._start_scan(folder)
        self._refresh_view()

    def _select_folder(self, folder: str) -> None:
        self.config.selected_folder = folder
        self._updating_ui = True
        try:
            self.all_btn.setChecked(False)
            for index in range(self.folder_list.count()):
                item = self.folder_list.item(index)
                if item.data(Qt.ItemDataRole.UserRole) == folder:
                    self.folder_list.setCurrentItem(item)
                    break
        finally:
            self._updating_ui = False
        self._show_selection()
        self._schedule_save()

    def _on_all_clicked(self, _checked: bool = False) -> None:
        self.all_btn.setChecked(True)
        self._updating_ui = True
        try:
            self.folder_list.clearSelection()
        finally:
            self._updating_ui = False
        self.config.selected_folder = ALL_TRACKS
        self._show_all()
        self._schedule_save()

    def _on_folder_changed(
        self, current: QListWidgetItem | None, _previous: QListWidgetItem | None
    ) -> None:
        if self._updating_ui or current is None:
            return
        folder = current.data(Qt.ItemDataRole.UserRole)
        if not folder or folder == self.config.selected_folder:
            return
        self.config.selected_folder = folder
        self.all_btn.setChecked(False)
        self._show_folder(folder)
        self._schedule_save()

    def _on_folder_clicked(self, item: QListWidgetItem | None) -> None:
        """Handle clicking the folder that is already the current row.

        ``currentItemChanged`` never fires in that case (for example right
        after "All tracks" cleared the selection), so the view would keep
        showing every track instead of the clicked folder.
        """
        if self._updating_ui or item is None:
            return
        folder = item.data(Qt.ItemDataRole.UserRole)
        if not folder or folder == self.config.selected_folder:
            return
        self.config.selected_folder = folder
        self.all_btn.setChecked(False)
        self._show_folder(folder)
        self._schedule_save()

    # ---- folder actions ------------------------------------------------

    def _browse_folder(self) -> None:
        start = Path.home() / "Music"
        if not start.is_dir():
            start = Path.home()
        folder = QFileDialog.getExistingDirectory(
            self, tr("Выберите папку с музыкой"), str(start)
        )
        if folder:
            self.add_folder(folder)

    def add_folder(self, folder: str) -> bool:
        folder = str(Path(folder))
        norm = os.path.normcase(os.path.abspath(folder))
        for existing in self.config.folders:
            if os.path.normcase(os.path.abspath(existing)) == norm:
                self._select_folder(existing)
                return False
        if not os.path.isdir(folder):
            QMessageBox.warning(
                self,
                tr("Папка не найдена"),
                tr("Выбранная папка не существует или недоступна."),
            )
            return False
        self.config.folders.append(folder)
        self._tracks_by_folder.pop(folder, None)
        self._scanned.discard(folder)
        self._populate_folder_list()
        self._select_folder(folder)
        self._schedule_save()
        return True

    def _remove_folder(self, folder: str) -> None:
        if folder not in self.config.folders:
            return
        self.config.folders.remove(folder)
        self._tracks_by_folder.pop(folder, None)
        self._scanned.discard(folder)
        if self.config.selected_folder == folder:
            self.config.selected_folder = ALL_TRACKS
        self._populate_folder_list()
        self._show_selection()
        self._schedule_save()

    def _show_folder_menu(self, position: QPoint) -> None:
        item = self.folder_list.itemAt(position)
        if item is None:
            return
        folder = item.data(Qt.ItemDataRole.UserRole)
        if not folder:
            return
        menu = QMenu(self)
        open_action = menu.addAction(tr("Открыть в Проводнике"))
        refresh_action = menu.addAction(tr("Обновить папку"))
        menu.addSeparator()
        remove_action = menu.addAction(tr("Удалить из библиотеки"))
        chosen = menu.exec(self.folder_list.mapToGlobal(position))
        if chosen == open_action:
            QDesktopServices.openUrl(QUrl.fromLocalFile(folder))
        elif chosen == refresh_action:
            self._scanned.discard(folder)
            self._start_scan(folder)
            if self.config.selected_folder in (folder, ALL_TRACKS):
                self._refresh_view()
        elif chosen == remove_action:
            self._remove_folder(folder)

    def _refresh_all(self) -> None:
        self._probe.clear_failures()
        for folder in list(self.config.folders):
            self._scanned.discard(folder)
            self._start_scan(folder)
        self._refresh_view()

    def _on_folders_reordered(self, folders: list[str]) -> None:
        order = [folder for folder in folders if folder in self.config.folders]
        if len(order) != len(self.config.folders):
            return
        if order == self.config.folders:
            return
        self.config.folders = order
        self._schedule_save()

    # ---- online mode ---------------------------------------------------

    def _sync_online_folders(self) -> None:
        folders = list(self.config.folders)
        selected = self.config.download_folder
        if not folders:
            selected = ""
        else:
            match = ""
            if selected:
                wanted = os.path.normcase(os.path.abspath(selected))
                match = next(
                    (
                        folder
                        for folder in folders
                        if os.path.normcase(os.path.abspath(folder)) == wanted
                    ),
                    "",
                )
            if not match:
                preferred = self.config.selected_folder
                if preferred and preferred != ALL_TRACKS:
                    wanted = os.path.normcase(os.path.abspath(preferred))
                    match = next(
                        (
                            folder
                            for folder in folders
                            if os.path.normcase(os.path.abspath(folder))
                            == wanted
                        ),
                        "",
                    )
            selected = match or folders[0]
        self.config.download_folder = selected
        current = self.online_view.set_folders(
            folders, self._folder_names, selected
        )
        if current != self.config.download_folder:
            self.config.download_folder = current
        self.online_view.set_scope(self.config.online_scope)
        self.online_view.set_sources(self.config.online_sources)
        if folders:
            self.online_view.clear_folder_hint()

    def _update_mode_ui(self) -> None:
        online = self._online_mode
        self.sidebar.setVisible(not online)
        self.mode_label.setText(tr("Онлайн") if online else tr("Оффлайн"))
        tooltip = (
            tr("Выключить онлайн-режим")
            if online
            else tr("Включить онлайн-режим")
        )
        self.mode_label.setToolTip(tooltip)
        self.mode_label.setProperty("online", online)
        repolish(self.mode_label)
        self.mode_toggle.setToolTip(tooltip)

    def _show_online_header(self) -> None:
        self.content_title.setText(tr("Онлайн-поиск"))
        self.content_meta.setText(
            tr("Поиск треков и альбомов в интернете")
        )

    def _set_online_mode(self, enabled: bool, persist: bool = True) -> None:
        enabled = bool(enabled)
        if enabled == self._online_mode:
            self.mode_toggle.set_checked_silently(enabled)
            self._update_mode_ui()
            return
        self._online_mode = enabled
        self.config.online_mode = enabled
        self.mode_toggle.set_checked_silently(enabled)
        self._update_mode_ui()
        if enabled:
            self._sync_online_folders()
            self.stack.setCurrentWidget(self.online_view)
            self._show_online_header()
            if not self.config.folders:
                self.online_view.set_status(
                    "Добавьте папку в библиотеку, чтобы выбрать "
                    "место скачивания."
                )
            QTimer.singleShot(0, self.online_view.focus_search)
        else:
            self._stop_online_preview()
            self._show_selection()
        if persist:
            self._schedule_save()

    def _on_online_folder_changed(self, folder: str) -> None:
        if not folder or folder == self.config.download_folder:
            return
        if folder not in self.config.folders:
            return
        self.config.download_folder = folder
        self._schedule_save()

    def _on_online_scope_changed(self, scope: str) -> None:
        if scope not in ("tracks", "albums"):
            return
        if scope == self.config.online_scope:
            return
        self.config.online_scope = scope
        self._schedule_save()

    def _on_online_sources_changed(self, sources: object) -> None:
        known = set(PROVIDER_KEYS)
        selected = {
            str(source) for source in (sources or []) if str(source) in known
        }
        stored = (
            None
            if selected == known
            else [key for key in PROVIDER_KEYS if key in selected]
        )
        if stored == self.config.online_sources:
            return
        self.config.online_sources = stored
        self._schedule_save()

    def _start_online_search(self, query: str, scope: str) -> None:
        if not self._online_mode or self._closing:
            return
        if self._search_thread is not None and self._search_thread.isRunning():
            return
        sources = self.online_view.active_sources()
        if not sources:
            self.online_view.set_status(
                tr("Выберите хотя бы один источник"), error=True
            )
            return
        self._stop_online_preview()
        self._search_generation += 1
        generation = self._search_generation
        self.online_view.set_searching(True, query)
        self.online_view.set_status("")
        self.content_meta.setText(
            tr("Поиск треков и альбомов в интернете")
        )
        worker = SearchWorker(
            generation, query, scope, self, sources=sources
        )
        worker.finishedSearchDetailed.connect(self._on_search_report)
        worker.finished.connect(
            lambda worker=worker: self._cleanup_search(worker)
        )
        self._search_thread = worker
        worker.start()

    def _on_search_report(self, generation: int, report: object) -> None:
        if self._closing or generation != self._search_generation:
            return
        providers = getattr(report, "providers", {}) or {}
        results = list(getattr(report, "results", []) or [])
        errors = list(getattr(report, "errors", []) or [])
        any_success = bool(getattr(report, "any_success", False))
        self.online_view.set_provider_reports(providers)
        if results:
            self.online_view.set_results(results)
            if errors:
                self.online_view.show_source_warnings(errors)
            return
        if errors and not any_success:
            self.online_view.show_error("Ошибка поиска", "; ".join(errors))
            return
        self.online_view.show_selected_empty()
        if errors:
            self.online_view.show_source_warnings(errors)

    def _on_search_finished(
        self, generation: int, results: list, errors: list
    ) -> None:
        if self._closing or generation != self._search_generation:
            return
        if results:
            self.online_view.set_results(list(results))
            if errors:
                self.online_view.show_source_warnings(errors)
            return
        if errors:
            self.online_view.show_error("Ошибка поиска", "; ".join(errors))
        else:
            self.online_view.show_selected_empty()

    def _cleanup_search(self, worker: SearchWorker) -> None:
        if self._search_thread is worker:
            self._search_thread = None
        worker.deleteLater()

    def _start_online_preview(self, result: SearchResult) -> None:
        if self._closing or not self._online_mode:
            return
        if (
            self._preview_thread is not None
            and self._preview_thread.isRunning()
        ):
            return
        self._stop_online_preview()
        self._preview_generation += 1
        generation = self._preview_generation
        self._preview_result = result
        self._preview_fallback_used = False
        self.online_view.set_previewing(result, loading=True)
        worker = PreviewWorker(generation, result, self)
        worker.previewReady.connect(self._on_preview_ready)
        worker.previewFailed.connect(self._on_preview_failed)
        worker.finished.connect(
            lambda worker=worker: self._cleanup_preview(worker)
        )
        self._preview_thread = worker
        worker.start()

    def _on_preview_ready(
        self,
        generation: int,
        stream_url: str,
        title: str,
        duration_ms: int,
    ) -> None:
        if (
            self._closing
            or generation != self._preview_generation
            or not self._online_mode
        ):
            return
        if not stream_url:
            self._on_preview_failed(
                generation,
                tr("Источник не вернул аудио для прослушивания"),
            )
            return
        result = self._preview_result
        self._discard_hitmo_preview()
        url = stream_url
        if result is not None and result.source == "hitmo":
            # Cached Hitmo preview: play the local file, not an HTTP URL.
            self._hitmo_preview_path = stream_url
            url = QUrl.fromLocalFile(stream_url).toString()
        self.playback.play_preview(url, title, duration_ms)
        self.online_view.set_previewing(self._preview_result)

    def _start_preview_fallback(self, result: SearchResult) -> None:
        if self._closing or not self._online_mode:
            return
        self.online_view.set_previewing(result, loading=True)
        worker = PreviewWorker(
            self._preview_generation, result, self, fallback=True
        )
        worker.previewReady.connect(self._on_preview_ready)
        worker.previewFailed.connect(self._on_preview_failed)
        worker.finished.connect(
            lambda worker=worker: self._cleanup_preview(worker)
        )
        self._preview_thread = worker
        worker.start()

    def _on_preview_failed(self, generation: int, message: str) -> None:
        if self._closing or generation != self._preview_generation:
            return
        self._preview_result = None
        self._preview_fallback_used = False
        self.online_view.set_previewing(None)
        self.online_view.show_preview_error(message)

    def _stop_online_preview(self) -> None:
        self._preview_generation += 1
        worker = self._preview_thread
        if worker is not None and worker.isRunning():
            worker.cancel()
        self._preview_result = None
        self._preview_fallback_used = False
        self.online_view.set_previewing(None)
        if self.playback.is_previewing():
            self.playback.stop_preview()
        self._discard_hitmo_preview()

    def _on_preview_finished(self) -> None:
        self._preview_result = None
        self._preview_fallback_used = False
        self.online_view.set_previewing(None)
        self._discard_hitmo_preview()

    def _discard_hitmo_preview(self) -> None:
        """Delete the cached Hitmo preview file that is no longer in use."""
        path = self._hitmo_preview_path
        self._hitmo_preview_path = None
        if not path:
            return
        try:
            Path(path).unlink(missing_ok=True)
        except OSError:
            pass

    def _cleanup_preview(self, worker: PreviewWorker) -> None:
        if self._preview_thread is worker:
            self._preview_thread = None
        worker.deleteLater()

    def _on_playback_error(self, message: str) -> None:
        if self.playback.is_previewing():
            result = self._preview_result
            self.playback.stop_preview()
            if result is not None and not self._preview_fallback_used:
                # The stream URL was resolved, but the player rejected it
                # (expired signed URL, 403/503 host, unsupported codec).
                self._preview_fallback_used = True
                self._start_preview_fallback(result)
                return
            self._preview_result = None
            self._preview_fallback_used = False
            self.online_view.set_previewing(None)
            self.online_view.show_preview_error(message)
            return
        self.player_bar.flash_error(message)

    def _start_online_download(
        self, result: SearchResult, folder: str
    ) -> None:
        if self._closing:
            return
        if not folder or folder not in self.config.folders:
            self.online_view.show_download_error(
                tr(
                    "Добавьте папку в библиотеку, чтобы выбрать "
                    "место скачивания."
                )
            )
            return
        if (
            self._download_thread is not None
            and self._download_thread.isRunning()
        ):
            return
        self.config.download_folder = folder
        self.online_view.set_downloading(True)
        worker = DownloadWorker(result, folder, self)
        worker.progressChanged.connect(self._on_download_progress)
        worker.finishedDownload.connect(self._on_download_finished)
        worker.finished.connect(
            lambda worker=worker: self._cleanup_download(worker)
        )
        self._download_thread = worker
        worker.start()

    def _on_download_progress(self, percent: int, detail: str) -> None:
        if self._closing or not self._online_mode:
            return
        self.online_view.set_download_progress(percent, detail)

    def _on_download_finished(
        self, success: bool, folder: str, error: str, count: int
    ) -> None:
        if self._closing:
            return
        self.online_view.set_downloading(False)
        label = self._folder_names.get(folder) or Path(folder).name or folder
        if success:
            self.online_view.show_downloaded(label, count)
            if folder in self.config.folders:
                if folder in self._scan_threads:
                    self._pending_rescans.add(folder)
                else:
                    self._scanned.discard(folder)
                    self._start_scan(folder)
            self._schedule_save()
        else:
            self.online_view.show_download_error(error)

    def _cleanup_download(self, worker: DownloadWorker) -> None:
        if self._download_thread is worker:
            self._download_thread = None
        worker.deleteLater()

    def _show_track_menu(self, position: QPoint) -> None:
        index = self.table.indexAt(position)
        if not index.isValid():
            return
        self.table.setCurrentCell(index.row(), 1)
        path = self.table.current_track_path()
        if not path:
            return
        menu = QMenu(self)
        play_action = menu.addAction(tr("Воспроизвести"))
        menu.addSeparator()
        rename_action = menu.addAction(tr("Переименовать"))
        delete_action = menu.addAction(tr("Удалить"))
        menu.addSeparator()
        open_action = menu.addAction(tr("Открыть папку с файлом"))
        chosen = menu.exec(self.table.viewport().mapToGlobal(position))
        if chosen == play_action:
            self._play_row(index.row())
        elif chosen == rename_action:
            self._rename_track(path)
        elif chosen == delete_action:
            self._delete_track(path)
        elif chosen == open_action:
            QDesktopServices.openUrl(
                QUrl.fromLocalFile(str(Path(path).parent))
            )

    def _rename_track(self, path: str) -> None:
        """Rename a track file on disk, keeping its extension."""
        source = Path(path)
        name, accepted = QInputDialog.getText(
            self,
            tr("Переименовать трек"),
            tr("Новое название файла:"),
            text=source.stem,
        )
        if not accepted:
            return
        name = name.strip()
        if not name:
            return
        name = safe_folder_name(name)
        if not name or name == source.stem:
            return
        target = source.with_name(f"{name}{source.suffix}")
        if target.exists():
            QMessageBox.warning(
                self,
                tr("Переименовать"),
                tr("Файл с таким названием уже существует."),
            )
            return
        try:
            source.rename(target)
        except OSError as error:
            QMessageBox.warning(self, tr("Переименовать"), str(error))
            return
        self._replace_track_path(source, target)

    def _replace_track_path(self, source: Path, target: Path) -> None:
        old = os.path.normcase(str(source))
        for tracks in self._tracks_by_folder.values():
            for track in tracks:
                if os.path.normcase(track.path) == old:
                    track.path = str(target)
                    track.title = target.stem
        self._move_cached_entry(str(source), str(target), target.stem)
        self._refresh_view()

    def _move_cached_entry(
        self, old: str, new: str, title: str
    ) -> None:
        entry = self._cache.entries.pop(old, None)
        if entry is None:
            return
        try:
            stat = os.stat(new)
        except OSError:
            return
        updated = dict(entry)
        updated.update(
            {"mtime": stat.st_mtime, "size": stat.st_size, "title": title}
        )
        self._cache.entries[new] = updated
        self._cache_timer.start()

    def _delete_track(self, path: str) -> None:
        """Delete a track file from disk after confirmation."""
        answer = QMessageBox.question(
            self,
            tr("Удалить трек"),
            tr("Вы точно хотите удалить этот трек?"),
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        if answer != QMessageBox.StandardButton.Yes:
            return
        current = self.playback.current_track
        if (
            current is not None
            and os.path.normcase(current.path) == os.path.normcase(path)
        ):
            self.playback.stop()
        try:
            Path(path).unlink()
        except OSError as error:
            QMessageBox.warning(self, tr("Удалить трек"), str(error))
            return
        self._cache.entries.pop(path, None)
        self._cache_timer.start()
        key = os.path.normcase(path)
        for tracks in self._tracks_by_folder.values():
            tracks[:] = [
                track
                for track in tracks
                if os.path.normcase(track.path) != key
            ]
        self._refresh_view()

    # ---- scanning ------------------------------------------------------

    def _start_scan(self, folder: str) -> None:
        if folder in self._scan_threads:
            return
        if not os.path.isdir(folder):
            self._tracks_by_folder[folder] = []
            self._scanned.add(folder)
            return
        self._scanned.discard(folder)
        thread = FolderScanThread(folder, self._cache.snapshot(), self)
        thread.done.connect(self._on_scan_done)
        thread.finished.connect(lambda f=folder: self._cleanup_scan(f))
        self._scan_threads[folder] = thread
        thread.start()

    def _cleanup_scan(self, folder: str) -> None:
        thread = self._scan_threads.pop(folder, None)
        if thread is not None:
            thread.deleteLater()
        if folder in self._pending_rescans:
            self._pending_rescans.discard(folder)
            if folder in self.config.folders:
                self._scanned.discard(folder)
                self._start_scan(folder)

    def _on_scan_done(
        self, folder: str, tracks: list[Track], updates: dict[str, dict]
    ) -> None:
        if folder not in self.config.folders:
            return
        self._cache.update(updates)
        if updates:
            self._cache_timer.start()
        self._apply_cached_durations(tracks)
        self._tracks_by_folder[folder] = tracks
        self._scanned.add(folder)
        unresolved = [track.path for track in tracks if track.duration_ms <= 0]
        if unresolved:
            self._probe.enqueue(unresolved, force=True)
        self._refresh_view()

    def _apply_cached_durations(self, tracks: list[Track]) -> None:
        for track in tracks:
            if track.duration_ms > 0:
                continue
            entry = self._cache.entries.get(track.path)
            if (
                isinstance(entry, dict)
                and entry.get("duration_verified")
                and int(entry.get("duration") or 0) > 0
            ):
                track.duration_ms = int(entry["duration"])

    # ---- rendering -----------------------------------------------------

    def _refresh_view(self) -> None:
        if self._online_mode:
            return
        if self.config.selected_folder == ALL_TRACKS:
            self._render_all()
        else:
            self._render_folder(self.config.selected_folder)

    def _render_all(self) -> None:
        folders = self.config.folders
        scanning = any(folder not in self._scanned for folder in folders)
        self._update_refresh_state()
        self.content_title.setText(tr("Все треки"))

        tracks: list[Track] = []
        seen: set[str] = set()
        for folder in folders:
            for track in self._tracks_by_folder.get(folder, []):
                key = os.path.normcase(os.path.abspath(track.path))
                if key in seen:
                    continue
                seen.add(key)
                tracks.append(track)
        tracks.sort(
            key=lambda item: (natural_key(item.title), natural_key(item.path))
        )
        tracks = self._sorted_by_saved_order(tracks, ALL_TRACKS)

        self._apply_tracks(tracks)

        if not folders:
            self.content_meta.setText(tr("Папки не добавлены"))
            self.placeholder.set_state(
                tr("Библиотека пуста"),
                tr("Нажмите «Обзор», чтобы добавить папку с музыкой."),
                "note",
            )
            self.stack.setCurrentWidget(self.placeholder)
        elif not tracks and scanning:
            self.content_meta.setText(tr("Сканирование библиотеки…"))
            self.placeholder.set_state(
                tr("Сканирование"),
                tr(
                    "Читаем треки и длительность. "
                    "Это может занять немного времени."
                ),
                "note",
                loading=True,
            )
            self.stack.setCurrentWidget(self.placeholder)
        elif not tracks:
            self.content_meta.setText(tr("0 треков"))
            self.placeholder.set_state(
                tr("Здесь нет треков"),
                tr(
                    "Поддерживаются MP3, FLAC, WAV, OGG, M4A "
                    "и другие форматы."
                ),
                "note",
            )
            self.stack.setCurrentWidget(self.placeholder)
        else:
            meta = track_count(len(tracks))
            if scanning:
                meta += tr(" · сканирование…")
            self.content_meta.setText(meta)
            self.stack.setCurrentWidget(self.table)

    def _render_folder(self, folder: str) -> None:
        title = self._folder_names.get(folder, Path(folder).name or folder)
        self.content_title.setText(title)
        missing = not os.path.isdir(folder)
        self._update_refresh_state()
        tracks = list(self._tracks_by_folder.get(folder, []))
        tracks = self._sorted_by_saved_order(tracks, folder)
        scanning = folder not in self._scanned

        self._apply_tracks(tracks)

        if missing:
            self.content_meta.setText(tr("Папка не найдена"))
            self.placeholder.set_state(
                tr("Папка недоступна"),
                tr(
                    "Возможно, она была перемещена или удалена. "
                    "Удалите её из библиотеки через правый клик."
                ),
                "folder",
            )
            self.stack.setCurrentWidget(self.placeholder)
        elif not tracks and scanning:
            self.content_meta.setText(tr("Сканирование…"))
            self.placeholder.set_state(
                tr("Сканирование"),
                tr(
                    "Читаем треки и длительность. "
                    "Это может занять немного времени."
                ),
                "note",
                loading=True,
            )
            self.stack.setCurrentWidget(self.placeholder)
        elif not tracks:
            self.content_meta.setText(tr("0 треков"))
            self.placeholder.set_state(
                tr("Здесь нет треков"),
                tr(
                    "Поддерживаются MP3, FLAC, WAV, OGG, M4A "
                    "и другие форматы."
                ),
                "note",
            )
            self.stack.setCurrentWidget(self.placeholder)
        else:
            meta = track_count(len(tracks))
            if scanning:
                meta += tr(" · сканирование…")
            self.content_meta.setText(meta)
            self.stack.setCurrentWidget(self.table)

    def _apply_tracks(self, tracks: list[Track]) -> None:
        selected = self.table.current_track_path()
        paths = tuple(track.path for track in tracks)
        self._view_tracks = tracks
        if paths != self._view_paths:
            self._view_paths = paths
            self.table.set_tracks(tracks)
            if selected:
                self.table.select_path(selected)
        self._update_current_highlight()
        self._update_transport()

    def _search_in_list(self) -> None:
        """Highlight a track by exact substring, then by fuzzy similarity."""
        query = self.search_input.text().strip().casefold()
        if not query:
            return
        for track in self._view_tracks:
            if query in track.title.casefold():
                self.table.highlight_path(track.path)
                return
        best_track = None
        best_score = FUZZY_MATCH_THRESHOLD
        for track in self._view_tracks:
            score = fuzzy_title_score(query, track.title.casefold())
            if score >= best_score:
                best_track = track
                best_score = score
        if best_track is not None:
            self.table.highlight_path(best_track.path)

    def _update_current_highlight(self) -> None:
        track = self.playback.current_track
        self.table.set_current_path(
            track.path if track else None, self.playback.is_playing()
        )

    def _update_transport(self) -> None:
        has_current = self.playback.current_track is not None
        can_play = has_current or bool(self._view_tracks)
        self.player_bar.set_transport_state(can_play, has_current)

    def _update_refresh_state(self) -> None:
        self.refresh_btn.setEnabled(bool(self.config.folders))

    def _sorted_by_saved_order(
        self, tracks: list[Track], key: str
    ) -> list[Track]:
        saved = self.config.track_order.get(key)
        if not saved:
            return tracks
        positions: dict[str, int] = {}
        for index, path in enumerate(saved):
            positions.setdefault(path, index)
        if not any(track.path in positions for track in tracks):
            return tracks
        limit = len(saved)
        return sorted(
            tracks,
            key=lambda track: (
                positions.get(track.path, limit),
                natural_key(track.title),
                natural_key(track.path),
            ),
        )

    def _on_track_order_changed(self, paths: list[str]) -> None:
        if not paths:
            return
        key = (
            ALL_TRACKS
            if self.config.selected_folder == ALL_TRACKS
            else self.config.selected_folder
        )
        self.config.track_order[key] = list(paths)
        positions = {path: index for index, path in enumerate(paths)}
        self._view_tracks.sort(
            key=lambda track: positions.get(track.path, len(paths))
        )
        self._view_paths = tuple(paths)
        self.playback.apply_order(paths)
        self._schedule_save()

    def _on_duration_resolved(self, path: str, duration_ms: int) -> None:
        self._apply_duration(path, duration_ms)

    def _apply_duration(self, path: str, duration_ms: int) -> None:
        duration = int(duration_ms)
        if duration <= 0:
            return
        for tracks in self._tracks_by_folder.values():
            for track in tracks:
                if track.path == path:
                    track.duration_ms = duration
        current = self.playback.current_track
        if current is not None and current.path == path:
            current.duration_ms = duration
            self.mini.set_progress(self.playback.position(), duration)
            self.player_bar.set_duration(duration)
        self.table.update_duration(path, duration)
        self._remember_duration(path, duration)

    def _remember_duration(self, path: str, duration_ms: int) -> None:
        try:
            stat = os.stat(path)
        except OSError:
            return
        entry = self._cache.entries.get(path)
        merged = dict(entry) if isinstance(entry, dict) else {}
        merged["mtime"] = stat.st_mtime
        merged["size"] = stat.st_size
        merged["title"] = merged.get("title") or self._title_for_path(path)
        merged["duration"] = int(duration_ms)
        merged["duration_verified"] = True
        self._cache.entries[path] = merged
        self._cache_timer.start()

    def _title_for_path(self, path: str) -> str:
        for tracks in self._tracks_by_folder.values():
            for track in tracks:
                if track.path == path:
                    return track.title
        return Path(path).stem

    # ---- playback slots ------------------------------------------------

    def _play_row(self, row: int) -> None:
        if 0 <= row < len(self._view_tracks):
            self.playback.play_queue(self._view_tracks, row)

    def _on_play_pause(self) -> None:
        if self.playback.current_track is None:
            if self._view_tracks:
                self.playback.play_queue(self._view_tracks, 0)
            return
        self.playback.toggle_play_pause()

    def _on_next(self) -> None:
        if self.playback.current_track is None:
            if self._view_tracks:
                self.playback.play_queue(self._view_tracks, 0)
            return
        self.playback.next_track(manual=True)

    def _on_previous(self) -> None:
        if self.playback.current_track is None:
            if self._view_tracks:
                self.playback.play_queue(self._view_tracks, 0)
            return
        self.playback.previous_track()

    def _on_track_changed(self, track: Track | None) -> None:
        if (
            track is not None
            and not self.playback.is_previewing()
            and self._preview_result is not None
        ):
            self._stop_online_preview()
        self.player_bar.set_track(track)
        self.mini.set_track(track)
        if track is None:
            self.mini.set_progress(0, 0)
            self._update_current_highlight()
            self._update_transport()
            self.setWindowTitle("")
            return
        self.mini.set_progress(0, track.duration_ms)
        self._update_current_highlight()
        self._update_transport()
        self.table.scroll_to_path(track.path)
        # The playing track is already shown in the player bar and mini
        # player, so the window title stays empty.
        self.setWindowTitle("")

    def _on_playback_state(self, state) -> None:
        playing = state == QMediaPlayer.PlaybackState.PlayingState
        self.player_bar.set_playing(playing)
        self.mini.set_playing(playing)
        self._update_current_highlight()

    def _on_position(self, position_ms: int) -> None:
        self.player_bar.set_position(position_ms)
        duration = self.playback.duration()
        if duration <= 0:
            track = self.playback.current_track
            duration = track.duration_ms if track else 0
        self.mini.set_progress(position_ms, duration)

    def _on_duration(self, duration_ms: int) -> None:
        track = self.playback.current_track
        real_duration = int(duration_ms)
        if real_duration > 0 and track is not None:
            self._apply_duration(track.path, real_duration)
        display = (
            real_duration
            if real_duration > 0
            else (track.duration_ms if track else 0)
        )
        self.player_bar.set_duration(display)
        self.mini.set_progress(self.playback.position(), display)

    def _on_shuffle_toggled(self, enabled: bool) -> None:
        self.playback.set_shuffle(enabled)
        self.config.shuffle = enabled
        self.player_bar.set_shuffle_state(enabled)
        self._schedule_save()

    def _on_repeat_toggled(self, enabled: bool) -> None:
        self.playback.set_repeat_one(enabled)
        self.config.repeat_one = enabled
        self.player_bar.set_repeat_state(enabled)
        self._schedule_save()

    def _on_shuffle_changed(self, enabled: bool) -> None:
        self.player_bar.set_shuffle_state(enabled)

    def _on_repeat_changed(self, enabled: bool) -> None:
        self.player_bar.set_repeat_state(enabled)

    def _on_volume_changed(self, percent: int) -> None:
        percent = max(0, min(100, int(percent)))
        if self.playback.is_muted() and percent > 0:
            self.playback.set_muted(False)
        self.playback.set_volume(percent)
        self.config.volume = percent
        muted = self.playback.is_muted()
        self.player_bar.set_volume(percent, muted)
        self.mini.set_volume(percent, muted)
        self._schedule_save()

    def _on_mute_clicked(self) -> None:
        if self.playback.is_muted():
            self.playback.set_muted(False)
            if self.player_bar.volume.value() == 0:
                self.player_bar.set_volume(70, False)
                self.playback.set_volume(70)
                self.config.volume = 70
                self._schedule_save()
        else:
            self.playback.set_muted(True)

        muted = self.playback.is_muted()
        percent = self.player_bar.volume.value()
        self.player_bar.set_muted(muted)
        self.player_bar.set_volume(percent, muted)
        self.mini.set_muted(muted)
        self.mini.set_volume(percent, muted)

    # ---- settings / hotkeys -------------------------------------------

    def _startup(self) -> None:
        if not self._enable_hotkeys:
            return
        self.hotkeys = GlobalHotkeys(
            QApplication.instance(),
            {
                "play_pause": self._on_play_pause,
                "next": self._on_next,
                "previous": self._on_previous,
            },
        )
        failures = self._register_hotkeys(show_errors=False)
        if failures:
            QTimer.singleShot(
                250, lambda: self._warn_hotkeys(failures)
            )

    def _register_hotkeys(self, show_errors: bool = True) -> list[str]:
        hotkeys = getattr(self, "hotkeys", None)
        if hotkeys is None:
            return []
        if not self.config.hotkeys_enabled:
            hotkeys.unregister_all()
            return []
        failures = hotkeys.register_all(self.config.hotkeys)
        if failures and show_errors:
            self._warn_hotkeys(failures)
        return failures

    def _warn_hotkeys(self, failures: list[str]) -> None:
        labels = hotkey_labels()
        names = ", ".join(labels.get(action, action) for action in failures)
        QMessageBox.warning(
            self,
            tr("Горячие клавиши"),
            tr(
                "Не удалось зарегистрировать глобальные сочетания:\n"
                "{names}\n\n"
                "Возможно, они уже заняты другой программой. "
                "Их можно изменить в настройках."
            ).format(names=names),
        )

    def _open_settings(self) -> None:
        hotkeys = getattr(self, "hotkeys", None)
        if hotkeys is not None:
            hotkeys.unregister_all()
        old_hotkeys = dict(self.config.hotkeys)
        old_enabled = self.config.hotkeys_enabled
        old_language = self.config.language
        old_mini = self.config.mini_player_enabled
        dialog = SettingsDialog(
            old_hotkeys, old_enabled, old_language, old_mini, self
        )
        accepted = dialog.exec() == QDialog.DialogCode.Accepted
        if accepted:
            (
                new_hotkeys,
                new_enabled,
                new_language,
                new_mini,
            ) = dialog.values()
            self.config.hotkeys = new_hotkeys
            self.config.hotkeys_enabled = new_enabled
            self.config.mini_player_enabled = new_mini
            if not new_mini:
                self.mini.hide()
            failures = self._register_hotkeys(show_errors=False)
            if failures:
                self.config.hotkeys = old_hotkeys
                self.config.hotkeys_enabled = old_enabled
                self._register_hotkeys(show_errors=False)
                self._warn_hotkeys(failures)
            else:
                if new_language != self.config.language:
                    self.config.language = new_language
                    set_language(new_language)
                    self._retranslate_ui()
            self._schedule_save()
        else:
            self._register_hotkeys(show_errors=False)

    def _retranslate_ui(self) -> None:
        """Apply the active language to all visible widgets."""
        self.setWindowTitle("")
        self.library_section.setText(tr("БИБЛИОТЕКА"))
        self.folders_section.setText(tr("ПАПКИ"))
        self.browse_btn.setText(tr("Обзор"))
        self.browse_btn.setToolTip(tr("Выбрать папку с музыкой"))
        self.refresh_btn.setToolTip(tr("Обновить все папки и треки"))
        self.all_btn.setText(tr("Все треки"))
        self.search_input.setPlaceholderText(tr("Поиск..."))
        self.search_button.setText(tr("Найти"))
        self.settings_btn.setToolTip(tr("Настройки (Ctrl+,)"))
        self._update_mode_ui()
        self.table.retranslate()
        self.online_view.retranslate()
        self.player_bar.retranslate()
        self.mini.retranslate()
        if self._online_mode:
            self._show_online_header()
        else:
            self._refresh_view()

    # ---- mini player ---------------------------------------------------

    def changeEvent(self, event) -> None:  # noqa: N802
        super().changeEvent(event)
        if event.type() != QEvent.Type.WindowStateChange:
            return
        if self.isMinimized():
            if self.config.mini_player_enabled:
                QTimer.singleShot(0, self._show_mini)
            elif self.mini.isVisible():
                self.mini.hide()
        elif self.mini.isVisible():
            self.mini.hide()

    def _show_mini(self) -> None:
        if not self.config.mini_player_enabled:
            self.mini.hide()
            return
        if not self.isMinimized():
            return
        self.mini.set_track(self.playback.current_track)
        self.mini.set_playing(self.playback.is_playing())
        self.mini.set_volume(
            self.player_bar.volume.value(), self.playback.is_muted()
        )
        duration = self.playback.duration()
        if duration <= 0:
            track = self.playback.current_track
            duration = track.duration_ms if track else 0
        self.mini.set_progress(self.playback.position(), duration)
        if not self._mini_placed:
            self.mini.show_at_saved_position(self.config.mini_position)
            self._mini_placed = True
        self.mini.show()
        self.mini.raise_()

    def _restore_from_mini(self) -> None:
        self.mini.hide()
        self.showNormal()
        self.raise_()
        self.activateWindow()

    def _quit_app(self) -> None:
        self.close()

    # ---- lifecycle / persistence --------------------------------------

    def showEvent(self, event) -> None:  # noqa: N802
        super().showEvent(event)
        if not self._title_applied:
            self._title_applied = True
            try:
                from aurison.platform_win import apply_dark_title_bar

                apply_dark_title_bar(self)
            except Exception:
                pass
        if not self._centered:
            self._centered = True
            if not self.config.geometry:
                screen = self.screen() or QApplication.primaryScreen()
                if screen is not None:
                    frame = self.frameGeometry()
                    frame.moveCenter(screen.availableGeometry().center())
                    self.move(frame.topLeft())

    def _schedule_save(self) -> None:
        self._save_timer.start()

    def _save_config(self) -> None:
        self.config.volume = self.player_bar.volume.value()
        self.config.shuffle = self.playback.shuffle()
        self.config.repeat_one = self.playback.repeat_one()
        if self._mini_placed:
            point = self.mini.pos()
            self.config.mini_position = [point.x(), point.y()]
        try:
            self.config.geometry = (
                self.saveGeometry().toBase64().data().decode("ascii")
            )
        except Exception:
            pass
        self.config.save()

    def closeEvent(self, event) -> None:  # noqa: N802
        if self._closing:
            event.accept()
            return
        self._closing = True
        self._save_config()
        self._cache.save()
        self._stop_online_preview()
        workers = (
            self._search_thread,
            self._download_thread,
            self._preview_thread,
        )
        for worker in workers:
            if worker is not None:
                worker.cancel()
        for worker in workers:
            if worker is not None and worker.isRunning():
                if not worker.wait(2000):
                    worker.terminate()
                    worker.wait(500)
        for thread in list(self._scan_threads.values()):
            thread.requestInterruption()
        for thread in list(self._scan_threads.values()):
            thread.wait(2500)
        hotkeys = getattr(self, "hotkeys", None)
        if hotkeys is not None:
            hotkeys.close()
        self._probe.stop()
        self.playback.stop()
        self.mini.close_for_quit()
        event.accept()
