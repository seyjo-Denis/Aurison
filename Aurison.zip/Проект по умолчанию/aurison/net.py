"""DNS-over-HTTPS fallback for networks that block music sites by DNS.

Some providers block domains such as youtube.com at the DNS level while the
actual hosts remain reachable.  The standard resolver raises ``gaierror`` in
that case.  Installing this fallback keeps the normal resolver as the primary
path and only asks a public DoH endpoint when it fails.
"""

from __future__ import annotations

import json
import socket
import threading
import time
import urllib.parse
import urllib.request

_DOH_ENDPOINTS = (
    "https://dns.google/resolve",
    "https://cloudflare-dns.com/dns-query",
)
_DOH_HOSTS = {"dns.google", "cloudflare-dns.com"}
_POSITIVE_TTL = 300.0
_NEGATIVE_TTL = 60.0
_MAX_CACHE = 256

_ORIGINAL_GETADDRINFO = socket.getaddrinfo
_cache: dict[tuple[str, int], tuple[float, tuple[str, ...]]] = {}
_cache_lock = threading.Lock()
_installed = False


def _is_ip_literal(host: str) -> bool:
    for family in (socket.AF_INET, socket.AF_INET6):
        try:
            socket.inet_pton(family, host)
            return True
        except OSError:
            continue
    return False


def _cached(host: str, query_type: str) -> tuple[str, ...] | None:
    key = (host.casefold(), 1 if query_type == "A" else 2)
    now = time.monotonic()
    with _cache_lock:
        entry = _cache.get(key)
        if entry is None:
            return None
        expires, addresses = entry
        if expires <= now:
            _cache.pop(key, None)
            return None
        return addresses


def _store(host: str, query_type: str, addresses: list[str]) -> None:
    ttl = _POSITIVE_TTL if addresses else _NEGATIVE_TTL
    key = (host.casefold(), 1 if query_type == "A" else 2)
    with _cache_lock:
        if len(_cache) >= _MAX_CACHE:
            _cache.clear()
        _cache[key] = (time.monotonic() + ttl, tuple(addresses))


def _query_doh(host: str, query_type: str) -> list[str]:
    params = urllib.parse.urlencode({"name": host, "type": query_type})
    expected = 1 if query_type == "A" else 28
    for endpoint in _DOH_ENDPOINTS:
        try:
            request = urllib.request.Request(
                f"{endpoint}?{params}",
                headers={
                    "Accept": "application/dns-json",
                    "User-Agent": "Aurison/1.0",
                },
            )
            with urllib.request.urlopen(request, timeout=5) as response:
                payload = json.loads(
                    response.read().decode("utf-8", "replace")
                )
        except Exception:
            continue
        if not isinstance(payload, dict) or payload.get("Status") != 0:
            continue
        addresses: list[str] = []
        for answer in payload.get("Answer") or []:
            if not isinstance(answer, dict) or answer.get("type") != expected:
                continue
            value = answer.get("data")
            if isinstance(value, str) and _is_ip_literal(value):
                addresses.append(value)
        if addresses:
            return addresses
    return []


def resolve(host: str, query_type: str = "A") -> list[str]:
    """Resolve a host through DoH, using a short in-process cache."""
    cached = _cached(host, query_type)
    if cached is not None:
        return list(cached)
    addresses = _query_doh(host, query_type)
    _store(host, query_type, addresses)
    return addresses


def _patched_getaddrinfo(
    host: object,
    port: object,
    family: int = 0,
    type: int = 0,
    proto: int = 0,
    flags: int = 0,
):
    try:
        return _ORIGINAL_GETADDRINFO(host, port, family, type, proto, flags)
    except socket.gaierror:
        if (
            not isinstance(host, str)
            or not host
            or flags & socket.AI_NUMERICHOST
            or _is_ip_literal(host)
            or host.casefold() in _DOH_HOSTS
        ):
            raise
        if family == socket.AF_INET6:
            query_type = "AAAA"
            addresses = resolve(host, "AAAA")
        else:
            query_type = "A"
            addresses = resolve(host, "A")
        if not addresses:
            raise
        socktype = type or socket.SOCK_STREAM
        protocol = proto or (
            socket.IPPROTO_TCP if socktype == socket.SOCK_STREAM else 0
        )
        results = []
        for address in addresses:
            if query_type == "AAAA":
                if family not in (0, socket.AF_INET6):
                    continue
                results.append(
                    (
                        socket.AF_INET6,
                        socktype,
                        protocol,
                        "",
                        (address, port, 0, 0),
                    )
                )
            else:
                if family not in (0, socket.AF_INET):
                    continue
                results.append(
                    (
                        socket.AF_INET,
                        socktype,
                        protocol,
                        "",
                        (address, port),
                    )
                )
        if not results:
            raise
        return results


def install_doh_fallback() -> None:
    """Install the resolver fallback once for the current process."""
    global _installed
    if _installed:
        return
    _installed = True
    socket.getaddrinfo = _patched_getaddrinfo
