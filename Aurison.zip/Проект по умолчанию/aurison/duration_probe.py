from __future__ import annotations

from collections import deque

from PySide6.QtCore import QObject, QTimer, QUrl, Signal
from PySide6.QtMultimedia import QMediaPlayer


class DurationProbe(QObject):
    """Resolve real track durations through Qt Multimedia, one file at a time."""

    resolved = Signal(str, int)
    failed = Signal(str)

    TIMEOUT_MS = 2500

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self._player = QMediaPlayer(self)
        self._queue: deque[str] = deque()
        self._queued: set[str] = set()
        self._known: set[str] = set()
        self._failed: set[str] = set()
        self._current: str | None = None
        self._timer = QTimer(self)
        self._timer.setSingleShot(True)
        self._timer.setInterval(self.TIMEOUT_MS)
        self._timer.timeout.connect(self._on_timeout)

        self._player.durationChanged.connect(self._on_duration)
        self._player.errorOccurred.connect(self._on_error)

    # ---- public API ----------------------------------------------------

    def enqueue(self, paths: list[str], force: bool = False) -> None:
        added = False
        for path in paths:
            if force:
                self._failed.discard(path)
                self._known.discard(path)
            if (
                not path
                or path in self._known
                or path in self._failed
                or path == self._current
                or path in self._queued
            ):
                continue
            self._queue.append(path)
            self._queued.add(path)
            added = True
        if added:
            self._start_next()

    def clear_failures(self) -> None:
        self._failed.clear()

    def stop(self) -> None:
        self._queue.clear()
        self._queued.clear()
        self._timer.stop()
        self._current = None
        self._player.setSource(QUrl())

    # ---- internals -----------------------------------------------------

    def _start_next(self) -> None:
        if self._current is not None or not self._queue:
            return
        path = self._queue.popleft()
        self._queued.discard(path)
        self._current = path
        self._timer.start()
        self._player.setSource(QUrl.fromLocalFile(path))

    def _on_duration(self, duration_ms: int) -> None:
        if self._current is None or duration_ms <= 0:
            return
        path = self._current
        duration = int(duration_ms)
        self._finish()
        self._known.add(path)
        self.resolved.emit(path, duration)

    def _on_error(self, _error: QMediaPlayer.Error, _message: str) -> None:
        if self._current is None:
            return
        path = self._current
        self._finish()
        self._failed.add(path)
        self.failed.emit(path)

    def _on_timeout(self) -> None:
        if self._current is None:
            return
        path = self._current
        self._finish()
        self._failed.add(path)
        self.failed.emit(path)

    def _finish(self) -> None:
        self._timer.stop()
        self._current = None
        QTimer.singleShot(0, self._start_next)
