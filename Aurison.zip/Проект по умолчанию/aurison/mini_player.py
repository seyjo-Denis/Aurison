from __future__ import annotations

from PySide6.QtCore import QPoint, QRectF, Qt, Signal
from PySide6.QtGui import QColor, QFont, QFontMetrics, QPainter, QPen
from PySide6.QtWidgets import (
    QHBoxLayout,
    QLabel,
    QMenu,
    QSizePolicy,
    QVBoxLayout,
    QWidget,
)

from aurison.icons import icon
from aurison.i18n import tr
from aurison.library import Track
from aurison.widgets import DARK_ICON, MUTED, JumpSlider, make_icon_button


class FittingTitleLabel(QLabel):
    """Small single-line label that shrinks its font until the title fits."""

    MIN_SIZE = 5
    MAX_SIZE = 7

    def __init__(self, text: str = "", parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._full_text = ""
        self.setObjectName("MiniTitle")
        self.setTextFormat(Qt.TextFormat.PlainText)
        self.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Fixed)
        self.setFixedHeight(12)
        self.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        self.setText(text)

    def setText(self, text: str) -> None:  # noqa: N802
        self._full_text = text
        self._refit()

    def full_text(self) -> str:
        return self._full_text

    def resizeEvent(self, event) -> None:  # noqa: N802
        super().resizeEvent(event)
        self._refit()

    def _refit(self) -> None:
        available = max(10, self.contentsRect().width() - 1)
        text = self._full_text
        if not text:
            QLabel.setText(self, "")
            self.setToolTip("")
            return

        font = QFont(self.font())
        font.setWeight(QFont.Weight.DemiBold)
        chosen = self.MIN_SIZE
        for size in range(self.MAX_SIZE, self.MIN_SIZE - 1, -1):
            font.setPixelSize(size)
            if QFontMetrics(font).horizontalAdvance(text) <= available:
                chosen = size
                break

        font.setPixelSize(chosen)
        self.setFont(font)
        metrics = QFontMetrics(font)
        display = text
        if metrics.horizontalAdvance(display) > available:
            display = metrics.elidedText(
                text, Qt.TextElideMode.ElideRight, available
            )
        QLabel.setText(self, display)
        self.setToolTip(text if display != text else "")


class MiniPlayer(QWidget):
    playPauseClicked = Signal()
    nextClicked = Signal()
    previousClicked = Signal()
    expandClicked = Signal()
    quitRequested = Signal()
    volumeChanged = Signal(int)
    muteClicked = Signal()
    seekRequested = Signal(int)

    CARD_WIDTH = 368
    CARD_HEIGHT = 88
    PROGRESS_MARGIN = 16

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setWindowTitle("Aurison")
        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint
            | Qt.WindowType.WindowStaysOnTopHint
            | Qt.WindowType.Tool
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self.setFixedSize(self.CARD_WIDTH, self.CARD_HEIGHT)
        self.setMouseTracking(True)

        self._playing = False
        self._position = 0
        self._duration = 0
        self._muted = False
        self._track: Track | None = None
        self._drag_offset: QPoint | None = None
        self._allow_close = False
        self._hover_progress = False
        self._seeking = False

        root = QHBoxLayout(self)
        root.setContentsMargins(14, 8, 10, 16)
        root.setSpacing(4)

        text_column = QVBoxLayout()
        text_column.setContentsMargins(0, 0, 0, 0)
        text_column.setSpacing(1)
        self.title = FittingTitleLabel(tr("Ничего не играет"), self)
        self.state = QLabel(tr("Остановлен"), self)
        self.state.setObjectName("MiniState")

        volume_row = QHBoxLayout()
        volume_row.setContentsMargins(0, 0, 0, 0)
        volume_row.setSpacing(4)
        self.mute_btn = make_icon_button(
            self, "volume", MUTED, 12, 18, tr("Выключить звук"), "MiniButton"
        )
        self.volume = JumpSlider(Qt.Orientation.Horizontal, self)
        self.volume.setObjectName("MiniVolume")
        self.volume.setRange(0, 100)
        self.volume.setValue(70)
        self.volume.setFixedHeight(14)
        self.volume.setToolTip(tr("Громкость"))
        volume_row.addWidget(self.mute_btn)
        volume_row.addWidget(self.volume, 1)

        text_column.addStretch(1)
        text_column.addWidget(self.title)
        text_column.addWidget(self.state)
        text_column.addSpacing(2)
        text_column.addLayout(volume_row)
        text_column.addStretch(1)

        self.prev_btn = make_icon_button(
            self, "prev", MUTED, 15, 28, tr("Предыдущий трек"), "MiniButton"
        )
        self.play_btn = make_icon_button(
            self, "play", DARK_ICON, 14, 34, tr("Воспроизведение"), "MiniPlay"
        )
        self.next_btn = make_icon_button(
            self, "next", MUTED, 15, 28, tr("Следующий трек"), "MiniButton"
        )
        self.expand_btn = make_icon_button(
            self, "expand", MUTED, 14, 26, tr("Развернуть плеер"), "MiniButton"
        )

        root.addLayout(text_column, 1)
        root.addWidget(self.prev_btn, 0, Qt.AlignmentFlag.AlignVCenter)
        root.addWidget(self.play_btn, 0, Qt.AlignmentFlag.AlignVCenter)
        root.addWidget(self.next_btn, 0, Qt.AlignmentFlag.AlignVCenter)
        root.addWidget(self.expand_btn, 0, Qt.AlignmentFlag.AlignVCenter)

        self.play_btn.clicked.connect(self.playPauseClicked)
        self.prev_btn.clicked.connect(self.previousClicked)
        self.next_btn.clicked.connect(self.nextClicked)
        self.expand_btn.clicked.connect(self.expandClicked)
        self.volume.valueChanged.connect(self._on_volume_value_changed)
        self.mute_btn.clicked.connect(self.muteClicked)

        self.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.customContextMenuRequested.connect(self._show_menu)
        self._refresh_volume_icon()

    # ---- state ---------------------------------------------------------

    def set_track(self, track: Track | None) -> None:
        self._track = track
        self.title.setText(track.title if track else tr("Ничего не играет"))
        self.title.setToolTip(track.path if track else "")

    def retranslate(self) -> None:
        """Refresh all visible text after the UI language changed."""
        self.title.setText(
            self._track.title if self._track else tr("Ничего не играет")
        )
        self.prev_btn.setToolTip(tr("Предыдущий трек"))
        self.next_btn.setToolTip(tr("Следующий трек"))
        self.expand_btn.setToolTip(tr("Развернуть плеер"))
        self.volume.setToolTip(tr("Громкость"))
        self._refresh_play_state_text()
        self._refresh_volume_icon()

    def _refresh_play_state_text(self) -> None:
        if self._playing:
            self.play_btn.setToolTip(tr("Пауза"))
            self.state.setText(tr("Играет"))
        else:
            self.play_btn.setToolTip(tr("Воспроизведение"))
            self.state.setText(
                tr("На паузе") if self._position > 0 else tr("Остановлен")
            )

    def set_playing(self, playing: bool) -> None:
        self._playing = bool(playing)
        if playing:
            self.play_btn.setIcon(icon("pause", DARK_ICON, 14))
            self.play_btn.setToolTip(tr("Пауза"))
            self.state.setText(tr("Играет"))
        else:
            self.play_btn.setIcon(icon("play", DARK_ICON, 14))
            self.play_btn.setToolTip(tr("Воспроизведение"))
            self.state.setText(
                tr("На паузе") if self._position > 0 else tr("Остановлен")
            )

    def set_progress(self, position_ms: int, duration_ms: int) -> None:
        self._duration = max(0, int(duration_ms))
        if not self._seeking:
            position = max(0, int(position_ms))
            if self._duration:
                position = min(position, self._duration)
            self._position = position
        self.update()

    def set_volume(self, percent: int, muted: bool = False) -> None:
        self._muted = bool(muted)
        self.volume.blockSignals(True)
        self.volume.setValue(max(0, min(100, int(percent))))
        self.volume.blockSignals(False)
        self._refresh_volume_icon()

    def set_muted(self, muted: bool) -> None:
        self._muted = bool(muted)
        self._refresh_volume_icon()

    def show_at_saved_position(self, position: list[int] | None) -> None:
        if position is not None:
            self.move(position[0], position[1])
            self._ensure_on_screen()
            return
        screen = self.screen()
        if screen is None:
            return
        geometry = screen.availableGeometry()
        self.move(
            geometry.right() - self.width() - 24,
            geometry.bottom() - self.height() - 24,
        )

    def _ensure_on_screen(self) -> None:
        from PySide6.QtGui import QGuiApplication

        screens = QGuiApplication.screens()
        for screen in screens:
            if screen.availableGeometry().intersects(self.frameGeometry()):
                return
        screen = QGuiApplication.primaryScreen()
        if screen is None:
            return
        geometry = screen.availableGeometry()
        x = min(max(self.x(), geometry.left()), geometry.right() - self.width())
        y = min(max(self.y(), geometry.top()), geometry.bottom() - self.height())
        self.move(x, y)

    # ---- painting ------------------------------------------------------

    def paintEvent(self, event) -> None:  # noqa: N802
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        card = QRectF(0.5, 0.5, self.width() - 1, self.height() - 1)
        painter.setPen(QPen(QColor("#2e323b"), 1))
        painter.setBrush(QColor("#17191e"))
        painter.drawRoundedRect(card, 14, 14)

        bar_x = float(self.PROGRESS_MARGIN)
        bar_width = float(self.width() - self.PROGRESS_MARGIN * 2)
        active = self._hover_progress or self._seeking
        bar_height = 5.0 if active else 3.0
        center_y = self.height() - 7.5
        bar_y = center_y - bar_height / 2.0

        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QColor("#2a2e36"))
        painter.drawRoundedRect(
            QRectF(bar_x, bar_y, bar_width, bar_height),
            bar_height / 2.0,
            bar_height / 2.0,
        )

        fraction = 0.0
        if self._duration > 0:
            fraction = min(1.0, max(0.0, self._position / self._duration))
            if fraction > 0:
                fill_width = min(bar_width, max(bar_height, bar_width * fraction))
                painter.setBrush(QColor("#9db4ff"))
                painter.drawRoundedRect(
                    QRectF(bar_x, bar_y, fill_width, bar_height),
                    bar_height / 2.0,
                    bar_height / 2.0,
                )

        if active and self._duration > 0:
            knob_x = bar_x + bar_width * fraction
            painter.setBrush(QColor("#f2f4f8"))
            painter.drawEllipse(
                QRectF(knob_x - 3.5, center_y - 3.5, 7.0, 7.0)
            )

    # ---- progress interaction -----------------------------------------

    def _progress_zone(self, point: QPoint) -> bool:
        return (
            self._duration > 0
            and self.height() - 22 <= point.y() <= self.height() - 1
            and 6 <= point.x() <= self.width() - 6
        )

    def _position_at(self, x: int) -> int:
        bar_width = max(1.0, float(self.width() - self.PROGRESS_MARGIN * 2))
        offset = min(
            bar_width, max(0.0, float(x - self.PROGRESS_MARGIN))
        )
        return int(round(self._duration * offset / bar_width))

    # ---- window behaviour ---------------------------------------------

    def mousePressEvent(self, event) -> None:  # noqa: N802
        if event.button() == Qt.MouseButton.LeftButton:
            point = event.position().toPoint()
            if self._progress_zone(point):
                self._seeking = True
                self._position = self._position_at(point.x())
                self.setCursor(Qt.CursorShape.PointingHandCursor)
                self.update()
                event.accept()
                return
            self._drag_offset = (
                event.globalPosition().toPoint() - self.frameGeometry().topLeft()
            )
            event.accept()
            return
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event) -> None:  # noqa: N802
        point = event.position().toPoint()
        if self._seeking:
            self._position = self._position_at(point.x())
            self.update()
            event.accept()
            return
        if self._drag_offset is not None and event.buttons() & Qt.MouseButton.LeftButton:
            self.move(event.globalPosition().toPoint() - self._drag_offset)
            event.accept()
            return

        hover = self._progress_zone(point)
        if hover != self._hover_progress:
            self._hover_progress = hover
            self.setCursor(
                Qt.CursorShape.PointingHandCursor
                if hover
                else Qt.CursorShape.ArrowCursor
            )
            self.update()
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event) -> None:  # noqa: N802
        if self._seeking and event.button() == Qt.MouseButton.LeftButton:
            self._position = self._position_at(event.position().toPoint().x())
            self._seeking = False
            self.update()
            self.seekRequested.emit(self._position)
            event.accept()
            return
        self._drag_offset = None
        super().mouseReleaseEvent(event)

    def leaveEvent(self, event) -> None:  # noqa: N802
        if not self._seeking and self._hover_progress:
            self._hover_progress = False
            self.setCursor(Qt.CursorShape.ArrowCursor)
            self.update()
        super().leaveEvent(event)

    def hideEvent(self, event) -> None:  # noqa: N802
        self._seeking = False
        self._hover_progress = False
        self._drag_offset = None
        self.setCursor(Qt.CursorShape.ArrowCursor)
        super().hideEvent(event)

    def closeEvent(self, event) -> None:  # noqa: N802
        if self._allow_close:
            event.accept()
            return
        event.ignore()

    def close_for_quit(self) -> None:
        self._allow_close = True
        self.close()

    def _show_menu(self, position: QPoint) -> None:
        menu = QMenu(self)
        quit_action = menu.addAction(tr("Выход"))
        chosen = menu.exec(self.mapToGlobal(position))
        if chosen == quit_action:
            self.quitRequested.emit()

    # ---- volume --------------------------------------------------------

    def _on_volume_value_changed(self, value: int) -> None:
        self._refresh_volume_icon()
        self.volumeChanged.emit(value)

    def _refresh_volume_icon(self) -> None:
        muted = self._muted or self.volume.value() == 0
        self.mute_btn.setIcon(
            icon("volume_off" if muted else "volume", MUTED, 12)
        )
        self.mute_btn.setToolTip(
            tr("Включить звук") if muted else tr("Выключить звук")
        )
