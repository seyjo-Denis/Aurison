from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtGui import QKeySequence
from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDialog,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QKeySequenceEdit,
    QLabel,
    QPushButton,
    QVBoxLayout,
)

from aurison.config import DEFAULT_HOTKEYS
from aurison.hotkeys import parse_sequence
from aurison.i18n import get_language, hotkey_labels, tr


class SettingsDialog(QDialog):
    def __init__(
        self,
        hotkeys: dict[str, str],
        hotkeys_enabled: bool,
        language: str,
        mini_player_enabled: bool = True,
        parent=None,
    ) -> None:
        super().__init__(parent)
        self.setObjectName("SettingsDialog")
        self.setWindowTitle(tr("Настройки") + " — Aurison")
        self.setModal(True)
        self.setFixedWidth(560)
        self._title_applied = False
        self._initial_language = (
            language if language in ("ru", "en") else get_language()
        )

        root = QVBoxLayout(self)
        root.setContentsMargins(28, 24, 28, 22)
        root.setSpacing(14)

        title = QLabel(tr("Настройки"), self)
        title.setObjectName("DialogTitle")
        root.addWidget(title)

        subtitle = QLabel("Aurison · " + tr("MP3-плеер"), self)
        subtitle.setObjectName("DialogSubtitle")
        root.addWidget(subtitle)

        divider = QFrame(self)
        divider.setObjectName("DialogDivider")
        divider.setFixedHeight(1)
        root.addWidget(divider)

        language_section = QLabel(tr("ЯЗЫК"), self)
        language_section.setObjectName("Section")
        root.addWidget(language_section)

        language_row = QHBoxLayout()
        language_row.setContentsMargins(0, 0, 0, 0)
        language_row.setSpacing(20)
        language_label = QLabel(tr("Язык"), self)
        language_label.setObjectName("FieldLabel")
        self.language_combo = QComboBox(self)
        self.language_combo.setObjectName("LanguageCombo")
        self.language_combo.addItem(tr("Русский"), "ru")
        self.language_combo.addItem("English", "en")
        index = self.language_combo.findData(self._initial_language)
        self.language_combo.setCurrentIndex(max(0, index))
        self.language_combo.setFixedWidth(200)
        language_row.addWidget(language_label)
        language_row.addStretch(1)
        language_row.addWidget(self.language_combo)
        root.addLayout(language_row)

        mini_section = QLabel(tr("МИНИ-ПЛЕЕР"), self)
        mini_section.setObjectName("Section")
        root.addWidget(mini_section)

        mini_hint = QLabel(
            tr(
                "Когда включено, при сворачивании появляется компактный "
                "мини-плеер. Если выключено, окно сворачивается в панель "
                "задач, а музыка продолжает играть."
            ),
            self,
        )
        mini_hint.setObjectName("Hint")
        mini_hint.setWordWrap(True)
        root.addWidget(mini_hint)

        self.mini_box = QCheckBox(
            tr("Показывать мини-плеер при сворачивании"), self
        )
        self.mini_box.setChecked(mini_player_enabled)
        root.addWidget(self.mini_box)

        hotkey_section = QLabel(tr("ГОРЯЧИЕ КЛАВИШИ"), self)
        hotkey_section.setObjectName("Section")
        root.addWidget(hotkey_section)

        description = QLabel(
            tr(
                "Управляйте плеером из любого приложения, "
                "даже когда окно свёрнуто."
            ),
            self,
        )
        description.setObjectName("Hint")
        description.setWordWrap(True)
        root.addWidget(description)

        self.enabled_box = QCheckBox(
            tr("Включить глобальные горячие клавиши"), self
        )
        self.enabled_box.setChecked(hotkeys_enabled)
        self.enabled_box.toggled.connect(self._update_enabled_state)
        root.addWidget(self.enabled_box)

        grid = QGridLayout()
        grid.setContentsMargins(0, 4, 0, 0)
        grid.setHorizontalSpacing(20)
        grid.setVerticalSpacing(10)
        self.edits: dict[str, QKeySequenceEdit] = {}
        for row, (action, label) in enumerate(hotkey_labels().items()):
            field_label = QLabel(label, self)
            field_label.setObjectName("FieldLabel")
            edit = QKeySequenceEdit(self)
            edit.setMaximumSequenceLength(1)
            edit.setKeySequence(
                QKeySequence(hotkeys.get(action, DEFAULT_HOTKEYS[action]))
            )
            edit.setFixedWidth(200)
            self.edits[action] = edit
            grid.addWidget(field_label, row, 0)
            grid.addWidget(edit, row, 1, Qt.AlignmentFlag.AlignRight)
        grid.setColumnStretch(0, 1)
        root.addLayout(grid)

        hint = QLabel(
            tr(
                "Нужен хотя бы один модификатор: Ctrl, Alt или Win. "
                "Например: Ctrl+Alt+Space."
            ),
            self,
        )
        hint.setObjectName("Hint")
        hint.setWordWrap(True)
        root.addWidget(hint)

        self.error_label = QLabel("", self)
        self.error_label.setObjectName("ErrorLabel")
        self.error_label.setWordWrap(True)
        self.error_label.hide()
        root.addWidget(self.error_label)

        root.addStretch(1)

        buttons = QHBoxLayout()
        buttons.setSpacing(8)
        self.reset_btn = QPushButton(tr("Сбросить"), self)
        self.reset_btn.setObjectName("GhostButton")
        self.reset_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.cancel_btn = QPushButton(tr("Отмена"), self)
        self.cancel_btn.setObjectName("SecondaryButton")
        self.cancel_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.save_btn = QPushButton(tr("Сохранить"), self)
        self.save_btn.setObjectName("PrimaryButton")
        self.save_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.save_btn.setDefault(True)
        buttons.addWidget(self.reset_btn)
        buttons.addStretch(1)
        buttons.addWidget(self.cancel_btn)
        buttons.addWidget(self.save_btn)
        root.addLayout(buttons)

        self.reset_btn.clicked.connect(self._reset)
        self.cancel_btn.clicked.connect(self.reject)
        self.save_btn.clicked.connect(self._validate_and_accept)
        self._update_enabled_state(self.enabled_box.isChecked())

    def values(self) -> tuple[dict[str, str], bool, str, bool]:
        return (
            {
                action: edit.keySequence().toString(
                    QKeySequence.SequenceFormat.PortableText
                )
                for action, edit in self.edits.items()
            },
            self.enabled_box.isChecked(),
            self.language_combo.currentData() or self._initial_language,
            self.mini_box.isChecked(),
        )

    def _update_enabled_state(self, enabled: bool) -> None:
        for edit in self.edits.values():
            edit.setEnabled(enabled)
        if enabled:
            self.error_label.hide()

    def _reset(self) -> None:
        for action, edit in self.edits.items():
            edit.setKeySequence(QKeySequence(DEFAULT_HOTKEYS[action]))
        self.enabled_box.setChecked(True)
        self.error_label.hide()

    def _show_error(self, message: str) -> None:
        self.error_label.setText(message)
        self.error_label.show()

    def _validate_and_accept(self) -> None:
        if not self.enabled_box.isChecked():
            self.accept()
            return

        labels = hotkey_labels()
        empty = [
            label
            for action, label in labels.items()
            if self.edits[action].keySequence().isEmpty()
        ]
        if empty:
            self._show_error(
                tr("Задайте сочетание для: {names}.").format(
                    names=", ".join(empty)
                )
            )
            return

        seen: dict[str, str] = {}
        for action, label in labels.items():
            sequence = self.edits[action].keySequence()
            portable = sequence.toString(QKeySequence.SequenceFormat.PortableText)
            if portable in seen:
                self._show_error(
                    tr(
                        "Сочетание «{sequence}» назначено дважды: "
                        "«{first}» и «{second}»."
                    ).format(
                        sequence=sequence.toString(),
                        first=seen[portable],
                        second=label,
                    )
                )
                return
            seen[portable] = label

            parsed = parse_sequence(portable)
            if parsed is None:
                self._show_error(
                    tr(
                        "Для «{label}» нужно одно сочетание с Ctrl, Alt или Win "
                        "и поддерживаемой клавишей."
                    ).format(label=label)
                )
                return

        self.accept()

    def showEvent(self, event) -> None:  # noqa: N802
        super().showEvent(event)
        if not self._title_applied:
            self._title_applied = True
            try:
                from aurison.platform_win import apply_dark_title_bar

                apply_dark_title_bar(self)
            except Exception:
                pass
