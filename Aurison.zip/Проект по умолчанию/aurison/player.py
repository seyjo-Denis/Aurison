from __future__ import annotations

import random

from PySide6.QtCore import QObject, QUrl, Signal
from PySide6.QtMultimedia import QAudioOutput, QMediaPlayer

from aurison.i18n import tr
from aurison.library import Track


class PlaybackController(QObject):
    trackChanged = Signal(object)
    playbackStateChanged = Signal(object)
    positionChanged = Signal(int)
    durationChanged = Signal(int)
    shuffleChanged = Signal(bool)
    repeatChanged = Signal(bool)
    queueChanged = Signal()
    previewFinished = Signal()
    errorOccurred = Signal(str)

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self._audio = QAudioOutput(self)
        self._audio.setVolume(0.7)
        self._player = QMediaPlayer(self)
        self._player.setAudioOutput(self._audio)

        self._queue: list[Track] = []
        self._index = -1
        self._preview: Track | None = None
        self._back: list[int] = []
        self._forward: list[int] = []
        self._shuffle_bag: list[int] = []
        self._shuffle = False
        self._repeat_one = False
        self._muted = False
        self._last_volume = 70

        self._player.positionChanged.connect(self._emit_position)
        self._player.durationChanged.connect(self._on_duration)
        self._player.playbackStateChanged.connect(self._emit_state)
        self._player.mediaStatusChanged.connect(self._on_media_status)
        self._player.errorOccurred.connect(self._on_error)

    # ---- state ---------------------------------------------------------

    @property
    def current_track(self) -> Track | None:
        if self._preview is not None:
            return self._preview
        if 0 <= self._index < len(self._queue):
            return self._queue[self._index]
        return None

    def is_previewing(self) -> bool:
        return self._preview is not None

    @property
    def queue(self) -> list[Track]:
        return self._queue

    @property
    def current_index(self) -> int:
        return self._index

    def has_queue(self) -> bool:
        return bool(self._queue)

    def is_playing(self) -> bool:
        return self._player.playbackState() == QMediaPlayer.PlaybackState.PlayingState

    def is_muted(self) -> bool:
        return self._muted

    def volume(self) -> int:
        return int(round(self._audio.volume() * 100))

    def position(self) -> int:
        return max(0, self._player.position())

    def duration(self) -> int:
        return max(0, self._player.duration())

    def media_finished(self) -> bool:
        return self._player.mediaStatus() == QMediaPlayer.MediaStatus.EndOfMedia

    # ---- transport -----------------------------------------------------

    def play_queue(self, tracks: list[Track], start_index: int = 0) -> None:
        tracks = [track for track in tracks if track]
        if not tracks:
            return
        index = max(0, min(start_index, len(tracks) - 1))
        self._preview = None
        self._queue = list(tracks)
        self._index = index
        self._back.clear()
        self._forward.clear()
        self._rebuild_shuffle_bag()
        self.queueChanged.emit()
        self._play_index(index)

    def prepare_preview(
        self,
        url: str,
        title: str,
        duration_ms: int = 0,
    ) -> None:
        """Show a remote track on the player before its stream is resolved."""
        self._preview = Track(
            path=url or title,
            title=title or url or tr("Ничего не играет"),
            duration_ms=max(0, int(duration_ms)),
        )
        self._queue = []
        self._index = -1
        self._back.clear()
        self._forward.clear()
        self._shuffle_bag.clear()
        self._player.stop()
        self._player.setSource(QUrl())
        self.queueChanged.emit()
        self.trackChanged.emit(self._preview)

    def play_preview(
        self,
        url: str,
        title: str,
        duration_ms: int = 0,
    ) -> None:
        """Play a remote audio stream without touching the local library."""
        if not url:
            return
        self.prepare_preview(url, title, duration_ms)
        self._player.setSource(QUrl(url))
        self._apply_loops()
        self._player.play()

    def stop_preview(self) -> None:
        if self._preview is None:
            return
        self._preview = None
        self._player.stop()
        self._player.setSource(QUrl())
        self.trackChanged.emit(None)

    def apply_order(self, paths: list[str]) -> None:
        """Reorder the active queue when the visible track order changes."""
        if not self._queue or not paths:
            return
        if len(self._queue) != len(paths):
            return
        old_paths = [track.path for track in self._queue]
        if old_paths == paths:
            return
        if len(set(old_paths)) != len(old_paths):
            return
        if set(old_paths) != set(paths):
            return

        old_by_path = {track.path: index for index, track in enumerate(self._queue)}
        new_by_path = {track.path: track for track in self._queue}
        remap = {
            old_by_path[path]: new_index
            for new_index, path in enumerate(paths)
        }
        self._queue = [new_by_path[path] for path in paths]
        self._index = remap.get(self._index, -1)
        self._back = [
            remap[index] for index in self._back if index in remap
        ]
        self._forward = [
            remap[index] for index in self._forward if index in remap
        ]
        if self._shuffle_bag:
            self._shuffle_bag = [
                remap[index]
                for index in self._shuffle_bag
                if index in remap
            ]
        self.queueChanged.emit()

    def toggle_play_pause(self) -> None:
        if self._preview is not None:
            if self.is_playing():
                self._player.pause()
                return
            if self.media_finished():
                self._player.setPosition(0)
            self._player.play()
            return
        if not self._queue:
            if self._index >= 0:
                self._player.play()
            return
        if self.is_playing():
            self._player.pause()
            return
        if self._index < 0:
            self._index = 0
        if self._player.source().isEmpty():
            self._play_index(self._index)
            return
        if self.media_finished():
            self._player.setPosition(0)
        self._player.play()

    def play(self) -> None:
        if self._queue and not self.is_playing():
            self.toggle_play_pause()

    def pause(self) -> None:
        if self.is_playing():
            self._player.pause()

    def next_track(self, manual: bool = True) -> None:
        if not self._queue:
            return
        if self._index < 0:
            self._play_index(0)
            return

        if self._forward:
            new_index = self._forward.pop()
            self._back.append(self._index)
            self._play_index(new_index)
            return

        if self._shuffle:
            if not self._shuffle_bag:
                self._rebuild_shuffle_bag()
            if not self._shuffle_bag:
                self._play_index(self._index)
                return
            new_index = self._shuffle_bag.pop()
        else:
            new_index = self._index + 1
            if new_index >= len(self._queue):
                new_index = 0

        self._back.append(self._index)
        self._play_index(new_index)

    def previous_track(self) -> None:
        if not self._queue or self._index < 0:
            return
        if self.position() > 3000 and not self.media_finished():
            self._player.setPosition(0)
            return
        if self._back:
            new_index = self._back.pop()
            self._forward.append(self._index)
            self._play_index(new_index)
            return
        if self._index > 0:
            self._forward.append(self._index)
            self._play_index(self._index - 1)
            return
        self._player.setPosition(0)

    def seek(self, position_ms: int) -> None:
        duration = self._player.duration()
        if duration <= 0:
            return
        self._player.setPosition(max(0, min(int(position_ms), duration)))

    def stop(self) -> None:
        self._player.stop()

    # ---- audio ---------------------------------------------------------

    def set_volume(self, percent: int) -> None:
        percent = max(0, min(100, int(percent)))
        self._audio.setVolume(percent / 100.0)
        if percent > 0:
            self._last_volume = percent

    def set_muted(self, muted: bool) -> None:
        self._muted = bool(muted)
        self._audio.setMuted(self._muted)

    # ---- modes ---------------------------------------------------------

    def set_shuffle(self, enabled: bool) -> None:
        enabled = bool(enabled)
        if self._shuffle == enabled:
            return
        self._shuffle = enabled
        self._forward.clear()
        self._rebuild_shuffle_bag()
        self.shuffleChanged.emit(enabled)

    def set_repeat_one(self, enabled: bool) -> None:
        enabled = bool(enabled)
        if self._repeat_one == enabled:
            return
        self._repeat_one = enabled
        self._apply_loops()
        self.repeatChanged.emit(enabled)

    def shuffle(self) -> bool:
        return self._shuffle

    def repeat_one(self) -> bool:
        return self._repeat_one

    # ---- internals -----------------------------------------------------

    def _play_index(self, index: int) -> None:
        if not (0 <= index < len(self._queue)):
            return
        self._index = index
        track = self._queue[index]
        self._player.setSource(QUrl.fromLocalFile(track.path))
        self._apply_loops()
        self._player.play()
        self.trackChanged.emit(track)

    def _apply_loops(self) -> None:
        self._player.setLoops(
            QMediaPlayer.Loops.Infinite if self._repeat_one else QMediaPlayer.Loops.Once
        )

    def _rebuild_shuffle_bag(self) -> None:
        self._shuffle_bag = []
        if self._shuffle and 0 <= self._index < len(self._queue):
            self._shuffle_bag = [
                index for index in range(len(self._queue)) if index != self._index
            ]
            random.shuffle(self._shuffle_bag)

    def _finish_queue(self) -> None:
        self._player.stop()

    def _on_duration(self, duration_ms: int) -> None:
        track = self.current_track
        if track is not None and duration_ms > 0:
            track.duration_ms = int(duration_ms)
        self.durationChanged.emit(max(0, int(duration_ms)))

    def _emit_position(self, position_ms: int) -> None:
        self.positionChanged.emit(max(0, int(position_ms)))

    def _emit_state(self, state: QMediaPlayer.PlaybackState) -> None:
        self.playbackStateChanged.emit(state)

    def _on_media_status(self, status: QMediaPlayer.MediaStatus) -> None:
        if status != QMediaPlayer.MediaStatus.EndOfMedia:
            return
        if self._preview is not None:
            self.previewFinished.emit()
            return
        if self._repeat_one:
            self._player.setPosition(0)
            self._player.play()
            return
        self.next_track(manual=False)

    def _on_error(self, _error: QMediaPlayer.Error, message: str) -> None:
        if message:
            self.errorOccurred.emit(message)
