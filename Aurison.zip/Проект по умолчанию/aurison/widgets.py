from __future__ import annotations

from PySide6.QtCore import (
    QEasingCurve,
    QEvent,
    QSize,
    Qt,
    QTimer,
    QVariantAnimation,
    Signal,
)
from PySide6.QtGui import QColor, QFont, QPainter
from PySide6.QtWidgets import (
    QAbstractButton,
    QFrame,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QSizePolicy,
    QSlider,
    QStyle,
    QStyleOptionSlider,
    QVBoxLayout,
    QWidget,
)

from aurison.icons import icon
from aurison.i18n import tr
from aurison.library import Track, format_duration

ACCENT = "#9db4ff"
TEXT = "#c9ced8"
MUTED = "#9aa0ab"
DISABLED = "#7d838f"
DARK_ICON = "#111318"


def repolish(widget: QWidget) -> None:
    widget.style().unpolish(widget)
    widget.style().polish(widget)
    widget.update()


class ToggleSwitch(QAbstractButton):
    """Compact animated on/off switch painted without external assets."""

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setCheckable(True)
        self.setFixedSize(42, 24)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self._position = 0.0
        self._animation = QVariantAnimation(self)
        self._animation.setDuration(150)
        self._animation.setEasingCurve(QEasingCurve.Type.OutCubic)
        self._animation.valueChanged.connect(self._set_position)
        self.toggled.connect(self._animate)

    def set_checked_silently(self, checked: bool) -> None:
        self.blockSignals(True)
        self.setChecked(checked)
        self.blockSignals(False)
        self._animation.stop()
        self._set_position(1.0 if checked else 0.0)

    def _set_position(self, value: object) -> None:
        self._position = float(value)
        self.update()

    def _animate(self, checked: bool) -> None:
        self._animation.stop()
        self._animation.setStartValue(self._position)
        self._animation.setEndValue(1.0 if checked else 0.0)
        self._animation.start()

    def paintEvent(self, event) -> None:  # noqa: N802
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        painter.setPen(Qt.PenStyle.NoPen)

        off = QColor("#2a2e36")
        on = QColor("#8fa4ff")
        track = QColor(
            int(off.red() + (on.red() - off.red()) * self._position),
            int(off.green() + (on.green() - off.green()) * self._position),
            int(off.blue() + (on.blue() - off.blue()) * self._position),
        )
        painter.setBrush(track)
        painter.drawRoundedRect(1.0, 2.0, self.width() - 2.0, self.height() - 4.0, 10.0, 10.0)

        diameter = 18.0
        left = 3.0
        right = self.width() - 3.0 - diameter
        x = left + (right - left) * self._position
        painter.setBrush(QColor("#f5f7fb"))
        painter.drawEllipse(x, 3.0, diameter, diameter)


class ElidedLabel(QLabel):
    """QLabel that ellipsizes its text instead of clipping it."""

    def __init__(self, text: str = "", parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._full_text = ""
        self.setTextFormat(Qt.TextFormat.PlainText)
        self.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        self.setMinimumWidth(0)
        self.setText(text)

    def setText(self, text: str) -> None:  # noqa: N802
        self._full_text = text
        self._update_elided()

    def full_text(self) -> str:
        return self._full_text

    def _update_elided(self) -> None:
        width = max(0, self.contentsRect().width() - 2)
        elided = self.fontMetrics().elidedText(
            self._full_text, Qt.TextElideMode.ElideRight, width
        )
        if QLabel.text(self) != elided:
            QLabel.setText(self, elided)
        self.setToolTip(self._full_text if elided != self._full_text else "")

    def resizeEvent(self, event) -> None:  # noqa: N802
        super().resizeEvent(event)
        self._update_elided()

    def changeEvent(self, event) -> None:  # noqa: N802
        super().changeEvent(event)
        if event.type() in (QEvent.Type.FontChange, QEvent.Type.StyleChange):
            self._update_elided()


class JumpSlider(QSlider):
    """Slider where a click anywhere jumps straight to that position."""

    def __init__(self, orientation=Qt.Orientation.Horizontal, parent=None) -> None:
        super().__init__(orientation, parent)
        self._jump_drag = False
        self.setCursor(Qt.CursorShape.PointingHandCursor)

    def _value_at(self, x: int) -> int:
        option = QStyleOptionSlider()
        self.initStyleOption(option)
        groove = self.style().subControlRect(
            QStyle.ComplexControl.CC_Slider,
            option,
            QStyle.SubControl.SC_SliderGroove,
            self,
        )
        if groove.width() <= 0:
            return self.value()
        pos = max(0, min(int(x) - groove.x(), groove.width()))
        return int(
            QStyle.sliderValueFromPosition(
                self.minimum(), self.maximum(), pos, groove.width()
            )
        )

    def mousePressEvent(self, event) -> None:  # noqa: N802
        if (
            event.button() != Qt.MouseButton.LeftButton
            or not self.isEnabled()
            or self.maximum() <= self.minimum()
        ):
            super().mousePressEvent(event)
            return
        self._jump_drag = True
        self.setFocus(Qt.FocusReason.MouseFocusReason)
        self.setSliderDown(True)
        self.setValue(self._value_at(int(event.position().x())))
        self.grabMouse()
        event.accept()

    def mouseMoveEvent(self, event) -> None:  # noqa: N802
        if self._jump_drag:
            self.setValue(self._value_at(int(event.position().x())))
            event.accept()
            return
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event) -> None:  # noqa: N802
        if self._jump_drag and event.button() == Qt.MouseButton.LeftButton:
            self._jump_drag = False
            self.setValue(self._value_at(int(event.position().x())))
            self.releaseMouse()
            self.setSliderDown(False)
            self._on_user_finished()
            event.accept()
            return
        super().mouseReleaseEvent(event)

    def keyPressEvent(self, event) -> None:  # noqa: N802
        before = self.value()
        super().keyPressEvent(event)
        if self.value() != before:
            self._on_user_finished()

    def wheelEvent(self, event) -> None:  # noqa: N802
        before = self.value()
        super().wheelEvent(event)
        if self.value() != before:
            self._on_user_finished()

    def hideEvent(self, event) -> None:  # noqa: N802
        if self._jump_drag:
            self._jump_drag = False
            self.releaseMouse()
            self.setSliderDown(False)
        super().hideEvent(event)

    def _on_user_finished(self) -> None:
        pass


class SeekSlider(JumpSlider):
    seekRequested = Signal(int)
    scrubbingChanged = Signal(bool)

    def __init__(self, parent=None) -> None:
        super().__init__(Qt.Orientation.Horizontal, parent)
        self._scrubbing = False

    @property
    def scrubbing(self) -> bool:
        return self._scrubbing

    def mousePressEvent(self, event) -> None:  # noqa: N802
        if (
            event.button() == Qt.MouseButton.LeftButton
            and self.isEnabled()
            and self.maximum() > self.minimum()
        ):
            self._scrubbing = True
            self.scrubbingChanged.emit(True)
        super().mousePressEvent(event)

    def _on_user_finished(self) -> None:
        self._scrubbing = False
        self.scrubbingChanged.emit(False)
        self.seekRequested.emit(self.value())

    def hideEvent(self, event) -> None:  # noqa: N802
        super().hideEvent(event)
        if self._scrubbing:
            self._scrubbing = False
            self.scrubbingChanged.emit(False)


def make_icon_button(
    parent: QWidget,
    icon_name: str,
    color: str,
    icon_size: int,
    button_size: int,
    tooltip: str,
    object_name: str = "Transport",
    checkable: bool = False,
) -> QPushButton:
    button = QPushButton(parent)
    button.setObjectName(object_name)
    button.setFixedSize(button_size, button_size)
    button.setIcon(icon(icon_name, color, icon_size))
    button.setIconSize(QSize(icon_size, icon_size))
    button.setToolTip(tooltip)
    button.setCursor(Qt.CursorShape.PointingHandCursor)
    button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
    button.setCheckable(checkable)
    return button


class PlayerBar(QFrame):
    playPauseClicked = Signal()
    nextClicked = Signal()
    previousClicked = Signal()
    shuffleToggled = Signal(bool)
    repeatToggled = Signal(bool)
    muteClicked = Signal()
    volumeChanged = Signal(int)
    seekRequested = Signal(int)

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setObjectName("PlayerBar")
        self.setFixedHeight(96)

        self._duration = 0
        self._position = 0
        self._scrubbing = False
        self._has_current = False
        self._can_play = False
        self._muted = False
        self._playing = False
        self._current_title = ""
        self._error_active = False

        self._error_timer = QTimer(self)
        self._error_timer.setSingleShot(True)
        self._error_timer.timeout.connect(self._clear_error)

        root = QHBoxLayout(self)
        root.setContentsMargins(20, 10, 20, 10)
        root.setSpacing(16)

        # left: current track title
        left = QWidget(self)
        left.setMinimumWidth(150)
        left_layout = QVBoxLayout(left)
        left_layout.setContentsMargins(0, 0, 0, 0)
        left_layout.setSpacing(0)
        self.title = ElidedLabel(tr("Ничего не играет"), left)
        self.title.setObjectName("PlayerTitle")
        self.title.setProperty("empty", True)
        left_layout.addStretch(1)
        left_layout.addWidget(self.title)
        left_layout.addStretch(1)

        # center: transport + seek
        center = QWidget(self)
        center.setMinimumWidth(360)
        center_layout = QVBoxLayout(center)
        center_layout.setContentsMargins(0, 0, 0, 0)
        center_layout.setSpacing(5)

        controls = QHBoxLayout()
        controls.setContentsMargins(0, 0, 0, 0)
        controls.setSpacing(4)
        controls.addStretch(1)

        self.shuffle_btn = make_icon_button(
            self,
            "shuffle",
            MUTED,
            17,
            32,
            tr("Случайный порядок"),
            "ToggleButton",
            checkable=True,
        )
        self.prev_btn = make_icon_button(
            self, "prev", TEXT, 18, 34, tr("Предыдущий трек")
        )
        self.play_btn = make_icon_button(
            self,
            "play",
            DARK_ICON,
            17,
            42,
            tr("Воспроизведение"),
            "PlayButton",
        )
        self.next_btn = make_icon_button(
            self, "next", TEXT, 18, 34, tr("Следующий трек")
        )
        self.repeat_btn = make_icon_button(
            self,
            "repeat",
            MUTED,
            17,
            32,
            tr("Повтор одного трека"),
            "ToggleButton",
            checkable=True,
        )

        controls.addWidget(self.shuffle_btn)
        controls.addSpacing(6)
        controls.addWidget(self.prev_btn)
        controls.addWidget(self.play_btn)
        controls.addWidget(self.next_btn)
        controls.addSpacing(6)
        controls.addWidget(self.repeat_btn)
        controls.addStretch(1)

        seek_row = QHBoxLayout()
        seek_row.setContentsMargins(0, 0, 0, 0)
        seek_row.setSpacing(10)
        self.elapsed_label = QLabel("0:00", self)
        self.elapsed_label.setObjectName("Time")
        self.elapsed_label.setAlignment(
            Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter
        )
        self.elapsed_label.setFixedWidth(46)
        self.seek = SeekSlider(self)
        self.seek.setObjectName("Seek")
        self.seek.setRange(0, 0)
        self.seek.setFixedHeight(20)
        self.seek.setEnabled(False)
        self.remaining_label = QLabel("0:00", self)
        self.remaining_label.setObjectName("Time")
        self.remaining_label.setFixedWidth(50)
        self.remaining_label.setAlignment(
            Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter
        )
        seek_row.addWidget(self.elapsed_label)
        seek_row.addWidget(self.seek, 1)
        seek_row.addWidget(self.remaining_label)

        center_layout.addLayout(controls)
        center_layout.addLayout(seek_row)

        # right: volume
        right = QWidget(self)
        right.setFixedWidth(158)
        right_layout = QHBoxLayout(right)
        right_layout.setContentsMargins(0, 0, 0, 0)
        right_layout.setSpacing(2)
        right_layout.addStretch(1)
        self.mute_btn = make_icon_button(
            self, "volume", MUTED, 18, 30, tr("Выключить звук")
        )
        self.volume = JumpSlider(Qt.Orientation.Horizontal, self)
        self.volume.setObjectName("Volume")
        self.volume.setRange(0, 100)
        self.volume.setValue(70)
        self.volume.setFixedWidth(96)
        self.volume.setFixedHeight(20)
        self.volume.setToolTip(tr("Громкость"))
        right_layout.addWidget(self.mute_btn)
        right_layout.addWidget(self.volume)

        root.addWidget(left, 3)
        root.addWidget(center, 4)
        root.addWidget(right, 0)

        # signals
        self.play_btn.clicked.connect(self.playPauseClicked)
        self.next_btn.clicked.connect(self.nextClicked)
        self.prev_btn.clicked.connect(self.previousClicked)
        self.shuffle_btn.clicked.connect(self._on_shuffle_clicked)
        self.repeat_btn.clicked.connect(self._on_repeat_clicked)
        self.mute_btn.clicked.connect(self.muteClicked)
        self.volume.valueChanged.connect(self._on_volume_value_changed)
        self.seek.seekRequested.connect(self.seekRequested)
        self.seek.scrubbingChanged.connect(self._on_scrubbing_changed)
        self.seek.valueChanged.connect(self._on_seek_value_changed)

        self.set_transport_state(False, False)
        self._refresh_volume_icon()

    # ---- public API ----------------------------------------------------

    def set_track(self, track: Track | None) -> None:
        self._error_timer.stop()
        self._error_active = False
        self.title.setProperty("error", False)
        self._current_title = track.title if track else ""
        self.title.setText(self._current_title or tr("Ничего не играет"))
        self.title.setProperty("empty", track is None)
        repolish(self.title)
        self._has_current = track is not None
        self.set_duration(track.duration_ms if track else 0)
        self.set_position(0)
        self._update_enabled()

    def retranslate(self) -> None:
        """Refresh all visible text after the UI language changed."""
        if self._error_active:
            self.title.setText(tr("Не удалось воспроизвести файл"))
        else:
            self.title.setText(self._current_title or tr("Ничего не играет"))
        self.title.setProperty("empty", not self._has_current)
        repolish(self.title)
        self.play_btn.setToolTip(
            tr("Пауза") if self._playing else tr("Воспроизведение")
        )
        self.prev_btn.setToolTip(tr("Предыдущий трек"))
        self.next_btn.setToolTip(tr("Следующий трек"))
        self.shuffle_btn.setToolTip(tr("Случайный порядок"))
        self.repeat_btn.setToolTip(tr("Повтор одного трека"))
        self.volume.setToolTip(tr("Громкость"))
        self._refresh_volume_icon()

    def set_playing(self, playing: bool) -> None:
        self._playing = bool(playing)
        self.play_btn.setToolTip(
            tr("Пауза") if playing else tr("Воспроизведение")
        )
        self._refresh_play_icon()

    def set_volume(self, percent: int, muted: bool = False) -> None:
        self._muted = bool(muted)
        self.volume.blockSignals(True)
        self.volume.setValue(max(0, min(100, int(percent))))
        self.volume.blockSignals(False)
        self._refresh_volume_icon()

    def set_muted(self, muted: bool) -> None:
        self._muted = bool(muted)
        self._refresh_volume_icon()

    def set_shuffle_state(self, enabled: bool) -> None:
        self.shuffle_btn.blockSignals(True)
        self.shuffle_btn.setChecked(bool(enabled))
        self.shuffle_btn.blockSignals(False)
        self._refresh_shuffle_icon()

    def set_repeat_state(self, enabled: bool) -> None:
        self.repeat_btn.blockSignals(True)
        self.repeat_btn.setChecked(bool(enabled))
        self.repeat_btn.blockSignals(False)
        self._refresh_repeat_icon()

    def set_transport_state(self, can_play: bool, has_current: bool) -> None:
        self._can_play = bool(can_play)
        self._has_current = bool(has_current)
        self._update_enabled()

    def set_duration(self, duration_ms: int) -> None:
        self._duration = max(0, int(duration_ms))
        self.seek.setRange(0, self._duration)
        if self._position > self._duration:
            self._position = self._duration
            self.seek.setValue(self._position)
        self._update_time_labels(self._position)
        self._update_enabled()

    def set_position(self, position_ms: int) -> None:
        if self._scrubbing:
            return
        self._position = max(0, min(int(position_ms), self._duration))
        self.seek.setValue(self._position)
        self._update_time_labels(self._position)

    def flash_error(self, message: str) -> None:
        self._error_active = True
        self.title.setText(tr("Не удалось воспроизвести файл"))
        self.title.setProperty("empty", False)
        self.title.setProperty("error", True)
        self.title.setToolTip(message)
        repolish(self.title)
        self._error_timer.start(5000)

    # ---- internals -----------------------------------------------------

    def _clear_error(self) -> None:
        if not self._error_active:
            return
        self._error_active = False
        self.title.setProperty("error", False)
        self.title.setText(self._current_title or tr("Ничего не играет"))
        self.title.setProperty("empty", not self._has_current)
        repolish(self.title)

    def _update_enabled(self) -> None:
        self.play_btn.setEnabled(self._can_play or self._has_current)
        self.prev_btn.setEnabled(self._has_current)
        self.next_btn.setEnabled(self._has_current)
        self.seek.setEnabled(self._has_current and self._duration > 0)
        self._refresh_play_icon()

    def _refresh_play_icon(self) -> None:
        color = DARK_ICON if self.play_btn.isEnabled() else DISABLED
        name = "pause" if self._playing else "play"
        self.play_btn.setIcon(icon(name, color, 17))

    def _update_time_labels(self, position_ms: int) -> None:
        self.elapsed_label.setText(format_duration(position_ms))
        if self._duration > 0:
            remaining = max(0, self._duration - position_ms)
            self.remaining_label.setText("−" + format_duration(remaining))
        else:
            self.remaining_label.setText("0:00")

    def _on_scrubbing_changed(self, scrubbing: bool) -> None:
        self._scrubbing = scrubbing
        if not scrubbing:
            self._update_time_labels(self.seek.value())

    def _on_seek_value_changed(self, value: int) -> None:
        if self._scrubbing:
            self._update_time_labels(value)

    def _on_volume_value_changed(self, value: int) -> None:
        self._refresh_volume_icon()
        self.volumeChanged.emit(value)

    def _refresh_volume_icon(self) -> None:
        muted = self._muted or self.volume.value() == 0
        self.mute_btn.setIcon(icon("volume_off" if muted else "volume", MUTED, 18))
        self.mute_btn.setToolTip(
            tr("Включить звук") if muted else tr("Выключить звук")
        )

    def _on_shuffle_clicked(self, checked: bool) -> None:
        self._refresh_shuffle_icon()
        self.shuffleToggled.emit(checked)

    def _refresh_shuffle_icon(self) -> None:
        active = self.shuffle_btn.isChecked()
        self.shuffle_btn.setIcon(icon("shuffle", ACCENT if active else MUTED, 17))

    def _on_repeat_clicked(self, checked: bool) -> None:
        self._refresh_repeat_icon()
        self.repeatToggled.emit(checked)

    def _refresh_repeat_icon(self) -> None:
        active = self.repeat_btn.isChecked()
        self.repeat_btn.setIcon(
            icon("repeat_one" if active else "repeat", ACCENT if active else MUTED, 17)
        )


class Placeholder(QWidget):
    """Centered empty/loading state for the track view."""

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 24, 24, 24)
        layout.setSpacing(8)
        layout.addStretch(1)

        self.icon_label = QLabel(self)
        self.icon_label.setObjectName("PlaceholderIcon")
        self.icon_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(self.icon_label)

        self.title_label = QLabel(self)
        self.title_label.setObjectName("PlaceholderTitle")
        self.title_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(self.title_label)

        self.text_label = QLabel(self)
        self.text_label.setObjectName("PlaceholderText")
        self.text_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.text_label.setWordWrap(True)
        self.text_label.setFixedWidth(460)
        layout.addWidget(self.text_label, 0, Qt.AlignmentFlag.AlignHCenter)
        layout.addStretch(1)

        self._loading = False
        self._base_title = ""
        self._dots = 0
        self._timer = QTimer(self)
        self._timer.setInterval(420)
        self._timer.timeout.connect(self._tick_loading)

    def set_state(
        self,
        title: str,
        text: str,
        icon_name: str = "note",
        loading: bool = False,
    ) -> None:
        self._base_title = title
        self._loading = loading
        self.title_label.setText(title)
        self.text_label.setText(text)
        pixmap = icon(icon_name, "#3a404b", 54).pixmap(54, 54)
        self.icon_label.setPixmap(pixmap)
        if loading:
            self._dots = 0
            self._timer.start()
        else:
            self._timer.stop()

    def _tick_loading(self) -> None:
        if not self._loading:
            self._timer.stop()
            return
        self._dots = (self._dots + 1) % 4
        self.title_label.setText(self._base_title + "." * self._dots)
