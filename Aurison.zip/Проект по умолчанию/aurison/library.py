from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

from PySide6.QtCore import QThread, Signal

from aurison.config import config_dir
from aurison.titles import clean_track_title

try:
    import mutagen
except Exception:  # pragma: no cover - only if dependency is missing
    mutagen = None

AUDIO_EXTENSIONS: set[str] = {
    ".mp3",
    ".flac",
    ".wav",
    ".ogg",
    ".oga",
    ".opus",
    ".m4a",
    ".aac",
    ".wma",
    ".aiff",
    ".aif",
    ".webm",
    ".mp4",
}

IGNORED_DIRS: set[str] = {
    "$recycle.bin",
    "system volume information",
    "__macosx",
}


@dataclass
class Track:
    path: str
    title: str
    duration_ms: int

    @property
    def filename(self) -> str:
        return os.path.basename(self.path)


def natural_key(text: str) -> tuple:
    parts = re.split(r"(\d+)", text)
    return tuple(
        (0, int(part)) if part.isdigit() else (1, part.casefold())
        for part in parts
        if part
    )


def format_duration(ms: int) -> str:
    total = max(0, int(ms)) // 1000
    hours, rem = divmod(total, 3600)
    minutes, seconds = divmod(rem, 60)
    if hours:
        return f"{hours}:{minutes:02d}:{seconds:02d}"
    return f"{minutes}:{seconds:02d}"


def read_metadata(path: str) -> tuple[str, int]:
    title = Path(path).stem
    duration_ms = 0
    if mutagen is None:
        return title, duration_ms
    try:
        audio = mutagen.File(path, easy=True)
        if audio is not None:
            tags = audio.tags
            if tags:
                raw_title = tags.get("title")
                if isinstance(raw_title, (list, tuple)):
                    raw_title = raw_title[0] if raw_title else None
                if raw_title:
                    cleaned = str(raw_title).strip()
                    if cleaned:
                        title = cleaned
            info = getattr(audio, "info", None)
            length = getattr(info, "length", 0) or 0
            if length:
                duration_ms = max(0, int(round(float(length) * 1000)))
    except Exception:
        pass
    return clean_track_title(title), duration_ms


def scan_folder(
    folder: str,
    cache_snapshot: dict[str, dict],
    cancelled: Callable[[], bool] | None = None,
) -> tuple[list[Track], dict[str, dict]]:
    root = Path(folder)
    tracks: list[Track] = []
    updates: dict[str, dict] = {}
    if not root.is_dir():
        return tracks, updates

    for dirpath, dirnames, filenames in os.walk(root, onerror=lambda _e: None):
        if cancelled and cancelled():
            return [], {}
        dirnames[:] = sorted(
            (
                name
                for name in dirnames
                if not name.startswith(".") and name.casefold() not in IGNORED_DIRS
            ),
            key=natural_key,
        )
        for name in filenames:
            if cancelled and cancelled():
                return [], {}
            if name.startswith("."):
                continue
            ext = os.path.splitext(name)[1].lower()
            if ext not in AUDIO_EXTENSIONS:
                continue
            full = os.path.join(dirpath, name)
            try:
                stat = os.stat(full)
            except OSError:
                continue
            entry = cache_snapshot.get(full)
            if (
                isinstance(entry, dict)
                and entry.get("mtime") == stat.st_mtime
                and entry.get("size") == stat.st_size
            ):
                title = clean_track_title(
                    str(entry.get("title") or Path(name).stem)
                )
                duration = (
                    int(entry.get("duration") or 0)
                    if entry.get("duration_verified")
                    else 0
                )
            else:
                title, _untrusted_duration = read_metadata(full)
                duration = 0
                updates[full] = {
                    "mtime": stat.st_mtime,
                    "size": stat.st_size,
                    "title": title,
                    "duration": 0,
                    "duration_verified": False,
                }
            tracks.append(Track(path=full, title=title, duration_ms=duration))

    tracks.sort(key=lambda item: (natural_key(item.title), natural_key(item.path)))
    return tracks, updates


class TrackCache:
    """Small on-disk cache so repeated scans do not re-read every tag."""

    def __init__(self) -> None:
        self.path = config_dir() / "cache.json"
        self.entries: dict[str, dict] = {}
        self._load()

    def _load(self) -> None:
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return
        if isinstance(data, dict) and isinstance(data.get("entries"), dict):
            self.entries = {
                str(key): value
                for key, value in data["entries"].items()
                if isinstance(value, dict)
            }

    def snapshot(self) -> dict[str, dict]:
        return dict(self.entries)

    def update(self, updates: dict[str, dict]) -> None:
        for path, entry in updates.items():
            existing = self.entries.get(path)
            if (
                isinstance(existing, dict)
                and existing.get("duration_verified")
                and existing.get("mtime") == entry.get("mtime")
                and existing.get("size") == entry.get("size")
            ):
                merged = dict(entry)
                merged["duration"] = int(existing.get("duration") or 0)
                merged["duration_verified"] = True
                self.entries[path] = merged
            else:
                self.entries[path] = entry

    def save(self) -> None:
        tmp = self.path.with_suffix(".json.tmp")
        try:
            tmp.write_text(
                json.dumps({"version": 2, "entries": self.entries}, ensure_ascii=False),
                encoding="utf-8",
            )
            os.replace(tmp, self.path)
        except OSError:
            pass


class FolderScanThread(QThread):
    done = Signal(str, list, dict)

    def __init__(
        self,
        folder: str,
        cache_snapshot: dict[str, dict],
        parent=None,
    ) -> None:
        super().__init__(parent)
        self.folder = folder
        self._cache_snapshot = cache_snapshot

    def run(self) -> None:
        tracks, updates = scan_folder(
            self.folder,
            self._cache_snapshot,
            self.isInterruptionRequested,
        )
        if not self.isInterruptionRequested():
            self.done.emit(self.folder, tracks, updates)
