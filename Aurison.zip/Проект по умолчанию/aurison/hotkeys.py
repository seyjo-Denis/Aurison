from __future__ import annotations

import ctypes
import sys
from ctypes import wintypes
from typing import Callable

from PySide6.QtCore import QAbstractNativeEventFilter, QCoreApplication, Qt
from PySide6.QtGui import QKeySequence

IS_WINDOWS = sys.platform == "win32"

WM_HOTKEY = 0x0312
MOD_ALT = 0x0001
MOD_CONTROL = 0x0002
MOD_SHIFT = 0x0004
MOD_WIN = 0x0008
MOD_NOREPEAT = 0x4000

if IS_WINDOWS:
    _user32 = ctypes.WinDLL("user32", use_last_error=True)
    _user32.RegisterHotKey.argtypes = [
        wintypes.HWND,
        ctypes.c_int,
        wintypes.UINT,
        wintypes.UINT,
    ]
    _user32.RegisterHotKey.restype = wintypes.BOOL
    _user32.UnregisterHotKey.argtypes = [wintypes.HWND, ctypes.c_int]
    _user32.UnregisterHotKey.restype = wintypes.BOOL
else:
    _user32 = None


def _build_vk_map() -> dict[int, int]:
    mapping: dict[int, int] = {}
    for offset in range(26):
        mapping[int(Qt.Key.Key_A) + offset] = 0x41 + offset
    for offset in range(10):
        mapping[int(Qt.Key.Key_0) + offset] = 0x30 + offset
    for offset in range(24):
        mapping[int(Qt.Key.Key_F1) + offset] = 0x70 + offset
    mapping.update(
        {
            int(Qt.Key.Key_Space): 0x20,
            int(Qt.Key.Key_Return): 0x0D,
            int(Qt.Key.Key_Enter): 0x0D,
            int(Qt.Key.Key_Escape): 0x1B,
            int(Qt.Key.Key_Tab): 0x09,
            int(Qt.Key.Key_Backspace): 0x08,
            int(Qt.Key.Key_Insert): 0x2D,
            int(Qt.Key.Key_Delete): 0x2E,
            int(Qt.Key.Key_Home): 0x24,
            int(Qt.Key.Key_End): 0x23,
            int(Qt.Key.Key_PageUp): 0x21,
            int(Qt.Key.Key_PageDown): 0x22,
            int(Qt.Key.Key_Left): 0x25,
            int(Qt.Key.Key_Up): 0x26,
            int(Qt.Key.Key_Right): 0x27,
            int(Qt.Key.Key_Down): 0x28,
            int(Qt.Key.Key_Pause): 0x13,
            int(Qt.Key.Key_Print): 0x2C,
            int(Qt.Key.Key_Comma): 0xBC,
            int(Qt.Key.Key_Period): 0xBE,
            int(Qt.Key.Key_Slash): 0xBF,
            int(Qt.Key.Key_Semicolon): 0xBA,
            int(Qt.Key.Key_Apostrophe): 0xDE,
            int(Qt.Key.Key_BracketLeft): 0xDB,
            int(Qt.Key.Key_BracketRight): 0xDD,
            int(Qt.Key.Key_Backslash): 0xDC,
            int(Qt.Key.Key_Minus): 0xBD,
            int(Qt.Key.Key_Equal): 0xBB,
            int(Qt.Key.Key_QuoteLeft): 0xC0,
            int(Qt.Key.Key_MediaPlay): 0xB3,
            int(Qt.Key.Key_MediaPause): 0xB3,
            int(Qt.Key.Key_MediaTogglePlayPause): 0xB3,
            int(Qt.Key.Key_MediaNext): 0xB0,
            int(Qt.Key.Key_MediaPrevious): 0xB1,
            int(Qt.Key.Key_MediaStop): 0xB2,
        }
    )
    return mapping


VK_MAP = _build_vk_map()


def parse_sequence(text: str) -> tuple[int, int] | None:
    """Return (modifiers, virtual-key) for a single-chord shortcut."""
    sequence = QKeySequence(text)
    if sequence.isEmpty() or sequence.count() != 1:
        return None
    combination = sequence[0]
    vk = VK_MAP.get(int(combination.key()))
    if vk is None:
        return None

    modifiers = 0
    qt_modifiers = combination.keyboardModifiers()
    if qt_modifiers & Qt.KeyboardModifier.ControlModifier:
        modifiers |= MOD_CONTROL
    if qt_modifiers & Qt.KeyboardModifier.AltModifier:
        modifiers |= MOD_ALT
    if qt_modifiers & Qt.KeyboardModifier.ShiftModifier:
        modifiers |= MOD_SHIFT
    if qt_modifiers & Qt.KeyboardModifier.MetaModifier:
        modifiers |= MOD_WIN

    # A global shortcut without Ctrl/Alt/Win would swallow ordinary typing.
    if not modifiers & (MOD_CONTROL | MOD_ALT | MOD_WIN):
        return None
    return modifiers, vk


class _NativeFilter(QAbstractNativeEventFilter):
    def __init__(self, manager: "GlobalHotkeys") -> None:
        super().__init__()
        self._manager = manager

    def nativeEventFilter(self, event_type, message):  # noqa: N802
        if isinstance(event_type, (bytes, bytearray)):
            event_type = event_type.decode(errors="ignore")
        if event_type not in ("windows_generic_MSG", "windows_dispatcher_MSG"):
            return False, 0
        try:
            msg = wintypes.MSG.from_address(int(message))
        except (TypeError, ValueError, OSError):
            return False, 0
        if msg.message == WM_HOTKEY:
            self._manager._dispatch(int(msg.wParam))
        return False, 0


class GlobalHotkeys:
    supported = IS_WINDOWS

    def __init__(
        self,
        app: QCoreApplication,
        callbacks: dict[str, Callable[[], None]],
    ) -> None:
        self._app = app
        self._callbacks = callbacks
        self._ids: dict[int, str] = {}
        self._next_id = 1
        self._filter = _NativeFilter(self)
        app.installNativeEventFilter(self._filter)

    def register_all(self, mapping: dict[str, str]) -> list[str]:
        self.unregister_all()
        if not IS_WINDOWS or _user32 is None:
            return []
        failures: list[str] = []
        for action, text in mapping.items():
            if action not in self._callbacks:
                continue
            parsed = parse_sequence(text)
            if parsed is None:
                failures.append(action)
                continue
            modifiers, vk = parsed
            hotkey_id = 0x4E00 + self._next_id
            self._next_id += 1
            if _user32.RegisterHotKey(
                None, hotkey_id, modifiers | MOD_NOREPEAT, vk
            ):
                self._ids[hotkey_id] = action
            else:
                failures.append(action)
        return failures

    def unregister_all(self) -> None:
        if not IS_WINDOWS or _user32 is None:
            self._ids.clear()
            return
        for hotkey_id in list(self._ids):
            _user32.UnregisterHotKey(None, hotkey_id)
        self._ids.clear()

    def _dispatch(self, hotkey_id: int) -> None:
        action = self._ids.get(hotkey_id)
        if action is None:
            return
        callback = self._callbacks.get(action)
        if callback is not None:
            callback()

    def close(self) -> None:
        self.unregister_all()
        try:
            self._app.removeNativeEventFilter(self._filter)
        except Exception:
            pass
