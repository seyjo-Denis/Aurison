from __future__ import annotations

import json
import os
import shutil
from dataclasses import asdict, dataclass, field
from pathlib import Path

ALL_TRACKS = "::all::"

DEFAULT_HOTKEYS: dict[str, str] = {
    "play_pause": "Ctrl+Alt+Space",
    "next": "Ctrl+Alt+Right",
    "previous": "Ctrl+Alt+Left",
}


def _legacy_config_dir() -> Path:
    appdata = os.environ.get("APPDATA")
    if appdata:
        return Path(appdata) / "NoirPlayer"
    return Path.home() / ".noir-player"


def config_dir() -> Path:
    override = os.environ.get("AURISON_CONFIG_DIR") or os.environ.get(
        "NOIR_CONFIG_DIR"
    )
    if override:
        base = Path(override)
    else:
        appdata = os.environ.get("APPDATA")
        base = Path(appdata) / "Aurison" if appdata else Path.home() / ".aurison"
        if not base.exists():
            legacy = _legacy_config_dir()
            if legacy.is_dir():
                try:
                    shutil.copytree(legacy, base)
                except OSError:
                    pass
    base.mkdir(parents=True, exist_ok=True)
    return base


def _as_int(value: object, default: int) -> int:
    try:
        return int(value)  # type: ignore[arg-type]
    except (TypeError, ValueError):
        return default


@dataclass
class Config:
    folders: list[str] = field(default_factory=list)
    selected_folder: str = ALL_TRACKS
    volume: int = 70
    shuffle: bool = False
    repeat_one: bool = False
    track_order: dict[str, list[str]] = field(default_factory=dict)
    hotkeys: dict[str, str] = field(default_factory=lambda: dict(DEFAULT_HOTKEYS))
    hotkeys_enabled: bool = True
    geometry: str = ""
    mini_position: list[int] | None = None
    mini_player_enabled: bool = True
    language: str = "ru"
    online_mode: bool = False
    online_scope: str = "tracks"
    online_sources: list[str] | None = None
    download_folder: str = ""

    @classmethod
    def load(cls) -> "Config":
        cfg = cls()
        path = config_dir() / "config.json"
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return cfg
        if not isinstance(data, dict):
            return cfg

        folders = data.get("folders")
        if isinstance(folders, list):
            seen: set[str] = set()
            for raw in folders:
                if not isinstance(raw, str) or not raw:
                    continue
                resolved = str(Path(raw))
                key = os.path.normcase(resolved)
                if key not in seen:
                    seen.add(key)
                    cfg.folders.append(resolved)

        selected = data.get("selected_folder")
        if isinstance(selected, str) and selected:
            cfg.selected_folder = selected

        cfg.volume = max(0, min(100, _as_int(data.get("volume"), cfg.volume)))
        cfg.shuffle = bool(data.get("shuffle", cfg.shuffle))
        cfg.repeat_one = bool(data.get("repeat_one", cfg.repeat_one))

        orders = data.get("track_order")
        if isinstance(orders, dict):
            for key, value in orders.items():
                if not isinstance(key, str) or not isinstance(value, list):
                    continue
                cfg.track_order[key] = [
                    str(path) for path in value if isinstance(path, str) and path
                ]

        cfg.hotkeys_enabled = bool(data.get("hotkeys_enabled", cfg.hotkeys_enabled))

        hotkeys = data.get("hotkeys")
        if isinstance(hotkeys, dict):
            for action, default in DEFAULT_HOTKEYS.items():
                value = hotkeys.get(action)
                if isinstance(value, str) and value:
                    cfg.hotkeys[action] = value
                else:
                    cfg.hotkeys[action] = default

        geometry = data.get("geometry")
        if isinstance(geometry, str):
            cfg.geometry = geometry

        mini = data.get("mini_position")
        if (
            isinstance(mini, list)
            and len(mini) == 2
            and all(isinstance(v, int) for v in mini)
        ):
            cfg.mini_position = [mini[0], mini[1]]

        cfg.mini_player_enabled = bool(
            data.get("mini_player_enabled", cfg.mini_player_enabled)
        )

        language = data.get("language")
        if language in ("ru", "en"):
            cfg.language = language

        cfg.online_mode = bool(data.get("online_mode", cfg.online_mode))
        if data.get("online_scope") in ("tracks", "albums"):
            cfg.online_scope = data["online_scope"]
        sources = data.get("online_sources")
        if isinstance(sources, list):
            cfg.online_sources = [
                source
                for source in sources
                if isinstance(source, str) and source
            ]
        download_folder = data.get("download_folder")
        if isinstance(download_folder, str):
            cfg.download_folder = download_folder

        return cfg

    def save(self) -> None:
        path = config_dir() / "config.json"
        tmp = path.with_suffix(".json.tmp")
        try:
            tmp.write_text(
                json.dumps(asdict(self), ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
            os.replace(tmp, path)
        except OSError:
            pass
