from __future__ import annotations

import time
from pathlib import Path

from PySide6.QtCore import QThread, Signal

from aurison.i18n import tr
from aurison.music_service import (
    ALBUM_SOURCES,
    DOWNLOAD_FORMAT,
    ITUNES_SEARCH_URL,
    MAX_TRACK_MS,
    MIN_TRACK_MS,
    RUTUBE_SEARCH_URL,
    SEARCH_LIMIT,
    SOURCE_FORMATS,
    SOURCE_LABELS,
    SOURCE_ORDER,
    DownloadCancelled,
    MusicAggregatorService,
    SearchReport,
    SearchResult,
    clean_error,
    cookie_options,
    dedupe_key,
    entry_to_result,
    flat_extract,
    format_for,
    http_json,
    retryable,
    safe_folder_name,
    search_tracks,
    search_youtube_albums,
    stream_from_info,
    track_duration_ok,
)

try:
    import yt_dlp
except Exception:  # pragma: no cover - optional dependency
    yt_dlp = None


# Backwards-compatible aliases for the online layer's original helpers.
_flat_extract = flat_extract
_entry_to_result = entry_to_result
_search_tracks = search_tracks
_search_youtube_albums = search_youtube_albums
_preview_stream = stream_from_info
_clean_error = clean_error
_safe_folder_name = safe_folder_name
_DownloadCancelled = DownloadCancelled


class SearchWorker(QThread):
    """Runs aggregated provider searches without blocking the UI thread."""

    finishedSearch = Signal(int, list, list)
    finishedSearchDetailed = Signal(int, object)

    def __init__(
        self,
        generation: int,
        query: str,
        scope: str,
        parent=None,
        sources: list[str] | None = None,
    ) -> None:
        super().__init__(parent)
        self._generation = generation
        self._query = query
        self._scope = scope
        self._sources = None if sources is None else list(sources)
        self._cancelled = False

    def cancel(self) -> None:
        self._cancelled = True

    def run(self) -> None:
        service = MusicAggregatorService()
        try:
            report = service.search_report(
                self._query,
                self._scope,
                SEARCH_LIMIT,
                self._sources,
            )
        except Exception as error:  # noqa: BLE001 - report to UI
            report = SearchReport(errors=[clean_error(error)])
        if self._cancelled:
            return
        self.finishedSearchDetailed.emit(self._generation, report)
        self.finishedSearch.emit(
            self._generation,
            list(report.results),
            list(report.errors),
        )


class PreviewWorker(QThread):
    """Resolves a direct audio stream URL for listening before download."""

    previewReady = Signal(int, str, str, int)
    previewFailed = Signal(int, str)

    def __init__(
        self,
        generation: int,
        result: SearchResult,
        parent=None,
        fallback: bool = False,
    ) -> None:
        super().__init__(parent)
        self._generation = generation
        self.result = result
        self._fallback = fallback
        self._cancelled = False

    def cancel(self) -> None:
        self._cancelled = True

    def run(self) -> None:
        service = MusicAggregatorService()
        try:
            if self._fallback:
                stream_url, title, duration_ms = (
                    service.resolve_preview_fallback(self.result)
                )
            else:
                stream_url, title, duration_ms = service.resolve_preview(
                    self.result
                )
        except Exception as error:  # noqa: BLE001 - report to UI
            if not self._cancelled:
                self.previewFailed.emit(
                    self._generation, clean_error(error)
                )
            return
        if self._cancelled:
            return
        if not stream_url:
            self.previewFailed.emit(
                self._generation,
                tr("Источник не вернул аудио для прослушивания"),
            )
            return
        self.previewReady.emit(
            self._generation, stream_url, title, duration_ms
        )


class DownloadWorker(QThread):
    """Downloads one track or one album into the selected library folder."""

    progressChanged = Signal(int, str)
    finishedDownload = Signal(bool, str, str, int)

    def __init__(
        self,
        result: SearchResult,
        target_folder: str,
        parent=None,
    ) -> None:
        super().__init__(parent)
        self.result = result
        self.target_folder = target_folder
        self._cancelled = False
        self._finished_files: set[str] = set()
        self._started_at = 0.0

    def cancel(self) -> None:
        self._cancelled = True

    def _hook(self, data: dict) -> None:
        if self._cancelled:
            raise DownloadCancelled()
        status = data.get("status")
        info = data.get("info_dict") or {}
        if status == "downloading":
            total = data.get("total_bytes") or data.get(
                "total_bytes_estimate"
            )
            downloaded = data.get("downloaded_bytes") or 0
            percent = int(downloaded * 100 / total) if total else 0
            detail = ""
            index = info.get("playlist_index")
            count = info.get("playlist_count")
            if count:
                detail = f"{index or 1}/{count}"
            self.progressChanged.emit(max(0, min(100, percent)), detail)
        elif status == "finished":
            filename = data.get("filename")
            if filename:
                self._finished_files.add(str(filename))
            self.progressChanged.emit(100, "")

    def run(self) -> None:
        target = Path(self.target_folder)
        try:
            target.mkdir(parents=True, exist_ok=True)
        except OSError as error:
            self.finishedDownload.emit(
                False, self.target_folder, clean_error(error), 0
            )
            return

        service = MusicAggregatorService()
        self._started_at = time.time()
        try:
            service.download(self.result, target, self._hook)
        except DownloadCancelled:
            return
        except Exception as error:  # noqa: BLE001 - report to UI
            if self._cancelled:
                return
            self.finishedDownload.emit(
                False, self.target_folder, clean_error(error), 0
            )
            return

        if self._cancelled:
            return
        count = len(self._finished_files)
        if count == 0:
            try:
                count = sum(
                    1
                    for path in target.rglob("*")
                    if path.is_file()
                    and path.stat().st_mtime >= self._started_at - 2
                )
            except OSError:
                count = 0
        self.finishedDownload.emit(
            True, self.target_folder, "", count
        )
