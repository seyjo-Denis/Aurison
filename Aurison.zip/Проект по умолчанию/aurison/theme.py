STYLESHEET = """
* {
    font-family: "Segoe UI", "Inter", sans-serif;
    outline: none;
}

QMainWindow, QWidget#Root, QDialog, QMessageBox {
    background-color: #0f1013;
    color: #e7e9ee;
}

QLabel {
    background: transparent;
    color: #e7e9ee;
}

QWidget#Header {
    background-color: #0f1013;
    border-bottom: 1px solid #1e2126;
}

QLabel#Brand {
    color: #f3f5f9;
    font-size: 18px;
    font-weight: 700;
}

QLabel#BrandSub {
    color: #6b717c;
    font-size: 9px;
    font-weight: 600;
}

QLabel#ModeLabel {
    color: #7f8591;
    font-size: 10px;
    font-weight: 600;
}
QLabel#ModeLabel[online="true"] {
    color: #9db4ff;
}

QWidget#Sidebar {
    background-color: #131418;
    border-right: 1px solid #1e2126;
}

QLabel#Section {
    color: #626873;
    font-size: 10px;
    font-weight: 600;
}

QFrame#BrowseGroup {
    background-color: #20232a;
    border: 1px solid #2c3038;
    border-radius: 9px;
}
QPushButton#BrowseMain {
    background: transparent;
    border: none;
    border-top-left-radius: 8px;
    border-bottom-left-radius: 8px;
    color: #eceef3;
    font-size: 12px;
    font-weight: 600;
    padding: 9px 10px;
    text-align: left;
}
QPushButton#BrowseMain:hover {
    background-color: #272b33;
}
QPushButton#BrowseMain:pressed {
    background-color: #1c1f25;
}
QPushButton#BrowseRefresh {
    background: transparent;
    border: none;
    border-left: 1px solid #2c3038;
    border-top-right-radius: 8px;
    border-bottom-right-radius: 8px;
    padding: 0;
}
QPushButton#BrowseRefresh:hover {
    background-color: #272b33;
}
QPushButton#BrowseRefresh:pressed {
    background-color: #1c1f25;
}
QPushButton#BrowseRefresh:disabled {
    background: transparent;
}

QPushButton#AllTracks {
    background: transparent;
    border: none;
    border-radius: 8px;
    color: #b9bec9;
    font-size: 12px;
    padding: 8px 10px;
    text-align: left;
}
QPushButton#AllTracks:hover {
    background-color: #1a1d23;
    color: #e7e9ee;
}
QPushButton#AllTracks:checked {
    background-color: #232730;
    color: #f1f3f7;
}

QListWidget#FolderList {
    background: transparent;
    border: none;
    padding: 0;
}
QListWidget#FolderList::item {
    height: 36px;
    border-radius: 8px;
    padding-left: 6px;
    padding-right: 28px;
    color: #b8bdc7;
}
QListWidget#FolderList::item:hover {
    background-color: #1a1d23;
}
QListWidget#FolderList::item:selected {
    background-color: #232730;
    color: #f1f3f7;
}

QLabel#Hint {
    color: #555a64;
    font-size: 10px;
}

QWidget#Content {
    background-color: #0f1013;
}

QLabel#ContentTitle {
    color: #f0f2f6;
    font-size: 21px;
    font-weight: 600;
}
QLabel#ContentMeta {
    color: #747a86;
    font-size: 11px;
}
QFrame#Divider {
    background-color: #202329;
    border: none;
}

QPushButton#IconButton {
    background: transparent;
    border: none;
    border-radius: 8px;
    padding: 0;
}
QPushButton#IconButton:hover {
    background-color: #1d2026;
}
QPushButton#IconButton:pressed {
    background-color: #252932;
}

QTableWidget#TrackTable {
    background: transparent;
    border: none;
    gridline-color: transparent;
    selection-background-color: #22262e;
    selection-color: #ffffff;
}
QTableWidget#TrackTable::item {
    border: none;
    color: #c6cad3;
    padding-left: 8px;
    padding-right: 8px;
}
QTableWidget#TrackTable::item:selected {
    background-color: #22262e;
    color: #ffffff;
}

QHeaderView::section {
    background: transparent;
    border: none;
}

QLabel#PlaceholderTitle {
    color: #969ca8;
    font-size: 16px;
    font-weight: 600;
}
QLabel#PlaceholderText {
    color: #626873;
    font-size: 12px;
}
QLabel#PlaceholderIcon {
    color: #343943;
}

QScrollBar:vertical {
    background: transparent;
    width: 10px;
    margin: 2px;
}
QScrollBar::handle:vertical {
    background: #2a2e36;
    min-height: 32px;
    border-radius: 4px;
}
QScrollBar::handle:vertical:hover {
    background: #3a3f49;
}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
    height: 0;
}
QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {
    background: transparent;
}
QScrollBar:horizontal {
    background: transparent;
    height: 10px;
    margin: 2px;
}
QScrollBar::handle:horizontal {
    background: #2a2e36;
    min-width: 32px;
    border-radius: 4px;
}
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {
    width: 0;
}

QFrame#PlayerBar {
    background-color: #131418;
    border-top: 1px solid #1e2126;
}

QLabel#PlayerTitle {
    color: #eef0f4;
    font-size: 13px;
    font-weight: 600;
}
QLabel#PlayerTitle[empty="true"] {
    color: #666c77;
    font-weight: 400;
}
QLabel#PlayerTitle[error="true"] {
    color: #ff9c9c;
}
QLabel#Time {
    color: #7f8591;
    font-size: 10px;
    font-family: "Cascadia Mono", "Consolas", monospace;
}

QPushButton#Transport {
    background: transparent;
    border: none;
    border-radius: 8px;
    padding: 0;
}
QPushButton#Transport:hover {
    background-color: #20232a;
}
QPushButton#Transport:pressed {
    background-color: #292d36;
}
QPushButton#Transport:disabled {
    background: transparent;
}

QPushButton#PlayButton {
    background-color: #e9ebf1;
    border: none;
    border-radius: 21px;
    padding: 0;
}
QPushButton#PlayButton:hover {
    background-color: #ffffff;
}
QPushButton#PlayButton:pressed {
    background-color: #cfd3dc;
}
QPushButton#PlayButton:disabled {
    background-color: #2a2d34;
}

QPushButton#ToggleButton {
    background: transparent;
    border: none;
    border-radius: 8px;
    padding: 0;
}
QPushButton#ToggleButton:hover {
    background-color: #20232a;
}
QPushButton#ToggleButton:checked {
    background-color: #1e2431;
}

QSlider#Seek::groove:horizontal {
    height: 4px;
    border-radius: 2px;
    background: #282c33;
}
QSlider#Seek::sub-page:horizontal {
    background: #f2f4f8;
    border-radius: 2px;
}
QSlider#Seek::handle:horizontal {
    width: 0;
    height: 0;
    margin: 0;
    background: transparent;
}
QSlider#Seek::handle:horizontal:hover {
    background: transparent;
}
QSlider#Seek:disabled::sub-page:horizontal {
    background: #343841;
}

QSlider#Volume::groove:horizontal {
    height: 3px;
    border-radius: 1px;
    background: #2a2e36;
}
QSlider#Volume::sub-page:horizontal {
    background: #aab0bd;
    border-radius: 1px;
}
QSlider#Volume::handle:horizontal {
    width: 10px;
    height: 10px;
    margin: -4px 0;
    border-radius: 5px;
    background: #e8eaf0;
}

QDialog#SettingsDialog {
    background-color: #121316;
}
QLabel#DialogTitle {
    color: #f2f4f8;
    font-size: 20px;
    font-weight: 600;
}
QLabel#DialogSubtitle {
    color: #747a86;
    font-size: 11px;
}
QFrame#DialogDivider {
    background-color: #24272d;
    border: none;
}
QLabel#FieldLabel {
    color: #c6cad3;
    font-size: 12px;
}
QKeySequenceEdit {
    background: transparent;
    border: none;
    padding: 0;
}
QKeySequenceEdit QLineEdit {
    background-color: #1a1d23;
    border: 1px solid #2b2f37;
    border-radius: 8px;
    color: #e8eaf0;
    font-size: 12px;
    padding: 8px 10px;
    min-height: 17px;
    selection-background-color: #3a4a7a;
}
QKeySequenceEdit QLineEdit:focus {
    border-color: #6f7fd8;
}
QKeySequenceEdit:disabled {
    background: transparent;
}
QKeySequenceEdit:disabled QLineEdit {
    color: #5f646e;
    background-color: #16181d;
}
QCheckBox {
    color: #c6cad3;
    font-size: 12px;
    spacing: 8px;
}
QCheckBox::indicator {
    width: 16px;
    height: 16px;
    border-radius: 4px;
    border: 1px solid #3a3f49;
    background-color: #1a1d23;
}
QCheckBox::indicator:checked {
    background-color: #8fa4ff;
    border-color: #8fa4ff;
}
QCheckBox::indicator:disabled {
    border-color: #2a2e36;
    background-color: #17191e;
}

QComboBox#LanguageCombo, QComboBox#OnlineCombo {
    background-color: #1a1d23;
    border: 1px solid #2b2f37;
    border-radius: 8px;
    color: #e8eaf0;
    font-size: 12px;
    padding: 8px 10px;
    min-height: 17px;
}
QComboBox#LanguageCombo:hover, QComboBox#OnlineCombo:hover {
    border-color: #3a404b;
}
QComboBox#LanguageCombo:focus, QComboBox#OnlineCombo:focus {
    border-color: #6f7fd8;
}
QComboBox#LanguageCombo::drop-down, QComboBox#OnlineCombo::drop-down {
    border: none;
    width: 24px;
}
QComboBox#LanguageCombo QAbstractItemView, QComboBox#OnlineCombo QAbstractItemView {
    background-color: #181b20;
    border: 1px solid #2a2e36;
    color: #dfe2e8;
    selection-background-color: #252932;
    selection-color: #ffffff;
    outline: none;
    padding: 4px;
}

QPushButton#PrimaryButton {
    background-color: #e9ebf1;
    border: none;
    border-radius: 8px;
    color: #111216;
    font-weight: 600;
    padding: 9px 18px;
}
QPushButton#PrimaryButton:hover {
    background-color: #ffffff;
}
QPushButton#SecondaryButton {
    background-color: #1d2026;
    border: 1px solid #2b3038;
    border-radius: 8px;
    color: #d7dae2;
    padding: 8px 16px;
}
QPushButton#SecondaryButton:hover {
    background-color: #252932;
}
QPushButton#GhostButton {
    background: transparent;
    border: none;
    color: #8d939f;
    padding: 8px 10px;
}
QPushButton#GhostButton:hover {
    background-color: #1c1f25;
    border-radius: 8px;
    color: #e8eaf0;
}
QPushButton#FilterButton {
    background-color: #1a1d23;
    border: 1px solid #2b3038;
    border-radius: 8px;
    color: #d7dae2;
    font-size: 12px;
    font-weight: 600;
    padding: 7px 12px;
}
QPushButton#FilterButton:hover {
    background-color: #232730;
    border-color: #424957;
    color: #f2f4f8;
}
QPushButton#FilterButton:pressed {
    background-color: #16181d;
}
QFrame#SourceFilterPanel {
    background-color: #16181d;
    border: 1px solid #2c3038;
    border-radius: 10px;
}
QLabel#FilterTitle {
    color: #f0f2f6;
    font-size: 13px;
    font-weight: 600;
}
QLabel#FilterSubtitle {
    color: #747a86;
    font-size: 10px;
}
QLabel#FilterCount {
    color: #9db4ff;
    font-size: 11px;
    font-weight: 600;
}
QLabel#FilterBadge {
    color: #8d939f;
    background-color: #1d2026;
    border: 1px solid #2b3038;
    border-radius: 7px;
    font-size: 9px;
    padding: 3px 6px;
}
QLabel#FilterBadge[status="ok"] {
    color: #9fd8b4;
    border-color: #2c4a38;
    background-color: #17211b;
}
QLabel#FilterBadge[status="preview"] {
    color: #d8c69f;
    border-color: #4a412c;
    background-color: #211f17;
}
QLabel#FilterBadge[status="unavailable"] {
    color: #ff9c9c;
    border-color: #4a2c2c;
    background-color: #211717;
}
QLabel#FilterBadge[status="pending"] {
    color: #9db4ff;
    border-color: #303b58;
    background-color: #1d2433;
}
QLabel#ErrorLabel {
    color: #ff9c9c;
    font-size: 11px;
}

QLineEdit#OnlineSearch {
    background-color: #17191e;
    border: 1px solid #2b2f37;
    border-radius: 9px;
    color: #e8eaf0;
    font-size: 13px;
    padding: 8px 12px;
    selection-background-color: #3a4a7a;
}
QLineEdit#OnlineSearch:focus {
    border-color: #6f7fd8;
}
QLineEdit#OnlineSearch:disabled {
    color: #5f646e;
    background-color: #14161a;
}
QLabel#OnlineStatus {
    color: #747a86;
    font-size: 11px;
}
QLabel#OnlineStatus[error="true"] {
    color: #ff9c9c;
}
QTableWidget#OnlineTable {
    background: transparent;
    border: none;
    gridline-color: transparent;
    selection-background-color: #1a1e27;
    selection-color: #ffffff;
}
QTableWidget#OnlineTable::item {
    border: none;
    padding-left: 8px;
    padding-right: 8px;
    color: #c6cad3;
}
QTableWidget#OnlineTable::item:selected {
    background-color: #1a1e27;
    color: #ffffff;
}
QTableWidget#OnlineTable QHeaderView::section {
    background: transparent;
    border: none;
    border-bottom: 1px solid #202329;
    color: #626873;
    font-size: 10px;
    font-weight: 600;
    padding-left: 8px;
    padding-right: 8px;
}
QLabel#OnlineTitle {
    color: #e7e9ee;
    font-size: 12px;
    font-weight: 600;
}
QLabel#OnlineMeta {
    color: #747a86;
    font-size: 10px;
}
QPushButton#PreviewButton {
    background-color: #1a1d23;
    border: 1px solid #2f3440;
    border-radius: 7px;
    color: #d7dae2;
    font-size: 11px;
    font-weight: 600;
    padding: 5px 10px;
}
QPushButton#PreviewButton:hover {
    background-color: #232730;
    border-color: #424957;
    color: #f2f4f8;
}
QPushButton#PreviewButton:pressed {
    background-color: #16181d;
}
QPushButton#PreviewButton:disabled {
    background-color: #191b20;
    border-color: #262a32;
    color: #5c616b;
}
QPushButton#DownloadButton {
    background-color: #1d2433;
    border: 1px solid #303b58;
    border-radius: 7px;
    color: #c9d5ff;
    font-size: 11px;
    font-weight: 600;
    padding: 5px 12px;
}
QPushButton#DownloadButton:hover {
    background-color: #252f45;
    border-color: #465780;
    color: #e4eaff;
}
QPushButton#DownloadButton:pressed {
    background-color: #19202d;
}
QPushButton#DownloadButton:disabled {
    background-color: #191b20;
    border-color: #262a32;
    color: #5c616b;
}
QProgressBar#DownloadProgress {
    background-color: #1e2126;
    border: none;
    border-radius: 2px;
}
QProgressBar#DownloadProgress::chunk {
    background-color: #9db4ff;
    border-radius: 2px;
}

QMenu {
    background-color: #181b20;
    border: 1px solid #2a2e36;
    border-radius: 8px;
    color: #dfe2e8;
    padding: 6px;
}
QMenu::item {
    padding: 7px 26px 7px 12px;
    border-radius: 6px;
}
QMenu::item:selected {
    background-color: #252932;
}
QMenu::separator {
    height: 1px;
    background: #2a2e36;
    margin: 5px 8px;
}

QToolTip {
    background-color: #1c1f25;
    color: #e7e9ee;
    border: 1px solid #2f343d;
    padding: 6px 8px;
    font-size: 11px;
}

QMessageBox QLabel {
    color: #e7e9ee;
}
QMessageBox QPushButton {
    background-color: #1d2026;
    border: 1px solid #2c3038;
    border-radius: 7px;
    color: #e7e9ee;
    min-width: 78px;
    padding: 7px 16px;
}
QMessageBox QPushButton:hover {
    background-color: #262a32;
}

QWidget#MiniCard {
    background: transparent;
}
QLabel#MiniTitle {
    color: #eef0f4;
}
QLabel#MiniState {
    color: #6e7480;
    font-size: 9px;
}
QPushButton#MiniButton {
    background: transparent;
    border: none;
    border-radius: 7px;
    padding: 0;
}
QPushButton#MiniButton:hover {
    background-color: #252932;
}
QPushButton#MiniPlay {
    background-color: #e9ebf1;
    border: none;
    border-radius: 17px;
    padding: 0;
}
QPushButton#MiniPlay:hover {
    background-color: #ffffff;
}
QSlider#MiniVolume::groove:horizontal {
    height: 3px;
    border-radius: 1px;
    background: #2a2e36;
}
QSlider#MiniVolume::sub-page:horizontal {
    background: #aab0bd;
    border-radius: 1px;
}
QSlider#MiniVolume::handle:horizontal {
    width: 8px;
    height: 8px;
    margin: -3px 0;
    border-radius: 4px;
    background: #e8eaf0;
}
QSlider#MiniVolume::handle:horizontal:hover {
    background: #ffffff;
}
"""

from pathlib import Path as _Path

_CHECK_ICON = (
    _Path(__file__).resolve().parent.parent / "assets" / "check.svg"
).as_posix()
STYLESHEET += f"""
QCheckBox::indicator:checked {{
    image: url("{_CHECK_ICON}");
}}
"""

