from __future__ import annotations

import ctypes
import sys


def apply_dark_title_bar(widget) -> None:
    """Ask DWM for a native dark title bar (Windows 10/11)."""
    if sys.platform != "win32":
        return
    try:
        hwnd = int(widget.winId())
        dwmapi = ctypes.windll.dwmapi
        enabled = ctypes.c_int(1)
        applied = False
        for attribute in (20, 19):  # DWMWA_USE_IMMERSIVE_DARK_MODE
            result = dwmapi.DwmSetWindowAttribute(
                hwnd, attribute, ctypes.byref(enabled), ctypes.sizeof(enabled)
            )
            if result == 0:
                applied = True
                break
        if not applied:
            return
        # Windows 11: blend the caption with the app background.
        caption = ctypes.c_int(0x0013100F)  # COLORREF for #0f1013
        text = ctypes.c_int(0x00EEE9E7)  # COLORREF for #e7e9ee
        dwmapi.DwmSetWindowAttribute(
            hwnd, 35, ctypes.byref(caption), ctypes.sizeof(caption)
        )
        dwmapi.DwmSetWindowAttribute(hwnd, 36, ctypes.byref(text), ctypes.sizeof(text))
    except Exception:
        pass
